# YouTube Live — correct Cloud setup

`DEVELOPER_ERROR` / login fail / stream never goes live is almost always package name + SHA-1 + Web Client ID mismatch.

## 1. Google Cloud project

1. Open Google Cloud Console and create (or pick) a project
2. Enable **YouTube Data API v3**
3. OAuth consent screen → External
4. Add your Gmail as a test user

## 2. OAuth clients

Create **two** OAuth client IDs:

### Android client

- Type: Android
- Package name: `com.example.esports` (must match `applicationId`)
- SHA-1 from the debug keystore:

```
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

If you sign a release build, also add that keystore SHA-1.

### Web application client

Sign-In needs the **Web** client ID, not the Android client ID.

## 3. App strings

Put the Web client ID in `app/src/main/res/values/strings.xml`:

```xml
<string name="default_web_client_id" translatable="false">YOUR_WEB_CLIENT_ID.apps.googleusercontent.com</string>
```

Leave it empty until you have a real Web client ID. Requesting a fake or Android client ID causes `DEVELOPER_ERROR (10)`.

## 4. In-app live flow

1. Connect YouTube (OAuth success)
2. Create broadcast (title, privacy, resolution/fps)
3. Bind stream
4. App starts RTMPS ingest
5. Wait until YouTube status is Good / Live
6. Transition to LIVE

## Common fails

| Error | Cause | Fix |
|---|---|---|
| DEVELOPER_ERROR (10) | Package / SHA-1 / Web client mismatch | Register exact `com.example.esports` + debug SHA-1; use Web client ID |
| empty token | Consent not granted | Approve YouTube scopes on the Google screen |
| RTMP connect fail | Insecure ingest / bad URL | App now prefers `rtmpsIngestionAddress` |
| stop looks successful | Old code hid the API error | Stop errors now show on the YouTube card |
