# MVP Live Analyser v1.2

Version code 3. Kill detector and Supabase were not changed.

## Fixed

- Pointer overlay still lazy-loads one section at a time (unchanged safe path)
- Screen capture downscales to 720p/1080p long-edge instead of full-phone RGBA every frame
- Pixel buffer ring + metrics StateFlow throttled to ~8 FPS
- Recording no longer clamps to 540p / 24fps / 2.5 Mbps; HIGH/1080p is used when the device encoder supports it
- Local MP4 now muxes AAC audio (mic + internal game audio)
- Audio and video PTS share one `MediaClock` (System.nanoTime epoch)
- Internal game audio starts with MediaProjection (`AudioPlaybackCapture`)
- Encoder prefers MediaCodec Surface input; YUV software path is fallback only
- Compositor double-buffers output bitmaps (no shared mutable frame race)
- Preview and encoder use the same center-crop framing module
- Meme overlay converts YUV → Bitmap directly (JPEG path removed)
- YouTube tokens never fall back to plaintext; encrypt fail forces re-login
- YouTube ingest prefers `rtmpsIngestionAddress`
- Stop-broadcast and go-live failures now show the real error in the UI
- Google Sign-In uses `default_web_client_id` only when you set a Web client ID

## YouTube DEVELOPER_ERROR

This is a Cloud Console config issue, not app logic. Follow `YOUTUBE_SETUP.md`.
