package com.example.services.composition

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF

/**
 * Single source of truth for preview + encoder framing.
 * Center-crop to destination aspect so station preview and YouTube/MP4
 * use the same crop/scale matrix (no stretch vs crop mismatch).
 */
object BroadcastFraming {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    fun even(value: Int): Int = (value and 1.inv()).coerceAtLeast(2)

    fun fitSize(srcW: Int, srcH: Int, maxW: Int, maxH: Int): Pair<Int, Int> {
        if (srcW <= 0 || srcH <= 0) return Pair(even(maxW), even(maxH))
        val scale = minOf(maxW.toFloat() / srcW, maxH.toFloat() / srcH)
        val w = even((srcW * scale).toInt().coerceAtLeast(2))
        val h = even((srcH * scale).toInt().coerceAtLeast(2))
        return Pair(w, h)
    }

    fun centerCropMatrix(srcW: Int, srcH: Int, dstW: Int, dstH: Int): Matrix {
        val matrix = Matrix()
        if (srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0) return matrix
        val scale = maxOf(dstW.toFloat() / srcW, dstH.toFloat() / srcH)
        val dx = (dstW - srcW * scale) * 0.5f
        val dy = (dstH - srcH * scale) * 0.5f
        matrix.setScale(scale, scale)
        matrix.postTranslate(dx, dy)
        return matrix
    }

    fun drawFramed(canvas: Canvas, source: Bitmap, dstW: Int, dstH: Int) {
        if (source.isRecycled || dstW <= 0 || dstH <= 0) return
        canvas.drawBitmap(source, centerCropMatrix(source.width, source.height, dstW, dstH), paint)
    }

    fun framedCopy(source: Bitmap, dstW: Int, dstH: Int, reuse: Bitmap? = null): Bitmap {
        val w = even(dstW)
        val h = even(dstH)
        val target = if (reuse != null && !reuse.isRecycled && reuse.width == w && reuse.height == h && reuse.isMutable) {
            reuse
        } else {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        }
        target.eraseColor(0)
        val canvas = Canvas(target)
        drawFramed(canvas, source, w, h)
        return target
    }

    fun destRect(dstW: Int, dstH: Int): RectF = RectF(0f, 0f, dstW.toFloat(), dstH.toFloat())
}
