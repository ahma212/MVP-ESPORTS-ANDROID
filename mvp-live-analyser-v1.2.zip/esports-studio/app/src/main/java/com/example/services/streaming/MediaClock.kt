package com.example.services.streaming

/**
 * Shared monotonic clock for audio + video PTS.
 * Both tracks must start from the same epoch so A/V stay in sync.
 */
object MediaClock {
    @Volatile
    private var epochNs: Long = 0L

    @Synchronized
    fun reset() {
        epochNs = System.nanoTime()
    }

    fun ensureStarted() {
        if (epochNs == 0L) reset()
    }

    fun ptsUs(): Long {
        ensureStarted()
        return ((System.nanoTime() - epochNs) / 1000L).coerceAtLeast(0L)
    }

    fun isRunning(): Boolean = epochNs != 0L
}
