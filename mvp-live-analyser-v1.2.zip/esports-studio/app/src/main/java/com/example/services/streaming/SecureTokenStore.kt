package com.example.services.streaming

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Secure token manager using Android KeyStore + AES-256 GCM encryption.
 * Tokens are NEVER stored in plaintext. Encryption failure means the save is skipped
 * and the caller must force re-login.
 */
class SecureTokenStore(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "SecureTokenStore"
        private const val PREF_NAME = "mvp_esports_secure_tokens"
        private const val KEY_ACCESS_TOKEN = "yt_access_token"
        private const val KEY_REFRESH_TOKEN = "yt_refresh_token"
        private const val KEY_TOKEN_EXPIRY = "yt_token_expiry"
        private const val KEY_CHANNEL_TITLE = "yt_channel_title"
        private const val KEY_CHANNEL_ID = "yt_channel_id"
        private const val KEY_ENC_OK = "yt_tokens_encrypted_ok"

        private const val KEY_ALIAS = "MvpEsportsYouTubeSecretKey"
        private const val ANDROID_KEY_STORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
    }

    class TokenEncryptionException(message: String, cause: Throwable? = null) : Exception(message, cause)

    init {
        initKeyStore()
    }

    private fun initKeyStore() {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
            if (!keyStore.containsAlias(KEY_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
                val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()

                keyGenerator.init(keyGenParameterSpec)
                keyGenerator.generateKey()
            }
        } catch (e: Exception) {
            Log.e(TAG, "KeyStore init failed — tokens will not be persisted", e)
        }
    }

    private fun getSecretKey(): SecretKey? {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
            val entry = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            entry?.secretKey
        } catch (e: Exception) {
            Log.e(TAG, "Secret key unavailable", e)
            null
        }
    }

    fun encryptAndSave(key: String, value: String) {
        val secretKey = getSecretKey()
            ?: throw TokenEncryptionException("Android KeyStore key unavailable — refusing plaintext token save")

        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(value.toByteArray(Charsets.UTF_8))

            val combined = ByteArray(iv.size + encryptedBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)

            val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
            prefs.edit().putString(key, encoded).putBoolean(KEY_ENC_OK, true).apply()
        } catch (e: Exception) {
            throw TokenEncryptionException("Token encryption failed — token not saved", e)
        }
    }

    fun getAndDecrypt(key: String): String? {
        val stored = prefs.getString(key, null) ?: return null
        val secretKey = getSecretKey()
        if (secretKey == null) {
            Log.e(TAG, "Cannot decrypt $key — key missing. Forcing re-login.")
            clear()
            return null
        }

        return try {
            val combined = Base64.decode(stored, Base64.NO_WRAP)
            if (combined.size <= 12) {
                Log.e(TAG, "Stored token for $key is not valid ciphertext — refusing plaintext fallback")
                prefs.edit().remove(key).apply()
                return null
            }

            val iv = ByteArray(12)
            val encrypted = ByteArray(combined.size - 12)
            System.arraycopy(combined, 0, iv, 0, 12)
            System.arraycopy(combined, 12, encrypted, 0, encrypted.size)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(encrypted)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            Log.e(TAG, "Decrypt failed for $key — clearing store so user re-logins", e)
            clear()
            null
        }
    }

    fun saveTokens(
        accessToken: String,
        refreshToken: String? = null,
        expiresInSeconds: Long = 3600,
        channelTitle: String? = null,
        channelId: String? = null
    ) {
        encryptAndSave(KEY_ACCESS_TOKEN, accessToken)
        if (!refreshToken.isNullOrBlank()) {
            encryptAndSave(KEY_REFRESH_TOKEN, refreshToken)
        }
        val expiryTime = System.currentTimeMillis() + (expiresInSeconds * 1000L)
        val editor = prefs.edit().putLong(KEY_TOKEN_EXPIRY, expiryTime)
        if (!channelTitle.isNullOrBlank()) {
            editor.putString(KEY_CHANNEL_TITLE, channelTitle)
        }
        if (!channelId.isNullOrBlank()) {
            editor.putString(KEY_CHANNEL_ID, channelId)
        }
        editor.apply()
    }

    fun getAccessToken(): String? = getAndDecrypt(KEY_ACCESS_TOKEN)
    fun getRefreshToken(): String? = getAndDecrypt(KEY_REFRESH_TOKEN)
    fun getChannelTitle(): String? = prefs.getString(KEY_CHANNEL_TITLE, null)
    fun getChannelId(): String? = prefs.getString(KEY_CHANNEL_ID, null)
    fun isTokenExpired(): Boolean {
        val expiry = prefs.getLong(KEY_TOKEN_EXPIRY, 0L)
        return System.currentTimeMillis() >= (expiry - 60000L)
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
