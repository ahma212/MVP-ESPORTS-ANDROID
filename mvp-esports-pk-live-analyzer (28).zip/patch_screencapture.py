import re

with open('app/src/main/java/com/example/platform/android/ScreenCaptureService.kt', 'r') as f:
    content = f.read()

old_code = """            if (rowPadding == 0) {
                val bytesToRead = minOf(buffer.remaining(), pixelData.size)
                buffer.get(pixelData, 0, bytesToRead)
            } else {
                var offset = 0
                val rowBytes = width * 4
                for (i in 0 until height) {
                    val rowStart = i * rowStride
                    if (rowStart < buffer.capacity()) {
                        buffer.position(rowStart)
                        val bytesToRead = minOf(rowBytes, buffer.remaining())
                        buffer.get(pixelData, offset, bytesToRead)
                    }
                    offset += rowBytes
                }
            }"""

# Can we optimize this? If rowPadding > 0, we can copy the whole buffer anyway and just use rowStride in composition?
# Wait! In composition we assume rowStride = width * 4. We can't just copy it all.
