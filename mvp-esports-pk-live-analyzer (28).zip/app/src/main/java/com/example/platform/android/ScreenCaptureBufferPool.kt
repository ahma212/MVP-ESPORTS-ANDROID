package com.example.platform.android

import com.example.core.model.FrameBufferReference
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Bounded, thread-safe pool of reusable ByteArray frame buffers for real-time screen capture.
 * Ensures zero-allocation buffer reuse without races: buffers are only reused after all
 * downstream consumers have fully released their reference counts.
 */
class ScreenCaptureBufferPool(
    val capacity: Int = 6
) {
    private val lock = ReentrantLock()
    private var poolWidth = 0
    private var poolHeight = 0
    private var poolByteSize = 0
    private var buffers: Array<FrameBufferReference>? = null

    /**
     * Reallocates pool if resolution changes or pool is not initialized.
     */
    fun configure(width: Int, height: Int, requiredSize: Int) {
        val size = maxOf(requiredSize, width * height * 4)
        lock.withLock {
            if (buffers == null || poolWidth != width || poolHeight != height || poolByteSize < size) {
                poolWidth = width
                poolHeight = height
                poolByteSize = size
                buffers = Array(capacity) { index ->
                    FrameBufferReference(
                        id = index,
                        array = ByteArray(size),
                        onRelease = { /* Buffer is now free for subsequent acquire */ }
                    )
                }
            }
        }
    }

    /**
     * Attempts to acquire an idle buffer from the pool and sets its initial reference count.
     * Returns null if all buffers in the pool are currently retained by active consumers.
     */
    fun acquireBuffer(width: Int, height: Int, requiredSize: Int, initialRefs: Int = 1): FrameBufferReference? {
        val size = maxOf(requiredSize, width * height * 4)
        lock.withLock {
            if (buffers == null || poolWidth != width || poolHeight != height || poolByteSize < size) {
                configure(width, height, size)
            }
            val pool = buffers ?: return null
            for (buf in pool) {
                if (buf.acquire(initialRefs)) {
                    return buf
                }
            }
            // All buffers are busy in downstream pipeline
            return null
        }
    }

    /**
     * Releases and frees all buffers when capture pipeline stops.
     */
    fun clear() {
        lock.withLock {
            buffers?.forEach { it.forceFree() }
            buffers = null
            poolWidth = 0
            poolHeight = 0
            poolByteSize = 0
        }
    }
}
