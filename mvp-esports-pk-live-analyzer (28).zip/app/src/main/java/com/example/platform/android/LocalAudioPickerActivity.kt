package com.example.platform.android

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.example.services.audio.LocalMusicPlayerManager

/**
 * Lightweight translucent Activity that launches the Android Storage Access Framework (SAF)
 * local audio picker for the floating pointer overlay.
 */
class LocalAudioPickerActivity : ComponentActivity() {

    private val audioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            handleSelectedAudio(uri)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            audioPickerLauncher.launch(arrayOf("audio/*"))
        } catch (_: Exception) {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "audio/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_CODE_PICK_AUDIO)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICK_AUDIO && resultCode == Activity.RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                handleSelectedAudio(uri)
            }
        }
        finish()
    }

    private fun handleSelectedAudio(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {}

        var title = "Custom Audio Track"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) {
                            title = name
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        LocalMusicPlayerManager.loadAndPlay(applicationContext, uri, title)
    }

    companion object {
        private const val REQUEST_CODE_PICK_AUDIO = 2002

        fun launch(context: Context) {
            val intent = Intent(context, LocalAudioPickerActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
