package com.example.platform.android

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.core.model.DetectionFrame
import com.example.services.video.IVideoInputService
import com.example.services.video.VideoCaptureState
import com.example.services.video.VideoSourceType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

/**
 * Real Android Video File Input Source.
 *
 * Decodes real frames from user-selected local video files (MP4/MKV)
 * and emits actual uncompressed RGBA_8888 DetectionFrames into the detection and composition pipeline.
 *
 * Employs zero-allocation byte buffers and smooth 30fps streaming.
 */
class AndroidVideoFileInputService(
    private val context: Context,
    private val videoUri: Uri
) : IVideoInputService {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var playbackJob: Job? = null
    private val bufferPool = ScreenCaptureBufferPool(capacity = 8)

    private val _captureState = MutableStateFlow<VideoCaptureState>(VideoCaptureState.Idle)
    override val captureState: StateFlow<VideoCaptureState> = _captureState.asStateFlow()

    private val _frameFlow = MutableSharedFlow<DetectionFrame>(
        extraBufferCapacity = 16,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )
    override val frameFlow: SharedFlow<DetectionFrame> = _frameFlow.asSharedFlow()

    override val activeSource: VideoSourceType = VideoSourceType.VIDEO_FILE_FEED

    private var durationMs: Long = 0L
    private var videoWidth: Int = 1920
    private var videoHeight: Int = 1080
    private var targetFps: Int = 30
    private var isPaused: Boolean = false
    private var currentPositionMs: Long = 0L
    private var lastStateUpdateMs: Long = 0L

    init {
        extractVideoMetadata()
    }

    private fun extractVideoMetadata() {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, videoUri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 0L

            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            videoWidth = widthStr?.toIntOrNull()?.coerceAtLeast(320) ?: 1920
            videoHeight = heightStr?.toIntOrNull()?.coerceAtLeast(180) ?: 1080

            val captureFpsStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
            targetFps = captureFpsStr?.toFloatOrNull()?.toInt()?.coerceIn(15, 60) ?: 30
        } catch (_: Exception) {
            durationMs = 0L
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) { }
        }
    }

    override suspend fun startCapture(): Result<Unit> {
        if (playbackJob?.isActive == true) {
            return Result.success(Unit)
        }

        isPaused = false
        _captureState.value = VideoCaptureState.Capturing(
            sourceType = VideoSourceType.VIDEO_FILE_FEED,
            width = videoWidth,
            height = videoHeight,
            fps = targetFps,
            framesCaptured = 0L
        )

        playbackJob = scope.launch {
            val decoder = com.example.services.media.HardwareVideoDecoder(context, videoUri)
            var frameIndex = 0L

            try {
                decoder.decodeContinuousRgba(targetFps = targetFps) { rgbaData, w, h, ptsMs ->
                    if (isPaused) return@decodeContinuousRgba

                    currentPositionMs = ptsMs
                    val expectedSize = w * h * 4
                    val subscribers = _frameFlow.subscriptionCount.value
                    val initialRefs = if (subscribers > 0) subscribers else 1
                    val bufferRef = bufferPool.acquireBuffer(w, h, expectedSize, initialRefs)

                    if (bufferRef != null) {
                        System.arraycopy(rgbaData, 0, bufferRef.array, 0, expectedSize)
                        val detectionFrame = DetectionFrame(
                            frameId = frameIndex,
                            timestampMs = ptsMs,
                            width = w,
                            height = h,
                            buffer = bufferRef.array,
                            format = "RGBA_8888",
                            sourceIdentifier = "video_file",
                            bufferRef = bufferRef
                        )

                        _frameFlow.tryEmit(detectionFrame)
                        frameIndex++
                    }

                    val now = System.currentTimeMillis()
                    if (now - lastStateUpdateMs >= 1000L) {
                        lastStateUpdateMs = now
                        _captureState.value = VideoCaptureState.Capturing(
                            sourceType = VideoSourceType.VIDEO_FILE_FEED,
                            width = w,
                            height = h,
                            fps = targetFps,
                            framesCaptured = frameIndex
                        )
                    }
                }
            } catch (e: Exception) {
                _captureState.value = VideoCaptureState.Error("Video decoding error: ${e.message}", e)
            } finally {
                bufferPool.clear()
            }
        }

        return Result.success(Unit)
    }

    fun pausePlayback() {
        isPaused = true
    }

    fun resumePlayback() {
        isPaused = false
    }

    fun seekTo(positionMs: Long) {
        currentPositionMs = positionMs.coerceIn(0L, durationMs.coerceAtLeast(0L))
    }

    override suspend fun stopCapture(): Result<Unit> {
        playbackJob?.cancel()
        playbackJob = null
        _captureState.value = VideoCaptureState.Idle
        currentPositionMs = 0L
        isPaused = false
        return Result.success(Unit)
    }

    override fun release() {
        playbackJob?.cancel()
        playbackJob = null
        _captureState.value = VideoCaptureState.Idle
    }
}
