package com.example.services.composition

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.example.core.model.DetectionFrame
import com.example.services.streaming.StandingTableControlsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

/**
 * Real-Time Broadcast Video Compositor Foundation (Part A).
 *
 * Implements [IBroadcastCompositor] and [com.example.services.streaming.ICompositionProcessor].
 *
 * Execution Pipeline:
 * Real Captured PUBG Frame (ScreenCaptureService)
 *         ↓
 * Broadcast Compositor Base Layer
 *         ↓
 * Overall Standing Overlay Layer (EsportsStandingTable integration)
 *         ↓
 * MVP ESPORTS Bottom Ticker Layer (EsportsBottomTicker integration)
 *         ↓
 * Final Composed Broadcast Frame (MediaCodec / Broadcast Program Output)
 *
 * Guarantees:
 * 1. Base layer is strictly the real captured PUBG mobile screen frame (never fake/placeholder).
 * 2. PUBG gameplay remains fully visible beneath semi-transparent esports overlays.
 * 3. Operator controls (Floating pointer, ROI boxes, buttons) are strictly excluded from broadcast output.
 * 4. Memory-optimized zero-allocation buffer reuse across high-frequency 30/60 FPS frames.
 */
class BroadcastVideoCompositor private constructor() : IBroadcastCompositor {

    companion object {
        @Volatile
        private var instance: BroadcastVideoCompositor? = null

        fun getInstance(): BroadcastVideoCompositor {
            return instance ?: synchronized(this) {
                instance ?: BroadcastVideoCompositor().also { instance = it }
            }
        }
    }

    private val layers = ConcurrentHashMap<String, IBroadcastLayer>()

    override val standingOverlay = OverallStandingOverlayLayer()
    fun setTeamsProvider(provider: () -> List<com.example.core.model.TeamLiveState>) {
        standingOverlay.teamsProvider = provider
        customGraphicsOverlay.teamsProvider = provider
        vipMilestoneOverlay.teamsProvider = provider
    }
    override val tickerOverlay = BottomTickerOverlayLayer()
    val sceneGraphicsOverlay = SceneGraphicsOverlayLayer()
    val vipMilestoneOverlay = VipMilestoneOverlayLayer()
    val customGraphicsOverlay = CustomGraphicsOverlayLayer()
    val videoMemeOverlay = BroadcastVideoMemeOverlayLayer()

    private val _composedFrames = MutableSharedFlow<ComposedBroadcastFrame>(
        replay = 1,
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val composedFrames: SharedFlow<ComposedBroadcastFrame> = _composedFrames.asSharedFlow()

    private val _latestComposedFrame = MutableStateFlow<ComposedBroadcastFrame?>(null)
    override val latestComposedFrame: StateFlow<ComposedBroadcastFrame?> = _latestComposedFrame.asStateFlow()

    private val _isCompositing = MutableStateFlow(false)
    override val isCompositing: StateFlow<Boolean> = _isCompositing.asStateFlow()

    private var frameAttachmentJob: Job? = null
    private var controlsObserverJob: Job? = null
    private var sceneObserverJob: Job? = null
    private var milestoneObserverJob: Job? = null

    // Frame buffer pool to eliminate GC allocations while guaranteeing safe frame ownership
    private class FrameBufferSlot(
        val index: Int,
        var width: Int,
        var height: Int,
        var bitmap: Bitmap,
        var canvas: Canvas,
        val refCount: java.util.concurrent.atomic.AtomicInteger = java.util.concurrent.atomic.AtomicInteger(0)
    ) {
        fun release() {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    private class FrameBufferPool(private val poolSize: Int = 4) {
        private val slots = ArrayList<FrameBufferSlot>()
        private var currentWidth = 0
        private var currentHeight = 0

        @Synchronized
        fun acquireSlot(width: Int, height: Int): FrameBufferSlot {
            if (currentWidth != width || currentHeight != height) {
                slots.forEach { it.release() }
                slots.clear()
                currentWidth = width
                currentHeight = height
            }

            // Find an available slot with refCount == 0
            for (slot in slots) {
                if (slot.refCount.compareAndSet(0, 1)) {
                    return slot
                }
            }

            // If we have room in the pool, create a new slot
            if (slots.size < poolSize) {
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                val newSlot = FrameBufferSlot(slots.size, width, height, bmp, Canvas(bmp))
                newSlot.refCount.set(1)
                slots.add(newSlot)
                return newSlot
            }

            // If all pool slots are busy, allocate a temporary dynamic slot to avoid overwriting or blocking
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val dynamicSlot = FrameBufferSlot(-1, width, height, bmp, Canvas(bmp))
            dynamicSlot.refCount.set(1)
            return dynamicSlot
        }

        @Synchronized
        fun releaseSlot(slot: FrameBufferSlot) {
            if (slot.refCount.decrementAndGet() == 0) {
                if (slot.index == -1) {
                    // This was a temporary dynamic slot, recycle immediately
                    slot.release()
                }
                // Otherwise, it stays in the slots list with refCount = 0 for reuse
            }
        }

        @Synchronized
        fun releaseAll() {
            slots.forEach { it.release() }
            slots.clear()
            currentWidth = 0
            currentHeight = 0
        }
    }

    private val frameBufferPool = FrameBufferPool(poolSize = 4)

    // Reusable bitmaps and canvas for base screen frame decode
    @Volatile
    private var cachedBaseBitmap: Bitmap? = null
    @Volatile
    private var cachedCropBuffer: ByteArray? = null
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    
    // Smoothness tracking (zero-allocation ring buffer)
    private val frameTimesArray = LongArray(60)
    private var frameTimesIndex = 0
    private var frameTimesCount = 0
    private var lastFpsUpdate = 0L
    private var frameCount = 0
    @Volatile
    private var currentFps = 0
    @Volatile
    private var isHeavy = false

    init {
        // Register default Part A, Part E, Part F, and Part G broadcast layers
        addLayer(standingOverlay)
        addLayer(tickerOverlay)
        addLayer(sceneGraphicsOverlay)
        addLayer(vipMilestoneOverlay)
        addLayer(customGraphicsOverlay)
        addLayer(videoMemeOverlay)
    }

    override fun addLayer(layer: IBroadcastLayer) {
        // Floating pointer, cropper, and operator control overlays must NOT appear in broadcast composition
        if (layer.layerId.contains("pointer", ignoreCase = true) ||
            layer.layerId.contains("cropper", ignoreCase = true) ||
            layer.layerId.contains("control", ignoreCase = true) ||
            layer.layerId.contains("overlay_badge", ignoreCase = true)
        ) {
            android.util.Log.w("BroadcastVideoCompositor", "Excluded operator layer '${layer.layerId}' from broadcast composition")
            return
        }
        layers[layer.layerId] = layer
    }

    override fun removeLayer(layerId: String) {
        layers.remove(layerId)
    }

    override fun getLayer(layerId: String): IBroadcastLayer? {
        return layers[layerId]
    }

    override fun getAllLayers(): List<IBroadcastLayer> {
        return layers.values.sortedBy { it.zIndex }
    }

    override fun setStandingOverlayEnabled(enabled: Boolean) {
        standingOverlay.isEnabled = enabled
    }

    override fun setTickerOverlayEnabled(enabled: Boolean) {
        tickerOverlay.isEnabled = enabled
    }

    /**
     * Attaches directly to a live frame stream from ScreenCaptureService or IVideoInputService.
     */
    override fun attachFrameSource(frameFlow: SharedFlow<DetectionFrame>, scope: CoroutineScope) {
        frameAttachmentJob?.cancel()
        controlsObserverJob?.cancel()
        sceneObserverJob?.cancel()
        milestoneObserverJob?.cancel()

        _isCompositing.value = true

        // Synchronize with operator toggle controls from StandingTableControlsManager
        controlsObserverJob = scope.launch {
            StandingTableControlsManager.controlsState.collect { controls ->
                standingOverlay.isEnabled = controls.scoreboardEnabled
                standingOverlay.top3Mode = controls.top3ModeEnabled
                
                // Standing Scale/Size mapping
                standingOverlay.scale = when (controls.standingSize) {
                    "Small" -> 0.75f
                    "Large" -> 1.25f
                    else -> 1.0f // "Medium"
                }

                // Standing Position mapping
                when (controls.standingPosition) {
                    "Top Left" -> {
                        standingOverlay.xOffsetPercent = 0.05f
                        standingOverlay.yOffsetPercent = 0.05f
                    }
                    "Bottom Left" -> {
                        standingOverlay.xOffsetPercent = 0.05f
                        standingOverlay.yOffsetPercent = 0.55f
                    }
                    "Bottom Right" -> {
                        standingOverlay.xOffsetPercent = 0.68f
                        standingOverlay.yOffsetPercent = 0.55f
                    }
                    else -> { // "Top Right"
                        standingOverlay.xOffsetPercent = 0.68f
                        standingOverlay.yOffsetPercent = 0.05f
                    }
                }

                tickerOverlay.isEnabled = controls.bottomTickerEnabled
                tickerOverlay.speedMultiplier = controls.tickerSpeedMultiplier

                // Ticker Size (height + textScale) mapping
                when (controls.tickerSize) {
                    "Small" -> {
                        tickerOverlay.heightPx = 30f
                        tickerOverlay.textScale = 0.8f
                    }
                    "Large" -> {
                        tickerOverlay.heightPx = 60f
                        tickerOverlay.textScale = 1.3f
                    }
                    else -> { // "Medium"
                        tickerOverlay.heightPx = 42f
                        tickerOverlay.textScale = 1.0f
                    }
                }

                tickerOverlay.yOffsetPercent = controls.tickerYOffset
                tickerOverlay.customText = controls.tickerCustomText
                tickerOverlay.loopVideoUri = controls.tickerLoopVideoUri
                tickerOverlay.loopVideoEnabled = controls.tickerLoopVideoEnabled

                val activeMemeUri = controls.memeOverlayUri ?: controls.tickerLoopVideoUri
                val isMemeActive = controls.memeOverlayEnabled || controls.tickerLoopVideoEnabled
                videoMemeOverlay.videoUri = activeMemeUri
                videoMemeOverlay.isEnabled = isMemeActive
                videoMemeOverlay.memePosition = controls.memePosition

                customGraphicsOverlay.isEnabled = controls.customGraphicsEnabled
                customGraphicsOverlay.customBannerText = controls.customBannerText
                customGraphicsOverlay.customBannerPosition = controls.customBannerPosition
                customGraphicsOverlay.customBannerScale = controls.customBannerScale
                vipMilestoneOverlay.isEnabled = controls.killCardEnabled || controls.milestoneCardEnabled
            }
        }

        // Synchronize with EsportsSceneEngine state (enabling scene graphics overlay for countdowns, breaks, endings)
        sceneObserverJob = scope.launch {
            com.example.services.scene.EsportsSceneEngine.sceneState.collect { sceneState ->
                val isLive = sceneState.currentScene == com.example.core.model.EsportsScene.LIVE_MATCH
                sceneGraphicsOverlay.isEnabled = !isLive
            }
        }

        // Observe teams state for VIP milestones
        milestoneObserverJob = scope.launch {
            var previousTeams = emptyList<com.example.core.model.TeamLiveState>()
            com.example.services.streaming.LocalLiveRuntimeManager.teamsState.collect { currentTeams ->
                if (previousTeams.isNotEmpty()) {
                    vipMilestoneOverlay.detectMilestones(previousTeams, currentTeams)
                }
                previousTeams = currentTeams
            }
        }

        // Ingest and composite real frames in background
        frameAttachmentJob = scope.launch(kotlinx.coroutines.Dispatchers.Default) {
            frameFlow.collect { rawFrame ->
                try {
                    composeFrame(rawFrame)
                } finally {
                    rawFrame.release()
                }
            }
        }
    }

    /**
     * Core composition engine.
     * Takes the real captured PUBG mobile frame, paints it as the background,
     * overlays active esports graphics, and outputs the final broadcast frame.
     */
    @Synchronized
    override fun composeFrame(rawFrame: DetectionFrame): ComposedBroadcastFrame? {
        val buffer = rawFrame.buffer ?: return null
        val width = rawFrame.width
        val height = rawFrame.height
        if (width <= 0 || height <= 0) return null

        val expectedSize = width * height * 4
        if (buffer.size < expectedSize) return null

        val startTimestamp = System.currentTimeMillis()

        try {
            // 1. Determine target broadcast resolution from StationDeskManager
            val targetRes = com.example.services.station.StationDeskManager.stationState.value.resolution
            val outW = targetRes.width
            val outH = targetRes.height

            // Calculate precise 16:9 crop framing boundaries (ContentScale.Crop matching Station preview)
            val targetAspect = outW.toFloat() / outH.toFloat()
            val srcAspect = width.toFloat() / height.toFloat()
            val srcRect = if (srcAspect > targetAspect) {
                val scaledWidth = (height * targetAspect).toInt()
                val left = (width - scaledWidth) / 2
                android.graphics.Rect(left, 0, left + scaledWidth, height)
            } else {
                val scaledHeight = (width / targetAspect).toInt()
                val top = (height - scaledHeight) / 2
                android.graphics.Rect(0, top, width, top + scaledHeight)
            }

            // 2. Load entire buffer directly into full-resolution base bitmap to avoid manual row-by-row array copy overhead.
            var baseBmp = cachedBaseBitmap
            if (baseBmp == null || baseBmp.width != width || baseBmp.height != height || baseBmp.isRecycled) {
                baseBmp?.recycle()
                baseBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                cachedBaseBitmap = baseBmp
            }
            val byteBuffer = ByteBuffer.wrap(buffer, 0, expectedSize)
            baseBmp.copyPixelsFromBuffer(byteBuffer)

            // 3. Acquire dedicated target-resolution frame buffer slot from pool
            val slot = frameBufferPool.acquireSlot(outW, outH)
            val outBmp = slot.bitmap
            val canvas = slot.canvas

            // 4. Draw cropped region of the full bitmap directly to target resolution (hardware-accelerated if possible)
            basePaint.colorFilter = com.example.services.station.StationDeskManager.getColorFilter()
            basePaint.isFilterBitmap = true
            val dstRect = android.graphics.Rect(0, 0, outW, outH)
            canvas.drawBitmap(baseBmp, srcRect, dstRect, basePaint)

            // 6. Render Active Broadcast Overlay Layers (in strict z-index order)
            // Encoded video is gameplay + standing + ticker + milestones + memes only.
            // FloatingPointerOverlay views and operator controls are strictly excluded.
            val enabledLayers = layers.values.filter { layer ->
                layer.isEnabled &&
                    !layer.layerId.contains("pointer", ignoreCase = true) &&
                    !layer.layerId.contains("cropper", ignoreCase = true) &&
                    !layer.layerId.contains("control", ignoreCase = true)
            }.sortedBy { it.zIndex }
            val activeLayerIds = mutableListOf<String>()

            for (layer in enabledLayers) {
                layer.draw(canvas, outW, outH, rawFrame.timestampMs)
                activeLayerIds.add(layer.layerId)
            }

            val elapsed = System.currentTimeMillis() - startTimestamp
            val frameTimestamp = if (rawFrame.timestampMs > 0L) rawFrame.timestampMs else System.currentTimeMillis()
            
            // Auto-Downgrade logic (zero-allocation ring buffer)
            frameCount++
            frameTimesArray[frameTimesIndex] = elapsed
            frameTimesIndex = (frameTimesIndex + 1) % 60
            if (frameTimesCount < 60) frameTimesCount++
            
            val now = System.currentTimeMillis()
            if (now - lastFpsUpdate > 1000) {
                currentFps = frameCount
                frameCount = 0
                lastFpsUpdate = now
                
                var sum = 0L
                for (i in 0 until frameTimesCount) {
                    sum += frameTimesArray[i]
                }
                val avgTime = if (frameTimesCount > 0) sum.toDouble() / frameTimesCount else 0.0
                isHeavy = avgTime > 20.0
                
                // Update StationDeskManager
                com.example.services.station.StationDeskManager.updatePerformanceMetrics(currentFps, isHeavy)
                
                // If in QUALITY and heavy for 2 seconds, trigger auto-downgrade
                val state = com.example.services.station.StationDeskManager.stationState.value
                if (state.smoothnessMode == com.example.services.station.SmoothnessMode.QUALITY && isHeavy) {
                    com.example.services.station.StationDeskManager.triggerAutoDowngrade()
                }
            }

            val composed = ComposedBroadcastFrame(
                frameId = rawFrame.frameId,
                timestampMs = frameTimestamp,
                width = outW,
                height = outH,
                bitmap = outBmp,
                activeLayers = activeLayerIds,
                compositionTimeMs = elapsed,
                onRelease = {
                    frameBufferPool.releaseSlot(slot)
                }
            )

            com.example.ui.util.FrameBitmapConverter.updateStationPreview(composed)
            
            val oldFrame = _latestComposedFrame.value
            _latestComposedFrame.value = composed
            oldFrame?.release()

            _composedFrames.tryEmit(composed)

            return composed
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**
     * Backward-compatible bridge to existing [com.example.services.streaming.ICompositionProcessor].
     * Program output is strictly gameplay + standing + ticker + milestones + memes only.
     * Overlay screenshots or badges are strictly NOT drawn into the compose bitmap.
     */
    override fun compositeOverlay(frame: DetectionFrame, overlayBadge: Bitmap?): Bitmap {
        val composed = composeFrame(frame)
        return composed?.bitmap
            ?: Bitmap.createBitmap(frame.width.coerceAtLeast(1), frame.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    }

    override fun release() {
        frameAttachmentJob?.cancel()
        frameAttachmentJob = null
        controlsObserverJob?.cancel()
        controlsObserverJob = null
        sceneObserverJob?.cancel()
        sceneObserverJob = null
        milestoneObserverJob?.cancel()
        milestoneObserverJob = null
        _isCompositing.value = false

        cachedBaseBitmap?.recycle()
        cachedBaseBitmap = null
        cachedCropBuffer = null

        frameBufferPool.releaseAll()

        val oldFrame = _latestComposedFrame.value
        _latestComposedFrame.value = null
        oldFrame?.release()
    }
}
