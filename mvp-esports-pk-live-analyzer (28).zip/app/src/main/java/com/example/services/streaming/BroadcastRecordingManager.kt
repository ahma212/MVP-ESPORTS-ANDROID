package com.example.services.streaming

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import com.example.services.audio.AudioMixerManager
import com.example.services.audio.InternalAudioCaptureManager
import com.example.services.audio.LocalMusicPlayerManager
import com.example.services.audio.MicrophoneCommentaryManager
import com.example.services.audio.MusicPcmDecoder
import com.example.services.audio.PcmMixer
import com.example.services.composition.BroadcastVideoCompositor
import com.example.services.composition.ComposedBroadcastFrame
import com.example.services.station.StationDeskManager
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.nio.ByteBuffer

enum class RecordingProfile(val label: String, val width: Int, val height: Int, val fps: Int, val bitrate: Int) {
    ULTRA("Ultra (1080p 60fps)", 1920, 1080, 60, 12000000),
    HIGH("High (1080p 30fps)", 1920, 1080, 30, 8000000),
    MEDIUM_60("Smooth (720p 60fps)", 1280, 720, 60, 6000000),
    MEDIUM("Medium (720p 30fps)", 1280, 720, 30, 5000000),
    LOW("Low (480p 30fps)", 854, 480, 30, 2000000)
}

/**
 * Production local video recording pipeline (Part 6).
 *
 * Captures composed frames from [BroadcastVideoCompositor] and mixed audio from [AudioMixerManager],
 * encoding them in real-time into a high-fidelity, synchronized MP4 file using MediaMuxer.
 *
 * Guarantees:
 * - Proper shutdown sequence: stop accepting new frames -> finish queued frames -> signal EOS ->
 *   drain encoders -> finalize muxer -> close resources without dropping final frames.
 * - Synchronized multi-track video (H.264) + audio (AAC-LC) muxing.
 * - Modern Android scoped-storage rules (MediaStore / ContentResolver / PFD / IS_PENDING).
 * - Immediate gallery visibility with MediaScannerConnection fallback.
 * - Leak-free resource management across all success and error paths.
 * - Accurate status and failure visibility for the operator.
 */
class BroadcastRecordingManager private constructor() {

    companion object {
        private const val TAG = "BroadcastRecording"
        private const val AUDIO_SAMPLE_RATE = 44100
        private const val AUDIO_CHANNEL_COUNT = 2
        private const val AUDIO_BITRATE = 128000

        @Volatile
        private var instance: BroadcastRecordingManager? = null

        fun getInstance(): BroadcastRecordingManager {
            return instance ?: synchronized(this) {
                instance ?: BroadcastRecordingManager().also { instance = it }
            }
        }
    }

    private val recordingScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var recordingJob: Job? = null
    private var frameCollectionJob: Job? = null
    private var encoderDrainJob: Job? = null
    private var audioCaptureJob: Job? = null
    private var durationJob: Job? = null

    private val recordingEncoder = MediaCodecVideoEncoder()
    private val recordingAudioEncoder = MediaCodecAudioEncoder()

    private val muxerLock = Any()
    private var mediaMuxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var audioTrackIndex = -1
    private var muxerStarted = false

    private val pendingVideoSamples = mutableListOf<Triple<ByteArray, Long, Boolean>>()
    private val pendingAudioSamples = mutableListOf<Triple<ByteArray, Long, Boolean>>()

    private var frameChannel: Channel<ComposedBroadcastFrame>? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0L)
    val recordingDurationSeconds: StateFlow<Long> = _recordingDurationSeconds.asStateFlow()

    private val _recordingError = MutableStateFlow<String?>(null)
    val recordingError: StateFlow<String?> = _recordingError.asStateFlow()

    private val _fileCreationStatus = MutableStateFlow<String?>("IDLE")
    val fileCreationStatus: StateFlow<String?> = _fileCreationStatus.asStateFlow()

    private val _selectedProfile = MutableStateFlow(RecordingProfile.HIGH)
    val selectedProfile: StateFlow<RecordingProfile> = _selectedProfile.asStateFlow()

    private val _selectedFps = MutableStateFlow(60)
    val selectedFps: StateFlow<Int> = _selectedFps.asStateFlow()

    private val _isAudioEnabled = MutableStateFlow(true)
    val isAudioEnabled: StateFlow<Boolean> = _isAudioEnabled.asStateFlow()

    private val _supportedResolutions = MutableStateFlow<List<Pair<Int, Int>>>(
        listOf(Pair(1920, 1080), Pair(1280, 720), Pair(854, 480))
    )
    val supportedResolutions: StateFlow<List<Pair<Int, Int>>> = _supportedResolutions.asStateFlow()

    private val _supportedFpsList = MutableStateFlow<List<Int>>(listOf(30, 60))
    val supportedFpsList: StateFlow<List<Int>> = _supportedFpsList.asStateFlow()

    private var currentOutputFile: File? = null
    private var currentOutputUri: Uri? = null
    private var currentPfd: ParcelFileDescriptor? = null
    private var recordingStartTimeMs = 0L
    private var lastRecordedPtsUs = -1L
    private var appContext: Context? = null
    private var configuredTargetFps = 30
    private var activeMusicDecoder: MusicPcmDecoder? = null

    init {
        val candidates = listOf(Pair(1920, 1080), Pair(1280, 720), Pair(854, 480))
        val supportedRes = candidates.filter { isResolutionSupported(it.first, it.second) }
        _supportedResolutions.value = if (supportedRes.isNotEmpty()) supportedRes else listOf(Pair(1920, 1080), Pair(1280, 720))

        val fpsCandidates = listOf(30, 60)
        val supportedFps = fpsCandidates.filter { isFpsSupported(it) }
        _supportedFpsList.value = if (supportedFps.isNotEmpty()) supportedFps else listOf(30, 60)
    }

    fun setSelectedProfile(profile: RecordingProfile) {
        _selectedProfile.value = profile
        _selectedFps.value = profile.fps
    }

    fun setSelectedFps(fps: Int) {
        _selectedFps.value = fps
    }

    fun setAudioEnabled(enabled: Boolean) {
        _isAudioEnabled.value = enabled
    }

    fun isResolutionSupported(width: Int, height: Int): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val codecList = android.media.MediaCodecList(android.media.MediaCodecList.REGULAR_CODECS)
                for (info in codecList.codecInfos) {
                    if (!info.isEncoder) continue
                    for (type in info.supportedTypes) {
                        if (type.equals("video/avc", ignoreCase = true)) {
                            val caps = info.getCapabilitiesForType(type)
                            val videoCaps = caps.videoCapabilities
                            if (videoCaps != null && videoCaps.isSizeSupported(width, height)) {
                                return true
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return (width == 1920 && height == 1080) || (width == 1280 && height == 720) || (width == 854 && height == 480)
    }

    fun isFpsSupported(fps: Int): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val codecList = android.media.MediaCodecList(android.media.MediaCodecList.REGULAR_CODECS)
                for (info in codecList.codecInfos) {
                    if (!info.isEncoder) continue
                    for (type in info.supportedTypes) {
                        if (type.equals("video/avc", ignoreCase = true)) {
                            val caps = info.getCapabilitiesForType(type)
                            val videoCaps = caps.videoCapabilities
                            if (videoCaps != null) {
                                val range = videoCaps.supportedFrameRates
                                if (range != null && range.contains(fps)) {
                                    return true
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return fps == 30 || fps == 60
    }

    /**
     * Starts local MP4 recording with capability validation, scoped storage setup,
     * and audio+video synchronization.
     */
    fun startRecording(
        context: Context,
        width: Int = _selectedProfile.value.width,
        height: Int = _selectedProfile.value.height,
        fps: Int = _selectedFps.value,
        bitrate: Int = _selectedProfile.value.bitrate,
        enableAudio: Boolean = _isAudioEnabled.value
    ): Result<Unit> {
        if (_isRecording.value) return Result.success(Unit)

        return try {
            appContext = context.applicationContext

            var targetWidth = width
            var targetHeight = height
            var targetFps = fps
            var targetBitrate = bitrate

            if (!isResolutionSupported(targetWidth, targetHeight)) {
                Log.w(TAG, "Requested resolution ${targetWidth}x${targetHeight} unsupported by device, falling back to 1280x720")
                targetWidth = 1280
                targetHeight = 720
            }

            if (!isFpsSupported(targetFps)) {
                Log.w(TAG, "Requested FPS $targetFps unsupported by device, falling back to 30")
                targetFps = 30
            }

            configuredTargetFps = targetFps
            _isAudioEnabled.value = enableAudio

            // Reset muxer state and buffers
            synchronized(muxerLock) {
                videoTrackIndex = -1
                audioTrackIndex = -1
                muxerStarted = false
                pendingVideoSamples.clear()
                pendingAudioSamples.clear()
            }

            // 1. Prepare modern scoped storage (MediaStore for Q+, direct file for legacy/fallback)
            val fileName = "MVP_STATION_${System.currentTimeMillis()}.mp4"
            var muxerCreated = false
            currentOutputFile = null
            currentOutputUri = null
            currentPfd = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MVP-Esports")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        val pfd = context.contentResolver.openFileDescriptor(uri, "rw")
                        if (pfd != null) {
                            currentOutputUri = uri
                            currentPfd = pfd
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                mediaMuxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                                muxerCreated = true
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "MediaStore initialization failed, using scoped app directory fallback: ${e.message}")
                }
            }

            if (!muxerCreated) {
                val moviesDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
                val targetDir = File(moviesDir, "MVP-Esports").apply { mkdirs() }
                val file = File(targetDir, fileName)
                currentOutputFile = file
                mediaMuxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                muxerCreated = true
            }

            // 2. Configure video encoder
            val videoConfigRes = recordingEncoder.configureEncoder(
                width = targetWidth,
                height = targetHeight,
                bitrate = targetBitrate,
                fps = targetFps,
                preferSurface = true
            )
            if (videoConfigRes.isFailure) {
                throw videoConfigRes.exceptionOrNull() ?: IllegalStateException("Failed to configure video encoder")
            }

            // 3. Configure audio encoder if enabled
            if (enableAudio) {
                val audioConfigRes = recordingAudioEncoder.configureEncoder(
                    sampleRate = AUDIO_SAMPLE_RATE,
                    channelCount = AUDIO_CHANNEL_COUNT,
                    bitrate = AUDIO_BITRATE
                )
                if (audioConfigRes.isFailure) {
                    Log.w(TAG, "Audio encoder configuration failed: ${audioConfigRes.exceptionOrNull()?.message}, continuing video-only")
                    _isAudioEnabled.value = false
                }
            }

            recordingStartTimeMs = SystemClock.elapsedRealtime()
            lastRecordedPtsUs = -1L
            _isRecording.value = true
            _recordingDurationSeconds.value = 0L

            val channel = Channel<ComposedBroadcastFrame>(
                capacity = 128,
                onBufferOverflow = BufferOverflow.SUSPEND,
                onUndeliveredElement = { frame -> frame.release() }
            )
            frameChannel = channel

            val filePathStr = currentOutputFile?.absolutePath ?: currentOutputUri?.toString() ?: fileName
            StationDeskManager.updateRecordingState(
                isRecording = true,
                durationSeconds = 0L,
                fileName = fileName,
                filePath = filePathStr
            )

            // 4. Video drain collector -> MediaMuxer
            encoderDrainJob = recordingScope.launch {
                recordingEncoder.encodedFrames.collect { encodedFrame ->
                    if (!_isRecording.value && !muxerStarted) return@collect
                    handleEncodedVideoFrame(encodedFrame)
                }
            }

            // 5. Composed frames collection -> bounded queue
            val compositor = BroadcastVideoCompositor.getInstance()
            frameCollectionJob = recordingScope.launch {
                compositor.composedFrames.collect { composedFrame ->
                    if (!_isRecording.value) return@collect
                    composedFrame.retain()
                    channel.send(composedFrame)
                }
            }

            // 6. Background encoding worker consuming from bounded queue
            recordingJob = recordingScope.launch(Dispatchers.IO) {
                for (frame in channel) {
                    try {
                        encodeAndMuxFrame(frame)
                    } finally {
                        frame.release()
                    }
                }
            }

            // 7. Audio Capture & Encoding loop if audio enabled
            if (_isAudioEnabled.value) {
                audioCaptureJob = recordingScope.launch(Dispatchers.IO) {
                    runAudioCaptureLoop()
                }
            }

            // 8. Duration Update Job
            durationJob = recordingScope.launch {
                while (isActive && _isRecording.value) {
                    delay(1000)
                    val dur = (SystemClock.elapsedRealtime() - recordingStartTimeMs) / 1000
                    _recordingDurationSeconds.value = dur
                    StationDeskManager.updateRecordingState(
                        isRecording = true,
                        durationSeconds = dur,
                        fileName = fileName,
                        filePath = filePathStr
                    )
                }
            }

            Log.i(TAG, "Local broadcast recording started: $filePathStr [${targetWidth}x${targetHeight} @ ${targetFps}fps, audio=${_isAudioEnabled.value}]")
            _fileCreationStatus.value = "RECORDING_ACTIVE: $fileName"
            _recordingError.value = null
            Result.success(Unit)
        } catch (e: Exception) {
            val errorMsg = e.message ?: "Failed to start recording"
            Log.e(TAG, "startRecording failed: $errorMsg", e)
            _recordingError.value = errorMsg
            _fileCreationStatus.value = "ERROR: $errorMsg"
            cleanupRecordingResources()
            Result.failure(e)
        }
    }

    private fun handleEncodedVideoFrame(encodedFrame: EncodedVideoFrame) {
        synchronized(muxerLock) {
            val muxer = mediaMuxer ?: return

            if (encodedFrame.isCodecConfig) {
                val videoFormat = recordingEncoder.getOutputFormat()
                if (videoFormat != null && !muxerStarted) {
                    try {
                        videoTrackIndex = muxer.addTrack(videoFormat)

                        if (_isAudioEnabled.value) {
                            val audioFormat = recordingAudioEncoder.getOutputFormat()
                                ?: MediaFormat.createAudioFormat(
                                    MediaFormat.MIMETYPE_AUDIO_AAC,
                                    AUDIO_SAMPLE_RATE,
                                    AUDIO_CHANNEL_COUNT
                                ).apply {
                                    setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE)
                                }
                            audioTrackIndex = muxer.addTrack(audioFormat)
                        }

                        muxer.start()
                        muxerStarted = true
                        Log.i(TAG, "MediaMuxer started with videoTrack=$videoTrackIndex, audioTrack=$audioTrackIndex")

                        // Flush pending video samples
                        for ((data, pts, isKey) in pendingVideoSamples) {
                            writeSampleDataInternal(videoTrackIndex, data, pts, isKey)
                        }
                        pendingVideoSamples.clear()

                        // Flush pending audio samples
                        if (audioTrackIndex >= 0) {
                            for ((data, pts, _) in pendingAudioSamples) {
                                writeSampleDataInternal(audioTrackIndex, data, pts, isKeyFrame = false)
                            }
                            pendingAudioSamples.clear()
                        }
                    } catch (ex: Exception) {
                        Log.e(TAG, "Error starting MediaMuxer: ${ex.message}", ex)
                    }
                }
                return
            }

            if (!muxerStarted) {
                // Buffer pre-start video frames so initial frames are not lost
                if (pendingVideoSamples.size < 60) {
                    pendingVideoSamples.add(Triple(encodedFrame.data, encodedFrame.presentationTimeUs, encodedFrame.isKeyFrame))
                }
                return
            }

            if (videoTrackIndex >= 0) {
                writeSampleDataInternal(videoTrackIndex, encodedFrame.data, encodedFrame.presentationTimeUs, encodedFrame.isKeyFrame)
            }
        }
    }

    private fun handleEncodedAudioPacket(data: ByteArray, ptsUs: Long, isConfig: Boolean) {
        if (isConfig) return
        synchronized(muxerLock) {
            if (!muxerStarted) {
                if (pendingAudioSamples.size < 100) {
                    pendingAudioSamples.add(Triple(data, ptsUs, false))
                }
                return
            }
            if (audioTrackIndex >= 0) {
                writeSampleDataInternal(audioTrackIndex, data, ptsUs, isKeyFrame = false)
            }
        }
    }

    private fun writeSampleDataInternal(trackIndex: Int, data: ByteArray, presentationTimeUs: Long, isKeyFrame: Boolean) {
        val muxer = mediaMuxer ?: return
        if (!muxerStarted || trackIndex < 0) return

        try {
            val bufferInfo = MediaCodec.BufferInfo().apply {
                set(
                    0,
                    data.size,
                    presentationTimeUs.coerceAtLeast(0L),
                    if (isKeyFrame) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                )
            }
            val buffer = ByteBuffer.wrap(data)
            muxer.writeSampleData(trackIndex, buffer, bufferInfo)
        } catch (ex: Exception) {
            Log.w(TAG, "Error writing sample data to track $trackIndex: ${ex.message}")
        }
    }

    private suspend fun runAudioCaptureLoop() {
        val bufferSize = 4096
        val micBuffer = ByteArray(bufferSize)
        val gameBuffer = ByteArray(bufferSize)
        val musicBuffer = ByteArray(bufferSize)
        val mixedBuffer = ByteArray(bufferSize * 2) // Stereo mixed output can be up to 2x mono input frames
        var audioPtsUs = 0L
        var activeMusicUri: String? = null

        try {
            while (currentCoroutineContext().isActive && _isRecording.value) {
                val micRead = MicrophoneCommentaryManager.read(micBuffer, 0, bufferSize)
                val gameRead = InternalAudioCaptureManager.read(gameBuffer, 0, bufferSize)

                val currentMusic = LocalMusicPlayerManager.musicState.value
                val ctx = appContext
                if (currentMusic.isPlaying && currentMusic.mediaUri != null && ctx != null) {
                    if (activeMusicUri != currentMusic.mediaUri) {
                        try { activeMusicDecoder?.stop() } catch (_: Exception) {}
                        activeMusicUri = currentMusic.mediaUri
                        try {
                            activeMusicDecoder = MusicPcmDecoder(
                                context = ctx,
                                uri = Uri.parse(currentMusic.mediaUri)
                            ).apply { start() }
                        } catch (_: Exception) {
                            activeMusicDecoder = null
                        }
                    }
                } else {
                    if (activeMusicDecoder != null) {
                        try { activeMusicDecoder?.stop() } catch (_: Exception) {}
                        activeMusicDecoder = null
                        activeMusicUri = null
                    }
                }

                val musicRead = activeMusicDecoder?.read(musicBuffer) ?: 0
                val mixerState = AudioMixerManager.mixerState.value

                val mixedLen = PcmMixer.mix(
                    micPcm = micBuffer,
                    micLen = micRead,
                    micVol = mixerState.micVolume,
                    micMuted = mixerState.micMuted,
                    gamePcm = gameBuffer,
                    gameLen = gameRead,
                    gameVol = mixerState.gameVolume,
                    gameMuted = mixerState.gameMuted,
                    musicPcm = musicBuffer,
                    musicLen = musicRead,
                    musicVol = mixerState.musicVolume,
                    musicMuted = mixerState.musicMuted,
                    outputPcm = mixedBuffer
                )

                if (mixedLen > 0) {
                    val wallClockPtsUs = (SystemClock.elapsedRealtime() - recordingStartTimeMs) * 1000L
                    if (Math.abs(audioPtsUs - wallClockPtsUs) > 100_000L) {
                        audioPtsUs = maxOf(0L, wallClockPtsUs)
                    }

                    recordingAudioEncoder.encodePcmData(mixedBuffer, 0, mixedLen, audioPtsUs) { aacPacket, _, isConfig ->
                        handleEncodedAudioPacket(aacPacket, audioPtsUs, isConfig)
                    }
                    audioPtsUs += (mixedLen.toLong() * 1_000_000L) / (AUDIO_SAMPLE_RATE * AUDIO_CHANNEL_COUNT * 2)
                } else {
                    delay(10L)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audio capture loop interrupted: ${e.message}")
        } finally {
            try { activeMusicDecoder?.stop() } catch (_: Exception) {}
            activeMusicDecoder = null
        }
    }

    /**
     * Executes synchronous stopping with complete pipeline draining to preserve
     * the last frames and audio data.
     */
    fun stopRecording(): Result<Unit> {
        if (!_isRecording.value) return Result.success(Unit)

        return runBlocking {
            stopRecordingInternal()
        }
    }

    /**
     * Coroutine-based shutdown sequence:
     * 1. Stop accepting new frames.
     * 2. Finish queued frames in frameChannel.
     * 3. Signal End-Of-Stream to video & audio encoders.
     * 4. Drain all trailing frames and audio packets.
     * 5. Stop and release MediaMuxer.
     * 6. Finalize MediaStore pending flag & trigger MediaScanner.
     * 7. Clean up all resources.
     */
    suspend fun stopRecordingInternal(): Result<Unit> {
        if (!_isRecording.value) return Result.success(Unit)

        val lastDur = _recordingDurationSeconds.value
        val lastFile = currentOutputFile
        val lastUri = currentOutputUri
        val ctx = appContext

        return try {
            // 1. Stop accepting new frames
            _isRecording.value = false

            // 2. Stop upstream compositor collection
            frameCollectionJob?.cancelAndJoin()
            frameCollectionJob = null

            // 3. Close the frame queue so the consumer drains all remaining frames
            frameChannel?.close()

            // 4. Wait for the recording job to encode all queued frames
            recordingJob?.join()
            recordingJob = null

            // 5. Signal EOS to video encoder and drain all remaining video packets
            recordingEncoder.signalEndOfStream()
            recordingEncoder.drainEndOfStream(maxAttempts = 30)

            // 6. Stop audio capture and drain audio encoder
            audioCaptureJob?.cancelAndJoin()
            audioCaptureJob = null

            if (_isAudioEnabled.value) {
                recordingAudioEncoder.signalEndOfStream()
                recordingAudioEncoder.drainOutputs { aacData, _, isConfig ->
                    handleEncodedAudioPacket(aacData, SystemClock.elapsedRealtime() * 1000L, isConfig)
                }
            }

            // 7. Cancel drain & duration jobs
            encoderDrainJob?.cancelAndJoin()
            encoderDrainJob = null
            durationJob?.cancelAndJoin()
            durationJob = null

            // 8. Stop encoders
            recordingEncoder.stopEncoder()
            recordingAudioEncoder.stopEncoder()

            // 9. Stop and release MediaMuxer
            synchronized(muxerLock) {
                if (muxerStarted) {
                    try {
                        mediaMuxer?.stop()
                    } catch (ex: Exception) {
                        Log.w(TAG, "MediaMuxer stop exception: ${ex.message}")
                    }
                }
                try {
                    mediaMuxer?.release()
                } catch (_: Exception) {}
                mediaMuxer = null
                muxerStarted = false
                pendingVideoSamples.clear()
                pendingAudioSamples.clear()
            }

            // 10. Close ParcelFileDescriptor if opened
            try {
                currentPfd?.close()
            } catch (_: Exception) {}
            currentPfd = null

            // 11. Finalize storage MediaStore IS_PENDING flag / MediaScanner
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && lastUri != null && ctx != null) {
                try {
                    val updateValues = ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }
                    ctx.contentResolver.update(lastUri, updateValues, null, null)
                    Log.i(TAG, "MediaStore recording finalized: $lastUri")
                } catch (ex: Exception) {
                    Log.w(TAG, "Failed updating MediaStore IS_PENDING: ${ex.message}")
                }
            }

            if (lastFile != null && lastFile.exists() && ctx != null) {
                try {
                    MediaScannerConnection.scanFile(
                        ctx,
                        arrayOf(lastFile.absolutePath),
                        arrayOf("video/mp4")
                    ) { path, uri ->
                        Log.i(TAG, "MP4 scanned into Gallery: $path -> $uri")
                    }
                } catch (ex: Exception) {
                    Log.w(TAG, "Failed to trigger media scan: ${ex.message}")
                }
            }

            val savedName = lastFile?.name ?: lastUri?.lastPathSegment ?: "recording.mp4"
            val savedPath = lastFile?.absolutePath ?: lastUri?.toString() ?: savedName

            StationDeskManager.updateRecordingState(
                isRecording = false,
                durationSeconds = lastDur,
                fileName = savedName,
                filePath = savedPath
            )

            _fileCreationStatus.value = "SAVED: $savedName"
            _recordingError.value = null
            Log.i(TAG, "Local broadcast recording successfully completed and saved: $savedPath")
            Result.success(Unit)
        } catch (e: Exception) {
            val errorMsg = e.message ?: "Failed to stop and finalize recording"
            Log.e(TAG, "stopRecording failed: $errorMsg", e)
            _recordingError.value = errorMsg
            _fileCreationStatus.value = "ERROR: $errorMsg"
            cleanupRecordingResources()
            Result.failure(e)
        }
    }

    private suspend fun encodeAndMuxFrame(composedFrame: ComposedBroadcastFrame) {
        try {
            val frameIntervalUs = 1_000_000L / configuredTargetFps.coerceAtLeast(1)
            var presentationTimeUs = composedFrame.timestampMs * 1000L
            
            // Fallback to elapsed time if timestamp is zero or invalid
            if (presentationTimeUs <= 0L) {
                presentationTimeUs = (SystemClock.elapsedRealtime() - recordingStartTimeMs) * 1000L
            }
            
            // Guarantee monotonic strictly increasing PTS
            if (lastRecordedPtsUs >= 0 && presentationTimeUs <= lastRecordedPtsUs) {
                presentationTimeUs = lastRecordedPtsUs + frameIntervalUs
            }
            
            lastRecordedPtsUs = presentationTimeUs

            recordingEncoder.encodeFrame(composedFrame.bitmap, presentationTimeUs)
        } catch (e: Exception) {
            Log.e(TAG, "Error encoding recording frame: ${e.message}", e)
        }
    }

    private fun cleanupRecordingResources() {
        _isRecording.value = false
        frameChannel?.close()
        frameChannel = null
        recordingJob?.cancel()
        recordingJob = null
        frameCollectionJob?.cancel()
        frameCollectionJob = null
        encoderDrainJob?.cancel()
        encoderDrainJob = null
        audioCaptureJob?.cancel()
        audioCaptureJob = null
        durationJob?.cancel()
        durationJob = null

        recordingEncoder.stopEncoder()
        recordingAudioEncoder.stopEncoder()

        synchronized(muxerLock) {
            try { mediaMuxer?.release() } catch (_: Exception) {}
            mediaMuxer = null
            muxerStarted = false
            pendingVideoSamples.clear()
            pendingAudioSamples.clear()
        }

        try { currentPfd?.close() } catch (_: Exception) {}
        currentPfd = null

        try { activeMusicDecoder?.stop() } catch (_: Exception) {}
        activeMusicDecoder = null
    }
}
