package com.example.services.streaming

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

data class EncodedAudioPacket(
    val data: ByteArray,
    val presentationTimeUs: Long,
    val isCodecConfig: Boolean,
    val isEndOfStream: Boolean = false
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is EncodedAudioPacket) return false
        if (!data.contentEquals(other.data)) return false
        if (presentationTimeUs != other.presentationTimeUs) return false
        if (isCodecConfig != other.isCodecConfig) return false
        if (isEndOfStream != other.isEndOfStream) return false
        return true
    }

    override fun hashCode(): Int {
        var result = data.contentHashCode()
        result = 31 * result + presentationTimeUs.hashCode()
        result = 31 * result + isCodecConfig.hashCode()
        result = 31 * result + isEndOfStream.hashCode()
        return result
    }
}

/**
 * Production AAC Audio Encoder using Android MediaCodec (AAC-LC).
 * Encodes PCM audio buffers into AAC bitstream packets for RTMP transmission and MP4 recording.
 */
class MediaCodecAudioEncoder {
    companion object {
        private const val TAG = "MediaCodecAudioEncoder"
        const val MIME_TYPE = MediaFormat.MIMETYPE_AUDIO_AAC
        const val DEFAULT_SAMPLE_RATE = 44100
        const val DEFAULT_BIT_RATE = 64000
        const val DEFAULT_CHANNEL_COUNT = 2
        private const val TIMEOUT_US = 10000L
    }

    private var mediaCodec: MediaCodec? = null
    var isRunning: Boolean = false
        private set

    private var currentOutputFormat: MediaFormat? = null
    private var lastPresentationTimeUs: Long = -1L

    private val _encodedPackets = MutableSharedFlow<EncodedAudioPacket>(extraBufferCapacity = 128)
    val encodedPackets: SharedFlow<EncodedAudioPacket> = _encodedPackets.asSharedFlow()

    fun configureEncoder(
        sampleRate: Int = DEFAULT_SAMPLE_RATE,
        channelCount: Int = DEFAULT_CHANNEL_COUNT,
        bitrate: Int = DEFAULT_BIT_RATE
    ): Result<Unit> {
        return try {
            val format = MediaFormat.createAudioFormat(MIME_TYPE, sampleRate, channelCount).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val codec = MediaCodec.createEncoderByType(MIME_TYPE)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            mediaCodec = codec
            currentOutputFormat = format
            isRunning = true
            lastPresentationTimeUs = -1L
            Result.success(Unit)
        } catch (e: Exception) {
            isRunning = false
            try { mediaCodec?.release() } catch (_: Exception) {}
            mediaCodec = null
            Log.e(TAG, "Failed to configure AAC encoder: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun getOutputFormat(): MediaFormat? {
        return try {
            mediaCodec?.outputFormat ?: currentOutputFormat
        } catch (_: Exception) {
            currentOutputFormat
        }
    }

    fun encodePcmData(
        pcmBytes: ByteArray,
        offset: Int = 0,
        length: Int = pcmBytes.size,
        presentationTimeUs: Long,
        onEncodedPacket: ((ByteArray, Long, Boolean) -> Unit)? = null
    ) {
        val codec = mediaCodec ?: return
        if (!isRunning) return

        try {
            val inputBufferIndex = codec.dequeueInputBuffer(TIMEOUT_US)
            if (inputBufferIndex >= 0) {
                val inputBuffer = codec.getInputBuffer(inputBufferIndex)
                inputBuffer?.clear()
                val size = minOf(length, inputBuffer?.remaining() ?: length)
                inputBuffer?.put(pcmBytes, offset, size)
                codec.queueInputBuffer(inputBufferIndex, 0, size, presentationTimeUs, 0)
            }

            drainOutputsInternal(onEncodedPacket)
        } catch (e: Exception) {
            Log.e(TAG, "AAC encoding error: ${e.message}", e)
        }
    }

    fun signalEndOfStream() {
        val codec = mediaCodec ?: return
        if (!isRunning) return
        try {
            val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
            if (inputIndex >= 0) {
                codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Audio signalEndOfStream failed: ${e.message}")
        }
    }

    fun drainOutputs(onEncodedPacket: ((ByteArray, Long, Boolean) -> Unit)? = null) {
        drainOutputsInternal(onEncodedPacket, maxAttempts = 30)
    }

    private fun drainOutputsInternal(
        onEncodedPacket: ((ByteArray, Long, Boolean) -> Unit)? = null,
        maxAttempts: Int = 10
    ) {
        val codec = mediaCodec ?: return
        val bufferInfo = MediaCodec.BufferInfo()
        var attempts = 0

        while (attempts < maxAttempts) {
            val outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, 0L)
            if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                break
            } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try {
                    currentOutputFormat = codec.outputFormat
                } catch (_: Exception) {}
            } else if (outputBufferIndex >= 0) {
                val outputBuffer = codec.getOutputBuffer(outputBufferIndex)
                val isEos = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                val isConfig = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0

                if (outputBuffer != null && bufferInfo.size > 0) {
                    outputBuffer.position(bufferInfo.offset)
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                    val outData = ByteArray(bufferInfo.size)
                    outputBuffer.get(outData)

                    val ptsUs = bufferInfo.presentationTimeUs
                    _encodedPackets.tryEmit(
                        EncodedAudioPacket(
                            data = outData,
                            presentationTimeUs = ptsUs,
                            isCodecConfig = isConfig,
                            isEndOfStream = isEos
                        )
                    )

                    // Callback passes ms for RTMP convenience: ptsUs / 1000L
                    onEncodedPacket?.invoke(outData, ptsUs / 1000L, isConfig)
                }
                codec.releaseOutputBuffer(outputBufferIndex, false)
                if (isEos) break
            }
            attempts++
        }
    }

    fun stopEncoder() {
        try {
            isRunning = false
            try {
                mediaCodec?.stop()
            } catch (_: Exception) {}
            try {
                mediaCodec?.release()
            } catch (_: Exception) {}
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping audio encoder: ${e.message}")
        } finally {
            mediaCodec = null
        }
    }
}
