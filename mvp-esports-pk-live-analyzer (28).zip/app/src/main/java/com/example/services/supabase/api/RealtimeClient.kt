package com.example.services.supabase.api

import android.util.Log
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class RealtimeClient(
    private val client: OkHttpClient,
    private val supabaseUrl: String,
    private val anonKey: String,
    private var sessionId: String? = null
) {
    private var webSocket: WebSocket? = null
    private val _updates = MutableSharedFlow<JSONObject>(extraBufferCapacity = 100)
    val updates: SharedFlow<JSONObject> = _updates.asSharedFlow()
    
    private var ref = 1
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO + kotlinx.coroutines.SupervisorJob())
    private var reconnectJob: kotlinx.coroutines.Job? = null
    private var isClosedNormally = false
    private var reconnectDelayMs = 1000L
    private val maxReconnectDelayMs = 30000L

    fun updateSessionId(newSessionId: String) {
        this.sessionId = newSessionId
    }
    
    fun connect() {
        isClosedNormally = false
        val wssUrl = supabaseUrl.replace("https://", "wss://").replace("http://", "ws://") + 
                     "/realtime/v1/websocket?apikey=$anonKey&vsn=1.0.0"
        
        val request = Request.Builder().url(wssUrl).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d("Realtime", "Connected")
                reconnectDelayMs = 1000L // reset delay on success
                val joinMsg = JSONObject().apply {
                    put("topic", "realtime:public")
                    put("event", "phx_join")
                    put("payload", JSONObject().apply {
                        put("config", JSONObject().apply {
                            put("postgres_changes", JSONArray().apply {
                                val currentSessionId = sessionId
                                if (currentSessionId != null) {
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_sessions")
                                        put("filter", "id=eq.$currentSessionId")
                                    })
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_teams")
                                        put("filter", "session_id=eq.$currentSessionId")
                                    })
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_players")
                                        put("filter", "session_id=eq.$currentSessionId")
                                    })
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_events")
                                        put("filter", "session_id=eq.$currentSessionId")
                                    })
                                } else {
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_sessions")
                                    })
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_teams")
                                    })
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_players")
                                    })
                                    put(JSONObject().apply {
                                        put("event", "*")
                                        put("schema", "public")
                                        put("table", "live_broadcast_events")
                                    })
                                }
                            })
                        })
                    })
                    put("ref", "${ref++}")
                }
                webSocket.send(joinMsg.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    val event = json.optString("event")
                    val payload = json.optJSONObject("payload")
                    val payloadType = payload?.optString("type") ?: payload?.optString("event")
                    if (event == "postgres_changes" || payloadType == "postgres_changes" || payload?.has("data") == true || payload?.has("record") == true) {
                        _updates.tryEmit(json)
                    }
                } catch (e: Exception) {
                    Log.e("Realtime", "Parse error", e)
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d("Realtime", "Closed: $code / $reason")
                if (!isClosedNormally) {
                    triggerReconnect()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e("Realtime", "Error", t)
                if (!isClosedNormally) {
                    triggerReconnect()
                }
            }
        })
    }
    
    private fun triggerReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            Log.d("Realtime", "Reconnecting in $reconnectDelayMs ms...")
            kotlinx.coroutines.delay(reconnectDelayMs)
            reconnectDelayMs = (reconnectDelayMs * 2).coerceAtMost(maxReconnectDelayMs)
            connect()
        }
    }
    
    fun heartbeat() {
        val msg = JSONObject().apply {
            put("topic", "phoenix")
            put("event", "heartbeat")
            put("payload", JSONObject())
            put("ref", "${ref++}")
        }
        webSocket?.send(msg.toString())
    }
    
    fun disconnect() {
        isClosedNormally = true
        reconnectJob?.cancel()
        webSocket?.close(1000, "Normal closure")
        webSocket = null
    }
}
