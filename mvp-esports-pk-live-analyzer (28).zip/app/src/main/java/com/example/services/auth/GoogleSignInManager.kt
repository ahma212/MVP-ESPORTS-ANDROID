package com.example.services.auth

import android.accounts.Account
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.services.streaming.SecureTokenStore
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Task
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Modernized Google authentication & YouTube credential manager.
 * Supports:
 * 1. Android Credential Manager (androidx.credentials) for modern Google Identity.
 * 2. Supported Google Sign-In intent fallback to preserve existing activity result flows.
 * 3. Scope validation for YouTube Live API ("https://www.googleapis.com/auth/youtube" and "https://www.googleapis.com/auth/youtube.force-ssl").
 * 4. Comprehensive DEVELOPER_ERROR (code 10) diagnostic reporting (package, SHA-1, client ID, API scopes).
 * 5. Secure token refresh & invalidation without hardcoded secrets.
 */
class GoogleSignInManager private constructor(
    private val context: Context,
    private val tokenStore: SecureTokenStore = SecureTokenStore(context)
) {

    companion object {
        private const val TAG = "GoogleSignInManager"

        const val YOUTUBE_SCOPE = "https://www.googleapis.com/auth/youtube"
        const val YOUTUBE_FORCE_SSL_SCOPE = "https://www.googleapis.com/auth/youtube.force-ssl"
        const val OAUTH2_YOUTUBE_FULL_SCOPE = "oauth2:$YOUTUBE_SCOPE $YOUTUBE_FORCE_SSL_SCOPE"

        @Volatile
        private var INSTANCE: GoogleSignInManager? = null

        fun getInstance(context: Context): GoogleSignInManager {
            return INSTANCE ?: synchronized(this) {
                val instance = GoogleSignInManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }

        /**
         * Resolves the configured Web Client ID dynamically from google-services resources
         * or environment without hardcoding secrets.
         */
        fun getWebClientId(context: Context): String? {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) {
                val id = context.getString(resId)
                if (id.isNotBlank()) return id
            }
            return null
        }

        /**
         * Generates human-readable, actionable diagnostics for DEVELOPER_ERROR (Code 10)
         * and other Google Play Services / Credential Manager configuration errors.
         */
        fun formatConfigurationDiagnostics(context: Context, errorCode: Int, rawMessage: String?): String {
            val packageName = context.packageName
            return buildString {
                append("[DEVELOPER_ERROR (Status Code: $errorCode)]\n")
                append("Actionable Configuration Checklist:\n")
                append("1. Package Name Mismatch: Ensure '$packageName' is registered in Google Cloud Console.\n")
                append("2. SHA-1 Fingerprint: Verify your debug/release signing certificate SHA-1 fingerprint matches the OAuth 2.0 Client ID in Google Cloud.\n")
                append("3. OAuth Client Type: Configure an 'Android' client ID in Google Cloud Console using '$packageName' + your keystore SHA-1.\n")
                val clientId = getWebClientId(context)
                if (clientId.isNullOrBlank()) {
                    append("4. Web Client ID: 'default_web_client_id' string resource is missing or empty. Ensure google-services.json includes a Web Client ID.\n")
                } else {
                    append("4. Web Client ID: Configured ($clientId).\n")
                }
                append("5. Enabled APIs: Verify 'YouTube Data API v3' is enabled in Google Cloud Console.\n")
                if (!rawMessage.isNullOrBlank()) {
                    append("Raw System Message: $rawMessage")
                }
            }
        }
    }

    data class AuthenticatedGoogleAccount(
        val email: String,
        val displayName: String?,
        val idToken: String?,
        val account: Account
    )

    /**
     * Modern Android Credential Manager sign-in flow.
     */
    suspend fun signInWithCredentialManager(activity: Activity): Result<AuthenticatedGoogleAccount> = withContext(Dispatchers.IO) {
        val credentialManager = CredentialManager.create(activity)
        val clientId = getWebClientId(activity)

        val getCredRequest = if (!clientId.isNullOrBlank()) {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(clientId)
                .setAutoSelectEnabled(false)
                .build()
            GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()
        } else {
            // If web client id is not configured, we cannot use GetGoogleIdOption directly without a server client id
            Log.w(TAG, "No Web Client ID found for CredentialManager. Falling back to Intent-based sign-in.")
            return@withContext Result.failure(
                IllegalStateException("Web Client ID is not configured. Please verify google-services.json or use legacy Google Sign-In.")
            )
        }

        try {
            val result = credentialManager.getCredential(activity, getCredRequest)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data)
                val email = googleIdToken.id
                val account = Account(email, "com.google")
                val authAccount = AuthenticatedGoogleAccount(
                    email = email,
                    displayName = googleIdToken.displayName,
                    idToken = googleIdToken.idToken,
                    account = account
                )
                Result.success(authAccount)
            } else {
                Result.failure(IllegalStateException("Unexpected credential type: ${credential.type}"))
            }
        } catch (e: GetCredentialCancellationException) {
            Result.failure(e)
        } catch (e: GetCredentialException) {
            val diag = formatConfigurationDiagnostics(activity, CommonStatusCodes.DEVELOPER_ERROR, e.message)
            Log.e(TAG, "Credential Manager error: $diag", e)
            Result.failure(Exception(diag, e))
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error in Credential Manager: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Retrieves a fresh OAuth 2.0 access token for the specified account and YouTube scopes.
     * In case of token rejection, invalidates cached tokens before retrying.
     */
    suspend fun acquireYouTubeAccessToken(
        account: Account,
        forceRefresh: Boolean = false
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (forceRefresh) {
                val existingToken = tokenStore.getAccessToken()
                if (!existingToken.isNullOrBlank()) {
                    try {
                        GoogleAuthUtil.clearToken(context, existingToken)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to clear token during force refresh: ${e.message}")
                    }
                }
            }

            val token = GoogleAuthUtil.getToken(context, account, OAUTH2_YOUTUBE_FULL_SCOPE)
            if (!token.isNullOrBlank()) {
                Result.success(token)
            } else {
                Result.failure(IllegalStateException("GoogleAuthUtil returned empty OAuth token."))
            }
        } catch (e: UserRecoverableAuthException) {
            // Must be propagated so the calling UI launches consent intent
            Result.failure(e)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to acquire YouTube access token: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Invalidates a revoked or expired token in GoogleAuthUtil cache and SecureTokenStore.
     */
    suspend fun invalidateToken(token: String) = withContext(Dispatchers.IO) {
        try {
            GoogleAuthUtil.clearToken(context, token)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clear token from GoogleAuthUtil: ${e.message}")
        }
        tokenStore.clear()
    }
}
