package com.example.services.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.example.core.model.RoiRegion
import com.example.platform.android.LocalAudioPickerActivity
import com.example.platform.android.LocalVideoPickerActivity
import com.example.services.audio.AudioMixerManager
import com.example.services.audio.LocalMusicPlayerManager
import com.example.services.roi.InMemoryRoiConfigurationService
import com.example.services.station.StationDeskManager
import com.example.services.streaming.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Lightweight Floating Pointer Overlay.
 *
 * Operates as a native, non-captured system overlay (TYPE_APPLICATION_OVERLAY + FLAG_SECURE)
 * acting as an in-game remote control while PUBG / gameplay is running.
 *
 * Architecture:
 * - Extremely lightweight floating circular shell (zero heavy memory retention).
 * - Lazy-loads section views: only the active section is constructed when opened.
 * - When switching sections or closing, previous section views and handlers are immediately released.
 * - Enforces strict UI separation from broadcast output: FLAG_SECURE ensures Android excludes
 *   this overlay window from ScreenCaptureService and MediaProjection.
 * - Single instance safety prevents duplicate overlays.
 */
class FloatingPointerOverlay(private val context: Context) : IFloatingControlService {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs: SharedPreferences = context.getSharedPreferences("mvp_pointer_prefs", Context.MODE_PRIVATE)

    private val _controlState = MutableStateFlow(FloatingControlState())
    override val controlState: StateFlow<FloatingControlState> = _controlState.asStateFlow()

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Overlay Window State
    @Volatile
    private var isAttached = false
    private var isExpanded = false
    private var pointerSizePreset = "SMALL"

    // Views
    private var overlayContainer: FrameLayout? = null
    private var pointerBubbleView: View? = null
    private var pointerStatusText: TextView? = null
    private var expandedCardView: LinearLayout? = null
    private var categoryMenuContainer: LinearLayout? = null
    private var sectionContentContainer: FrameLayout? = null
    private var headerTitleText: TextView? = null
    private var backButtonView: TextView? = null

    // Lazy section state
    private var currentSection: OverlaySection? = null
    private var activeSectionView: View? = null
    private var chatMessagesLayout: LinearLayout? = null

    // Chat polling runnable (only active when Chat section is open)
    private var chatPollingRunnable: Runnable? = null
    private var isSendingChat = false

    // Window Layout Params
    private var windowParams: WindowManager.LayoutParams? = null

    // Callbacks
    var onStopSessionRequested: (() -> Unit)? = null

    companion object {
        @Volatile
        private var activeInstance: FloatingPointerOverlay? = null
        private val lifecycleLock = Any()

        fun getActiveInstance(): FloatingPointerOverlay? = activeInstance

        fun checkOverlayPermission(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true
            }
        }

        fun requestOverlayPermission(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        }
    }

    /**
     * 6 Focused Remote Control Categories
     */
    enum class OverlaySection(val sectionId: Int, val title: String, val subtitle: String, val badge: String) {
        LIVE_AND_RECORD(0, "Live & Record", "Stream & Recording Control", "REC"),
        ROI_TARGET(1, "ROI Target", "Kill Feed Bounding Area", "ROI"),
        AUDIO_STUDIO(2, "Audio Studio", "Game, Mic & Music Mixer", "AUDIO"),
        MEDIA_STUDIO(3, "Media Studio", "Gallery Video & Memes", "MEDIA"),
        BROADCAST_GRAPHICS(4, "Broadcast Graphics", "HUD, Scoreboard & Cards", "GFX"),
        CHAT_STUDIO(5, "Chat Studio", "YouTube Live Chat", "CHAT")
    }

    // =========================================================================
    // IFloatingControlService Implementation
    // =========================================================================

    override fun showPointer() {
        showOverlay()
    }

    override fun hidePointer() {
        hideOverlay()
    }

    override fun setExpanded(expanded: Boolean) {
        synchronized(lifecycleLock) {
            if (expanded != isExpanded) {
                toggleExpand()
            }
        }
    }

    override fun setPointerSize(size: String) {
        synchronized(lifecycleLock) {
            pointerSizePreset = size
            prefs.edit().putString("pointer_size", size).apply()
            pointerBubbleView?.let { updateBubbleSize(it) }
            _controlState.value = _controlState.value.copy(pointerSize = size)
        }
    }

    override fun updatePosition(x: Int, y: Int) {
        synchronized(lifecycleLock) {
            windowParams?.let { params ->
                params.x = x
                params.y = y
                params.flags = params.flags or WindowManager.LayoutParams.FLAG_SECURE
                val container = overlayContainer
                if (isAttached && container != null && container.isAttachedToWindow) {
                    try {
                        windowManager.updateViewLayout(container, params)
                    } catch (e: Exception) {
                        Log.e("FloatingPointerOverlay", "Failed to update overlay position", e)
                    }
                }
            }
            _controlState.value = _controlState.value.copy(lastPositionX = x, lastPositionY = y)
        }
    }

    override fun recreate() {
        synchronized(lifecycleLock) {
            Log.d("FloatingPointerOverlay", "recreate requested")
            hideOverlay()
            showOverlay()
        }
    }

    fun updateStatus(status: String) {
        pointerStatusText?.text = status
    }

    // =========================================================================
    // Overlay Lifecycle
    // =========================================================================

    @SuppressLint("ClickableViewAccessibility")
    fun showOverlay(statusText: String = "LIVE") {
        synchronized(lifecycleLock) {
            Log.d("FloatingPointerOverlay", "showOverlay: isAttached=$isAttached")
            if (!checkOverlayPermission(context)) {
                Log.e("FloatingPointerOverlay", "Cannot show overlay: Draw overlay permission is NOT granted!")
                return
            }

            // Ensure this instance is the active one, dismissing others if necessary
            val oldInstance = activeInstance
            if (oldInstance != null && oldInstance != this) {
                Log.d("FloatingPointerOverlay", "Dismissing old active instance of overlay.")
                oldInstance.hideOverlay()
            }
            activeInstance = this

            // Check if existing container is already correctly attached
            val existingContainer = overlayContainer
            if (isAttached && existingContainer != null && existingContainer.isAttachedToWindow) {
                try {
                    existingContainer.visibility = View.VISIBLE
                    pointerBubbleView?.visibility = if (isExpanded) View.GONE else View.VISIBLE
                    expandedCardView?.visibility = if (isExpanded) View.VISIBLE else View.GONE
                    pointerStatusText?.text = statusText
                    _controlState.value = _controlState.value.copy(isVisible = true)
                    Log.d("FloatingPointerOverlay", "showOverlay: Already attached, restored visibility.")
                    return
                } catch (e: Exception) {
                    Log.e("FloatingPointerOverlay", "Failed to restore existing overlay view. Re-creating...", e)
                }
            }

            // If we're here, we need a fresh start for this instance
            hideOverlay()
            activeInstance = this // Restore as active after hideOverlay might have cleared it

            pointerSizePreset = prefs.getString("pointer_size", "SMALL") ?: "SMALL"
            val savedX = prefs.getInt("pointer_last_x", 100)
            val savedY = prefs.getInt("pointer_last_y", 300)

            val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            // FLAG_SECURE prevents operator UI from appearing in screen capture / MediaProjection
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_SECURE

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                flags,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = savedX
                y = savedY
            }
            windowParams = params

            val root = FrameLayout(context).apply {
                clipChildren = false
                clipToPadding = false
            }
            overlayContainer = root

            // 1. Collapsed Pointer Bubble
            val bubble = buildPointerBubble(statusText)
            pointerBubbleView = bubble
            root.addView(bubble)

            // 2. Expanded Card (Lazy shell; sections inflated only on tap)
            val card = buildExpandedCardShell()
            expandedCardView = card
            card.visibility = View.GONE
            root.addView(card)

            setupDragAndTouchListener(root, bubble, params)

            try {
                windowManager.addView(root, params)
                isAttached = true
                _controlState.value = _controlState.value.copy(
                    isVisible = true,
                    pointerSize = pointerSizePreset,
                    lastPositionX = savedX,
                    lastPositionY = savedY
                )
                startTelemetryUpdates()
                Log.d("FloatingPointerOverlay", "Successfully added overlay root view to WindowManager")
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "CRITICAL ERROR: Failed to add overlay view to WindowManager", e)
                isAttached = false
                overlayContainer = null
                activeInstance = null
            }
        }
    }

    fun hideOverlay() {
        synchronized(lifecycleLock) {
            Log.d("FloatingPointerOverlay", "hideOverlay called. isAttached=$isAttached")
            stopChatPolling()
            releaseCurrentSection()
            try {
                scope.coroutineContext.cancelChildren()
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Error canceling children coroutines during hideOverlay", e)
            }

            val container = overlayContainer
            if (container != null) {
                try {
                    if (container.isAttachedToWindow) {
                        windowManager.removeViewImmediate(container)
                        Log.d("FloatingPointerOverlay", "Successfully removed overlayContainer view from WindowManager")
                    }
                } catch (e: Exception) {
                    Log.e("FloatingPointerOverlay", "Error removing overlay container from WindowManager during hideOverlay", e)
                } finally {
                    overlayContainer = null
                }
            }

            pointerBubbleView = null
            expandedCardView = null
            categoryMenuContainer = null
            sectionContentContainer = null
            isAttached = false
            isExpanded = false

            if (activeInstance == this) {
                activeInstance = null
            }
            _controlState.value = _controlState.value.copy(isVisible = false, isExpanded = false)
        }
    }

    fun toggleExpand() {
        synchronized(lifecycleLock) {
            if (!isAttached || overlayContainer == null || overlayContainer?.isAttachedToWindow == false) {
                Log.w("FloatingPointerOverlay", "Cannot toggleExpand: Not correctly attached.")
                return
            }
            isExpanded = !isExpanded
            _controlState.value = _controlState.value.copy(isExpanded = isExpanded)

            if (isExpanded) {
                pointerBubbleView?.visibility = View.GONE
                expandedCardView?.visibility = View.VISIBLE
                showCategoryMenu()
            } else {
                releaseCurrentSection()
                expandedCardView?.visibility = View.GONE
                pointerBubbleView?.visibility = View.VISIBLE
            }
        }
    }

    fun onConfigurationChanged(newConfig: Configuration) {
        if (!isAttached) return
        overlayContainer?.post {
            ensureWithinScreenBounds()
        }
    }

    // =========================================================================
    // UI Construction (Lightweight Shell)
    // =========================================================================

    private fun buildPointerBubble(statusText: String): LinearLayout {
        val sizePx = getBubbleDimensionPx()
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(sizePx, sizePx)

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E60B1322"))
                setStroke(dpToPx(2f), Color.parseColor("#00E5FF"))
            }
            background = bg
            elevation = dpToPx(8f).toFloat()

            // Icon/Badge
            val title = TextView(context).apply {
                text = "MVP"
                setTextColor(Color.parseColor("#00E5FF"))
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }
            addView(title)

            // Status Indicator
            val status = TextView(context).apply {
                text = statusText
                setTextColor(Color.parseColor("#FF5252"))
                textSize = 8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }
            pointerStatusText = status
            addView(status)
        }
    }

    private fun updateBubbleSize(bubble: View) {
        val sizePx = getBubbleDimensionPx()
        bubble.layoutParams = FrameLayout.LayoutParams(sizePx, sizePx)
    }

    private fun getBubbleDimensionPx(): Int {
        return when (pointerSizePreset) {
            "MINI" -> dpToPx(42f)
            "MEDIUM" -> dpToPx(58f)
            "LARGE" -> dpToPx(68f)
            else -> dpToPx(50f)
        }
    }

    private fun buildExpandedCardShell(): LinearLayout {
        val cardWidth = dpToPx(340f)
        val cardHeight = dpToPx(480f)

        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(cardWidth, cardHeight)

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(14f).toFloat()
                setColor(Color.parseColor("#F2090F1D"))
                setStroke(dpToPx(1.5f), Color.parseColor("#00E5FF"))
            }
            background = bg
            elevation = dpToPx(12f).toFloat()
            clipChildren = true

            // --- Header Bar ---
            val header = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpToPx(12f), dpToPx(10f), dpToPx(12f), dpToPx(10f))
                setBackgroundColor(Color.parseColor("#B3040814"))

                // Back Button (shown inside sub-sections)
                val backBtn = TextView(context).apply {
                    text = "◀ MENU"
                    setTextColor(Color.parseColor("#00E5FF"))
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    visibility = View.GONE
                    setPadding(0, 0, dpToPx(10f), 0)
                    setOnClickListener { showCategoryMenu() }
                }
                backButtonView = backBtn
                addView(backBtn)

                // Header Title
                val title = TextView(context).apply {
                    text = "MVP CONTROL REMOTE"
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                headerTitleText = title
                addView(title)

                // Collapse Button
                val closeBtn = TextView(context).apply {
                    text = "MINIMIZE ▼"
                    setTextColor(Color.parseColor("#90A4AE"))
                    textSize = 10f
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(dpToPx(6f), dpToPx(2f), dpToPx(6f), dpToPx(2f))
                    setOnClickListener { toggleExpand() }
                }
                addView(closeBtn)
            }
            addView(header)

            // --- Main Content Area: Menu or Active Lazy Section ---
            val contentFrame = FrameLayout(context).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    1f
                )
            }
            sectionContentContainer = contentFrame

            // Category Menu Scroll View
            val menuScroll = ScrollView(context).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            }
            val menuList = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dpToPx(12f), dpToPx(12f), dpToPx(12f), dpToPx(12f))
            }
            categoryMenuContainer = menuList
            menuScroll.addView(menuList)
            contentFrame.addView(menuScroll)

            // Populate Category Menu
            OverlaySection.values().forEach { sec ->
                menuList.addView(buildCategoryMenuItem(sec) {
                    openSection(sec)
                })
            }

            addView(contentFrame)
        }
    }

    private fun buildCategoryMenuItem(section: OverlaySection, onClick: () -> Unit): View {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(12f), dpToPx(10f), dpToPx(12f), dpToPx(10f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8f)
            }

            val itemBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(8f).toFloat()
                setColor(Color.parseColor("#331E293B"))
                setStroke(dpToPx(1f), Color.parseColor("#3300E5FF"))
            }
            background = itemBg
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }

            // Badge
            val badge = TextView(context).apply {
                text = section.badge
                setTextColor(Color.parseColor("#00E5FF"))
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dpToPx(6f), dpToPx(3f), dpToPx(6f), dpToPx(3f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(4f).toFloat()
                    setColor(Color.parseColor("#2600E5FF"))
                }
            }
            addView(badge)

            // Title & Subtitle
            val textCol = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dpToPx(10f), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

                val t = TextView(context).apply {
                    text = section.title
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                }
                addView(t)

                val st = TextView(context).apply {
                    text = section.subtitle
                    setTextColor(Color.parseColor("#90A4AE"))
                    textSize = 10f
                }
                addView(st)
            }
            addView(textCol)

            // Chevron
            val chevron = TextView(context).apply {
                text = "▶"
                setTextColor(Color.parseColor("#00E5FF"))
                textSize = 11f
            }
            addView(chevron)
        }
    }

    // =========================================================================
    // Lazy Section Loading Architecture
    // =========================================================================

    private fun showCategoryMenu() {
        releaseCurrentSection()
        currentSection = null
        headerTitleText?.text = "MVP CONTROL REMOTE"
        backButtonView?.visibility = View.GONE
        categoryMenuContainer?.parent?.let { parent ->
            (parent as? View)?.visibility = View.VISIBLE
        }
    }

    private fun openSection(section: OverlaySection) {
        releaseCurrentSection()
        currentSection = section
        headerTitleText?.text = section.title.uppercase()
        backButtonView?.visibility = View.VISIBLE

        categoryMenuContainer?.parent?.let { parent ->
            (parent as? View)?.visibility = View.GONE
        }

        val sectionView = createSectionView(section)
        activeSectionView = sectionView
        sectionContentContainer?.addView(sectionView)

        if (section == OverlaySection.CHAT_STUDIO) {
            startChatPolling()
        }
    }

    private fun releaseCurrentSection() {
        stopChatPolling()
        chatMessagesLayout = null
        activeSectionView?.let { view ->
            sectionContentContainer?.removeView(view)
            if (view is LinearLayout) {
                view.removeAllViews()
            }
        }
        activeSectionView = null
    }

    private fun createSectionView(section: OverlaySection): View {
        val scroll = ScrollView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(14f), dpToPx(12f), dpToPx(14f), dpToPx(16f))
        }
        scroll.addView(content)

        when (section) {
            OverlaySection.LIVE_AND_RECORD -> populateLiveAndRecordSection(content)
            OverlaySection.ROI_TARGET -> populateRoiTargetSection(content)
            OverlaySection.AUDIO_STUDIO -> populateAudioStudioSection(content)
            OverlaySection.MEDIA_STUDIO -> populateMediaStudioSection(content)
            OverlaySection.BROADCAST_GRAPHICS -> populateBroadcastGraphicsSection(content)
            OverlaySection.CHAT_STUDIO -> populateChatStudioSection(content)
        }

        return scroll
    }

    // =========================================================================
    // 1. LIVE & RECORD CONTROLS
    // =========================================================================

    private fun populateLiveAndRecordSection(container: LinearLayout) {
        // --- Live Stream Section ---
        container.addView(buildSectionHeader("YOUTUBE LIVE BROADCAST"))

        val liveState = BroadcastController.getInstance(context).broadcastState.value
        val liveStatusText = TextView(context).apply {
            text = "Status: ${liveState.name}"
            setTextColor(if (liveState == BroadcastLifecycleState.LIVE) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dpToPx(8f))
        }
        container.addView(liveStatusText)

        val liveButtonsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            val startBtn = buildActionButton("START LIVE", Color.parseColor("#00C853"), 1f) {
                scope.launch {
                    val res = BroadcastController.getInstance(context).startBroadcast()
                    liveStatusText.text = if (res.isSuccess) "Status: LIVE" else "Error: ${res.exceptionOrNull()?.message ?: "Failed"}"
                    liveStatusText.setTextColor(if (res.isSuccess) Color.parseColor("#00E676") else Color.parseColor("#FF5252"))
                }
            }
            addView(startBtn)

            val pauseBtn = buildActionButton("PAUSE", Color.parseColor("#FFD600"), 1f) {
                scope.launch {
                    val current = BroadcastController.getInstance(context).broadcastState.value
                    if (current == BroadcastLifecycleState.LIVE) {
                        BroadcastController.getInstance(context).pauseBroadcast()
                        liveStatusText.text = "Status: PAUSED"
                        liveStatusText.setTextColor(Color.parseColor("#FFD600"))
                    } else if (current == BroadcastLifecycleState.PAUSED) {
                        val res = BroadcastController.getInstance(context).resumeBroadcast()
                        liveStatusText.text = if (res.isSuccess) "Status: LIVE" else "Error: ${res.exceptionOrNull()?.message ?: "Failed"}"
                        liveStatusText.setTextColor(if (res.isSuccess) Color.parseColor("#00E676") else Color.parseColor("#FF5252"))
                    }
                }
            }
            addView(pauseBtn)

            val stopBtn = buildActionButton("STOP", Color.parseColor("#D50000"), 1f) {
                BroadcastController.getInstance(context).stopBroadcast()
                liveStatusText.text = "Status: IDLE (OFF AIR)"
                liveStatusText.setTextColor(Color.parseColor("#90A4AE"))
                onStopSessionRequested?.invoke()
            }
            addView(stopBtn)
        }
        container.addView(liveButtonsRow)

        container.addView(buildDivider())

        // --- Screen Recorder Section ---
        container.addView(buildSectionHeader("LOCAL SCREEN RECORDER"))

        val isRecording = StationDeskManager.stationState.value.isRecording
        val recStatusText = TextView(context).apply {
            text = if (isRecording) "Recording Active (MP4)" else "Recorder Idle"
            setTextColor(if (isRecording) Color.parseColor("#FF5252") else Color.parseColor("#90A4AE"))
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dpToPx(8f))
        }
        container.addView(recStatusText)

        val recButtonsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            val startRec = buildActionButton("START RECORDER", Color.parseColor("#00E5FF"), 1f) {
                val res = StationDeskManager.startRecordingFromStation(context)
                if (res.isSuccess) {
                    recStatusText.text = "Recording Active (MP4)"
                    recStatusText.setTextColor(Color.parseColor("#FF5252"))
                } else {
                    recStatusText.text = "Error: ${res.exceptionOrNull()?.message}"
                }
            }
            addView(startRec)

            val stopRec = buildActionButton("STOP RECORDER", Color.parseColor("#D50000"), 1f) {
                val res = StationDeskManager.stopRecordingFromStation()
                recStatusText.text = if (res.isSuccess) "Recording Saved to Movies/MVP-Esports" else "Stopped"
                recStatusText.setTextColor(Color.parseColor("#00E676"))
            }
            addView(stopRec)
        }
        container.addView(recButtonsRow)
    }

    // =========================================================================
    // 2. ROI TARGET CONTROLS
    // =========================================================================

    private fun populateRoiTargetSection(container: LinearLayout) {
        container.addView(buildSectionHeader("OCR KILL FEED ROI CONFIGURATION"))

        val explanation = TextView(context).apply {
            text = "Enabling ROI selection places a temporary touch adjustment box on your phone display. The selection box is excluded from YouTube and MP4 recordings."
            setTextColor(Color.parseColor("#90A4AE"))
            textSize = 10f
            setPadding(0, 0, 0, dpToPx(12f))
        }
        container.addView(explanation)

        val currentRoi = InMemoryRoiConfigurationService.getInstance().selectedRoi.value ?: RoiRegion.DEFAULT_KILL_FEED
        val coordsText = TextView(context).apply {
            text = "Active Kill Feed ROI Area:\nLeft: ${(currentRoi.x * 100).toInt()}%  Top: ${(currentRoi.y * 100).toInt()}%\nWidth: ${(currentRoi.width * 100).toInt()}%  Height: ${(currentRoi.height * 100).toInt()}%"
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setPadding(dpToPx(10f), dpToPx(8f), dpToPx(10f), dpToPx(8f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(6f).toFloat()
                setColor(Color.parseColor("#2600E5FF"))
            }
        }
        container.addView(coordsText)

        val spacer = View(context).apply { layoutParams = LinearLayout.LayoutParams(1, dpToPx(12f)) }
        container.addView(spacer)

        val enableRoiBtn = buildActionButton("ENABLE ON-SCREEN ROI SELECTION", Color.parseColor("#00E5FF"), 0f) {
            FloatingRoiScreenCropper.startEdit(context)
            coordsText.text = "On-Screen ROI Selection: ACTIVE\nDrag corners on your screen to fit kill feed."
            coordsText.setTextColor(Color.parseColor("#00E676"))
        }
        container.addView(enableRoiBtn)

        val saveRoiBtn = buildActionButton("SAVE & CLOSE ROI SELECTION", Color.parseColor("#00C853"), 0f) {
            FloatingRoiScreenCropper.saveAndHide()
            val updated = InMemoryRoiConfigurationService.getInstance().selectedRoi.value ?: RoiRegion.DEFAULT_KILL_FEED
            coordsText.text = "Saved ROI Area:\nLeft: ${(updated.x * 100).toInt()}%  Top: ${(updated.y * 100).toInt()}%\nWidth: ${(updated.width * 100).toInt()}%  Height: ${(updated.height * 100).toInt()}%"
            coordsText.setTextColor(Color.WHITE)
        }
        container.addView(saveRoiBtn)

        val resetRoiBtn = buildActionButton("RESET TO DEFAULT KILL FEED", Color.parseColor("#37474F"), 0f) {
            FloatingRoiScreenCropper.stopEdit()
            InMemoryRoiConfigurationService.getInstance().selectRoi(RoiRegion.DEFAULT_KILL_FEED.id)
            val updated = RoiRegion.DEFAULT_KILL_FEED
            coordsText.text = "Default Kill Feed Area:\nLeft: ${(updated.x * 100).toInt()}%  Top: ${(updated.y * 100).toInt()}%\nWidth: ${(updated.width * 100).toInt()}%  Height: ${(updated.height * 100).toInt()}%"
        }
        container.addView(resetRoiBtn)
    }

    // =========================================================================
    // 3. AUDIO STUDIO CONTROLS
    // =========================================================================

    private fun populateAudioStudioSection(container: LinearLayout) {
        val audioState = AudioMixerManager.mixerState.value
        val musicState = LocalMusicPlayerManager.musicState.value

        // Game Audio
        container.addView(buildSectionHeader("INTERNAL GAME AUDIO"))
        container.addView(buildAudioChannelRow(
            label = "Game Audio",
            isMuted = audioState.gameMuted,
            volume = audioState.gameVolume,
            onToggleMute = { AudioMixerManager.toggleGameMute() },
            onVolumeChanged = { AudioMixerManager.setGameVolume(it) }
        ))

        container.addView(buildDivider())

        // Microphone
        container.addView(buildSectionHeader("OPERATOR MICROPHONE"))
        container.addView(buildAudioChannelRow(
            label = "Microphone",
            isMuted = audioState.micMuted,
            volume = audioState.micVolume,
            onToggleMute = { AudioMixerManager.toggleMicMute() },
            onVolumeChanged = { AudioMixerManager.setMicVolume(it) }
        ))

        container.addView(buildDivider())

        // Background Music
        container.addView(buildSectionHeader("LOCAL MUSIC PLAYER"))
        container.addView(buildAudioChannelRow(
            label = "Music Track",
            isMuted = audioState.musicMuted,
            volume = audioState.musicVolume,
            onToggleMute = { AudioMixerManager.toggleMusicMute() },
            onVolumeChanged = { AudioMixerManager.setMusicVolume(it) }
        ))

        // Music Details & Loop
        val songNameText = TextView(context).apply {
            text = "Track: ${musicState.songTitle}"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 10f
            setPadding(0, dpToPx(6f), 0, dpToPx(6f))
        }
        container.addView(songNameText)

        val musicActionRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            val selectMusicBtn = buildActionButton("SELECT FROM GALLERY", Color.parseColor("#00E5FF"), 1.2f) {
                LocalAudioPickerActivity.launch(context)
            }
            addView(selectMusicBtn)

            val loopBtn = buildActionButton(if (musicState.isLooping) "LOOP: ON" else "LOOP: OFF", Color.parseColor("#1E293B"), 0.8f) {
                LocalMusicPlayerManager.toggleLoop()
                val updatedLoop = LocalMusicPlayerManager.musicState.value.isLooping
                (this as? Button)?.text = if (updatedLoop) "LOOP: ON" else "LOOP: OFF"
            }
            addView(loopBtn)
        }
        container.addView(musicActionRow)
    }

    private fun buildAudioChannelRow(
        label: String,
        isMuted: Boolean,
        volume: Float,
        onToggleMute: () -> Unit,
        onVolumeChanged: (Float) -> Unit
    ): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dpToPx(4f), 0, dpToPx(4f))

            val muteBtn = Button(context).apply {
                text = if (isMuted) "MUTED" else "ON"
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (isMuted) Color.parseColor("#FF5252") else Color.parseColor("#00E676"))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(4f).toFloat()
                    setColor(Color.parseColor("#1E293B"))
                    setStroke(dpToPx(1f), if (isMuted) Color.parseColor("#FF5252") else Color.parseColor("#00E676"))
                }
                layoutParams = LinearLayout.LayoutParams(dpToPx(56f), dpToPx(32f))
                setOnClickListener {
                    onToggleMute()
                    val newAudio = AudioMixerManager.mixerState.value
                    val mutedNow = if (label.contains("Game")) newAudio.gameMuted else if (label.contains("Mic")) newAudio.micMuted else newAudio.musicMuted
                    text = if (mutedNow) "MUTED" else "ON"
                    setTextColor(if (mutedNow) Color.parseColor("#FF5252") else Color.parseColor("#00E676"))
                }
            }
            addView(muteBtn)

            val bar = SeekBar(context).apply {
                max = 100
                progress = (volume * 100).toInt()
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dpToPx(8f)
                    marginEnd = dpToPx(8f)
                }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                        if (fromUser) onVolumeChanged(prog / 100f)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }
            addView(bar)

            val valText = TextView(context).apply {
                text = "${(volume * 100).toInt()}%"
                setTextColor(Color.WHITE)
                textSize = 10f
                typeface = Typeface.MONOSPACE
                layoutParams = LinearLayout.LayoutParams(dpToPx(36f), LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            addView(valText)
        }
    }

    // =========================================================================
    // 4. MEDIA STUDIO CONTROLS
    // =========================================================================

    private fun populateMediaStudioSection(container: LinearLayout) {
        val controls = StandingTableControlsManager.controlsState.value

        container.addView(buildSectionHeader("GALLERY VIDEO & MEME OVERLAYS"))

        // Video selection
        val videoStatus = TextView(context).apply {
            text = if (controls.tickerLoopVideoEnabled) "Video Overlay: ENABLED" else "Video Overlay: DISABLED"
            setTextColor(if (controls.tickerLoopVideoEnabled) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dpToPx(6f))
        }
        container.addView(videoStatus)

        val videoRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            val pickVideoBtn = buildActionButton("SELECT VIDEO", Color.parseColor("#00E5FF"), 1f) {
                LocalVideoPickerActivity.launch(context)
            }
            addView(pickVideoBtn)

            val toggleVideoBtn = buildActionButton(if (controls.tickerLoopVideoEnabled) "VIDEO: ON" else "VIDEO: OFF", Color.parseColor("#1E293B"), 1f) {
                val current = StandingTableControlsManager.controlsState.value
                val newEnabled = !current.tickerLoopVideoEnabled
                StandingTableControlsManager.setTickerLoopVideo(current.tickerLoopVideoUri, newEnabled)
                (this as? Button)?.text = if (newEnabled) "VIDEO: ON" else "VIDEO: OFF"
                videoStatus.text = if (newEnabled) "Video Overlay: ENABLED" else "Video Overlay: DISABLED"
                videoStatus.setTextColor(if (newEnabled) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
            }
            addView(toggleVideoBtn)
        }
        container.addView(videoRow)

        container.addView(buildDivider())

        // Meme selection
        container.addView(buildSectionHeader("FUNNY MEME / REACTION OVERLAY"))

        val memeStatus = TextView(context).apply {
            text = if (controls.memeOverlayEnabled) "Meme Overlay: ENABLED" else "Meme Overlay: DISABLED"
            setTextColor(if (controls.memeOverlayEnabled) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dpToPx(6f))
        }
        container.addView(memeStatus)

        val memeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            val pickMemeBtn = buildActionButton("SELECT MEME", Color.parseColor("#00E5FF"), 1f) {
                LocalVideoPickerActivity.launch(context)
            }
            addView(pickMemeBtn)

            val toggleMemeBtn = buildActionButton(if (controls.memeOverlayEnabled) "MEME: ON" else "MEME: OFF", Color.parseColor("#1E293B"), 1f) {
                val current = StandingTableControlsManager.controlsState.value
                val newEnabled = !current.memeOverlayEnabled
                StandingTableControlsManager.setMemeOverlay(current.memeOverlayUri, newEnabled)
                (this as? Button)?.text = if (newEnabled) "MEME: ON" else "MEME: OFF"
                memeStatus.text = if (newEnabled) "Meme Overlay: ENABLED" else "Meme Overlay: DISABLED"
                memeStatus.setTextColor(if (newEnabled) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
            }
            addView(toggleMemeBtn)
        }
        container.addView(memeRow)

        container.addView(buildDivider())

        // Clear all media
        val clearBtn = buildActionButton("CLEAR ALL OVERLAY MEDIA", Color.parseColor("#D50000"), 0f) {
            StandingTableControlsManager.setTickerLoopVideo(null, false)
            StandingTableControlsManager.setMemeOverlay(null, false)
            videoStatus.text = "Video Overlay: DISABLED"
            videoStatus.setTextColor(Color.parseColor("#90A4AE"))
            memeStatus.text = "Meme Overlay: DISABLED"
            memeStatus.setTextColor(Color.parseColor("#90A4AE"))
        }
        container.addView(clearBtn)
    }

    // =========================================================================
    // 5. BROADCAST GRAPHICS CONTROLS
    // =========================================================================

    private fun populateBroadcastGraphicsSection(container: LinearLayout) {
        val controls = StandingTableControlsManager.controlsState.value

        container.addView(buildSectionHeader("HUD & GRAPHIC LAYERS"))

        // Overall Table (Scoreboard) Toggle
        container.addView(buildToggleRow("Scoreboard Table", controls.scoreboardEnabled) {
            StandingTableControlsManager.toggleScoreboard()
        })

        // Bottom Bar (Ticker) Toggle
        container.addView(buildToggleRow("Bottom Ticker Bar", controls.bottomTickerEnabled) {
            StandingTableControlsManager.toggleBottomTicker()
        })

        // VIP / Milestone Card Toggle
        container.addView(buildToggleRow("MVP Milestone Card", controls.milestoneCardEnabled) {
            StandingTableControlsManager.toggleMilestoneCard()
        })

        // Custom Overlay Toggle
        container.addView(buildToggleRow("Custom Graphic Overlay", controls.customGraphicsEnabled) {
            StandingTableControlsManager.toggleCustomGraphics()
        })

        // Logo Overlay Toggle
        container.addView(buildToggleRow("Tournament Logo", controls.logoOverlayEnabled) {
            StandingTableControlsManager.toggleLogoOverlay()
        })

        container.addView(buildDivider())

        // Positioning and Resizing Controls
        container.addView(buildSectionHeader("OVERLAY POSITION & SIZE"))

        // Table Position Cycle
        val positions = listOf("Top Right", "Top Left", "Bottom Right", "Bottom Left")
        val posBtn = buildActionButton("TABLE POS: ${controls.standingPosition}", Color.parseColor("#1E293B"), 0f) {
            val currentPos = StandingTableControlsManager.controlsState.value.standingPosition
            val nextIdx = (positions.indexOf(currentPos) + 1).let { if (it < 0 || it >= positions.size) 0 else it }
            val nextPos = positions[nextIdx]
            StandingTableControlsManager.setStandingPosition(nextPos)
            (this as? Button)?.text = "TABLE POS: $nextPos"
        }
        container.addView(posBtn)

        // Table Size Cycle
        val sizes = listOf("Small", "Medium", "Large")
        val sizeBtn = buildActionButton("TABLE SIZE: ${controls.standingSize}", Color.parseColor("#1E293B"), 0f) {
            val currentSize = StandingTableControlsManager.controlsState.value.standingSize
            val nextIdx = (sizes.indexOf(currentSize) + 1).let { if (it < 0 || it >= sizes.size) 0 else it }
            val nextSize = sizes[nextIdx]
            StandingTableControlsManager.setStandingSize(nextSize)
            (this as? Button)?.text = "TABLE SIZE: $nextSize"
        }
        container.addView(sizeBtn)

        // Meme Position Cycle
        val memePositions = listOf("Bottom Right", "Bottom Left", "Top Right", "Top Left")
        val memePosBtn = buildActionButton("MEME POS: ${controls.memePosition}", Color.parseColor("#1E293B"), 0f) {
            val currentPos = StandingTableControlsManager.controlsState.value.memePosition
            val nextIdx = (memePositions.indexOf(currentPos) + 1).let { if (it < 0 || it >= memePositions.size) 0 else it }
            val nextPos = memePositions[nextIdx]
            StandingTableControlsManager.setMemePosition(nextPos)
            (this as? Button)?.text = "MEME POS: $nextPos"
        }
        container.addView(memePosBtn)
    }

    private fun buildToggleRow(title: String, initialChecked: Boolean, onToggle: () -> Unit): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dpToPx(6f), 0, dpToPx(6f))

            val t = TextView(context).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 11f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            addView(t)

            val toggleBtn = Button(context).apply {
                var isChecked = initialChecked
                text = if (isChecked) "ON" else "OFF"
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (isChecked) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(4f).toFloat()
                    setColor(Color.parseColor("#1E293B"))
                    setStroke(dpToPx(1f), if (isChecked) Color.parseColor("#00E676") else Color.parseColor("#3300E5FF"))
                }
                layoutParams = LinearLayout.LayoutParams(dpToPx(52f), dpToPx(30f))
                setOnClickListener {
                    onToggle()
                    isChecked = !isChecked
                    text = if (isChecked) "ON" else "OFF"
                    setTextColor(if (isChecked) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
                    (background as? GradientDrawable)?.setStroke(
                        dpToPx(1f),
                        if (isChecked) Color.parseColor("#00E676") else Color.parseColor("#3300E5FF")
                    )
                }
            }
            addView(toggleBtn)
        }
    }

    // =========================================================================
    // 6. YOUTUBE LIVE CHAT CONTROLS
    // =========================================================================

    private fun populateChatStudioSection(container: LinearLayout) {
        container.addView(buildSectionHeader("LIVE CHAT STREAM"))

        // Chat messages box
        val messagesScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(180f)
            )
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(6f).toFloat()
                setColor(Color.parseColor("#26000000"))
                setStroke(dpToPx(1f), Color.parseColor("#3300E5FF"))
            }
            setPadding(dpToPx(8f), dpToPx(8f), dpToPx(8f), dpToPx(8f))
        }

        val messagesList = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }
        chatMessagesLayout = messagesList
        messagesScroll.addView(messagesList)
        container.addView(messagesScroll)

        val placeholder = TextView(context).apply {
            text = "Monitoring YouTube Live Chat...\nMessages will appear here in real-time."
            setTextColor(Color.parseColor("#90A4AE"))
            textSize = 10f
        }
        messagesList.addView(placeholder)

        val spacer = View(context).apply { layoutParams = LinearLayout.LayoutParams(1, dpToPx(8f)) }
        container.addView(spacer)

        // Chat Input & Send Row
        val inputRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            val input = EditText(context).apply {
                hint = "Send chat message..."
                setHintTextColor(Color.parseColor("#546E7A"))
                setTextColor(Color.WHITE)
                textSize = 11f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6f).toFloat()
                    setColor(Color.parseColor("#1E293B"))
                    setStroke(dpToPx(1f), Color.parseColor("#3300E5FF"))
                }
                setPadding(dpToPx(10f), dpToPx(8f), dpToPx(10f), dpToPx(8f))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            addView(input)

            val sendBtn = Button(context).apply {
                text = "SEND"
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.BLACK)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpToPx(6f).toFloat()
                    setColor(Color.parseColor("#00E5FF"))
                }
                layoutParams = LinearLayout.LayoutParams(dpToPx(64f), dpToPx(36f)).apply {
                    marginStart = dpToPx(6f)
                }
                setOnClickListener {
                    val msg = input.text.toString().trim()
                    if (msg.isNotEmpty() && !isSendingChat) {
                        isSendingChat = true
                        scope.launch {
                            try {
                                val ytService = YouTubeLiveService.getInstance(context)
                                val broadcastId = ytService.currentBroadcast.value?.broadcastId
                                if (broadcastId != null) {
                                    val chatId = ytService.getLiveChatId(broadcastId).getOrNull()
                                    if (chatId != null) {
                                        ytService.sendLiveChatMessage(chatId, msg)
                                    }
                                }
                                input.setText("")
                                val newRow = TextView(context).apply {
                                    text = "Operator: $msg"
                                    setTextColor(Color.parseColor("#00E676"))
                                    textSize = 10f
                                }
                                messagesList.addView(newRow)
                            } catch (e: Exception) {
                                Log.e("FloatingPointerOverlay", "Failed to send live chat message", e)
                            }
                            isSendingChat = false
                        }
                    }
                }
            }
            addView(sendBtn)
        }
        container.addView(inputRow)
    }

    private fun startChatPolling() {
        stopChatPolling()
        val runnable = object : Runnable {
            override fun run() {
                if (currentSection == OverlaySection.CHAT_STUDIO) {
                    pollChatMessages()
                    mainHandler.postDelayed(this, 4000)
                }
            }
        }
        chatPollingRunnable = runnable
        mainHandler.post(runnable)
    }

    private fun stopChatPolling() {
        chatPollingRunnable?.let {
            mainHandler.removeCallbacks(it)
            chatPollingRunnable = null
        }
    }

    private fun pollChatMessages() {
        scope.launch {
            try {
                val ytService = YouTubeLiveService.getInstance(context)
                val broadcastId = ytService.currentBroadcast.value?.broadcastId ?: return@launch
                val chatId = ytService.getLiveChatId(broadcastId).getOrNull() ?: return@launch
                val messages = ytService.fetchLiveChatMessages(chatId).getOrNull() ?: return@launch
                
                chatMessagesLayout?.let { list ->
                    list.removeAllViews()
                    if (messages.isEmpty()) {
                        val emptyText = TextView(context).apply {
                            text = "No recent messages in live chat."
                            setTextColor(Color.parseColor("#90A4AE"))
                            textSize = 10f
                        }
                        list.addView(emptyText)
                    } else {
                        messages.takeLast(10).forEach { item ->
                            val row = TextView(context).apply {
                                text = "${item.authorName}: ${item.messageText}"
                                setTextColor(if (item.isOwner || item.isModerator) Color.parseColor("#00E5FF") else Color.WHITE)
                                textSize = 10f
                                setPadding(0, dpToPx(1f), 0, dpToPx(1f))
                            }
                            list.addView(row)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Error polling live chat messages", e)
            }
        }
    }

    // =========================================================================
    // Telemetry & Periodic Sync (Lightweight, 1Hz)
    // =========================================================================

    private fun startTelemetryUpdates() {
        scope.launch {
            while (isActive) {
                delay(1000)
                if (isAttached) {
                    val isRec = StationDeskManager.stationState.value.isRecording
                    val isLive = BroadcastController.getInstance(context).broadcastState.value == BroadcastLifecycleState.LIVE
                    pointerStatusText?.text = if (isRec) "REC" else if (isLive) "LIVE" else "IDLE"
                    pointerStatusText?.setTextColor(if (isRec) Color.parseColor("#FF5252") else if (isLive) Color.parseColor("#00E676") else Color.parseColor("#90A4AE"))
                }
            }
        }
    }

    // =========================================================================
    // UI Helper Builders
    // =========================================================================

    private fun buildSectionHeader(title: String): TextView {
        return TextView(context).apply {
            text = title
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dpToPx(4f), 0, dpToPx(8f))
        }
    }

    private fun buildDivider(): View {
        return View(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(1f)
            ).apply {
                topMargin = dpToPx(12f)
                bottomMargin = dpToPx(12f)
            }
            setBackgroundColor(Color.parseColor("#1E293B"))
        }
    }

    private fun buildActionButton(
        text: String,
        color: Int,
        weight: Float,
        onClick: View.() -> Unit
    ): Button {
        return Button(context).apply {
            this.text = text
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(6f).toFloat()
                setColor(color)
            }
            layoutParams = if (weight > 0f) {
                LinearLayout.LayoutParams(0, dpToPx(38f), weight).apply {
                    marginStart = dpToPx(4f)
                    marginEnd = dpToPx(4f)
                }
            } else {
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(38f)).apply {
                    topMargin = dpToPx(4f)
                    bottomMargin = dpToPx(4f)
                }
            }
            setOnClickListener { onClick() }
        }
    }

    // =========================================================================
    // Touch & Drag Handling
    // =========================================================================

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragAndTouchListener(root: View, bubble: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isMoving = false

        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isMoving = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > dpToPx(6f) || Math.abs(dy) > dpToPx(6f)) {
                        isMoving = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        synchronized(lifecycleLock) {
                            val container = overlayContainer
                            if (isAttached && container != null && container.isAttachedToWindow) {
                                try {
                                    windowManager.updateViewLayout(container, params)
                                } catch (e: Exception) {
                                    Log.e("FloatingPointerOverlay", "Failed to update overlay position during drag", e)
                                }
                            }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isMoving) {
                        toggleExpand()
                    } else {
                        prefs.edit()
                            .putInt("pointer_last_x", params.x)
                            .putInt("pointer_last_y", params.y)
                            .apply()
                        ensureWithinScreenBounds()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun ensureWithinScreenBounds() {
        val displayMetrics = context.resources.displayMetrics
        synchronized(lifecycleLock) {
            windowParams?.let { params ->
                params.x = params.x.coerceIn(0, displayMetrics.widthPixels - dpToPx(50f))
                params.y = params.y.coerceIn(0, displayMetrics.heightPixels - dpToPx(50f))
                val container = overlayContainer
                if (isAttached && container != null && container.isAttachedToWindow) {
                    try {
                        windowManager.updateViewLayout(container, params)
                    } catch (e: Exception) {
                        Log.e("FloatingPointerOverlay", "Failed to update overlay bounds", e)
                    }
                }
            }
        }
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            context.resources.displayMetrics
        ).toInt()
    }
}
