package com.example.services.audio

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Real-time PCM Mixer that combines three independent sources of 16-bit PCM audio:
 * 1. Microphone (Mono or Stereo 16-bit PCM)
 * 2. Internal Device / Game Audio (Stereo 16-bit PCM)
 * 3. Music Audio (Stereo 16-bit PCM)
 * Handles independent volume control, muting, channel upmixing, frame alignment, and anti-clipping saturation.
 */
object PcmMixer {

    /**
     * Mixes three PCM buffers using explicit valid byte lengths into an existing output buffer
     * to prevent per-frame intermediate allocations.
     * @return Number of mixed bytes written to outputPcm.
     */
    fun mix(
        micPcm: ByteArray?,
        micLen: Int,
        micVol: Float,
        micMuted: Boolean,
        gamePcm: ByteArray?,
        gameLen: Int,
        gameVol: Float,
        gameMuted: Boolean,
        musicPcm: ByteArray?,
        musicLen: Int,
        musicVol: Float,
        musicMuted: Boolean,
        outputPcm: ByteArray
    ): Int {
        val micGain = if (micMuted) 0f else micVol.coerceIn(0f, 1f)
        val gameGain = if (gameMuted) 0f else gameVol.coerceIn(0f, 1f)
        val musicGain = if (musicMuted) 0f else musicVol.coerceIn(0f, 1f)

        val validMicLen = if (micPcm != null) micLen.coerceIn(0, micPcm.size) else 0
        val validGameLen = if (gamePcm != null) gameLen.coerceIn(0, gamePcm.size) else 0
        val validMusicLen = if (musicPcm != null) musicLen.coerceIn(0, musicPcm.size) else 0

        // Mic is typically mono (2 bytes per sample frame). Game & Music are stereo (4 bytes per sample frame).
        val micFrames = validMicLen / 2
        val gameFrames = validGameLen / 4
        val musicFrames = validMusicLen / 4

        val maxFrames = maxOf(micFrames, maxOf(gameFrames, musicFrames))
        if (maxFrames == 0) return 0

        val requiredBytes = maxFrames * 4
        if (outputPcm.size < requiredBytes) {
            return 0 // Buffer too small, safer to skip than crash
        }

        for (f in 0 until maxFrames) {
            // 1. Mic sample (mono -> expand to Left and Right channels)
            var micLeft = 0
            var micRight = 0
            if (micPcm != null && micGain > 0f) {
                val byteIdx = f * 2
                if (byteIdx + 1 < validMicLen) {
                    val sample = ((micPcm[byteIdx + 1].toInt() shl 8) or (micPcm[byteIdx].toInt() and 0xFF)).toShort().toInt()
                    micLeft = sample
                    micRight = sample
                } else if (validMicLen >= 2) {
                    val sample = ((micPcm[validMicLen - 1].toInt() shl 8) or (micPcm[validMicLen - 2].toInt() and 0xFF)).toShort().toInt()
                    micLeft = sample
                    micRight = sample
                }
            }

            // 2. Game sample (stereo: 4 bytes per frame -> Left and Right channels)
            var gameLeft = 0
            var gameRight = 0
            if (gamePcm != null && gameGain > 0f) {
                val byteIdx = f * 4
                if (byteIdx + 3 < validGameLen) {
                    gameLeft = ((gamePcm[byteIdx + 1].toInt() shl 8) or (gamePcm[byteIdx].toInt() and 0xFF)).toShort().toInt()
                    gameRight = ((gamePcm[byteIdx + 3].toInt() shl 8) or (gamePcm[byteIdx + 2].toInt() and 0xFF)).toShort().toInt()
                }
            }

            // 3. Music sample (stereo: 4 bytes per frame -> Left and Right channels)
            var musicLeft = 0
            var musicRight = 0
            if (musicPcm != null && musicGain > 0f) {
                val byteIdx = f * 4
                if (byteIdx + 3 < validMusicLen) {
                    musicLeft = ((musicPcm[byteIdx + 1].toInt() shl 8) or (musicPcm[byteIdx].toInt() and 0xFF)).toShort().toInt()
                    musicRight = ((musicPcm[byteIdx + 3].toInt() shl 8) or (musicPcm[byteIdx + 2].toInt() and 0xFF)).toShort().toInt()
                }
            }

            // Mix Left channel with independent volume gains and anti-clipping saturation
            val mixedLeft = (micLeft * micGain + gameLeft * gameGain + musicLeft * musicGain)
                .toInt()
                .coerceIn(-32768, 32767)

            // Mix Right channel with independent volume gains and anti-clipping saturation
            val mixedRight = (micRight * micGain + gameRight * gameGain + musicRight * musicGain)
                .toInt()
                .coerceIn(-32768, 32767)

            val outIdx = f * 4
            // Write Left (2 bytes)
            outputPcm[outIdx] = (mixedLeft and 0xFF).toByte()
            outputPcm[outIdx + 1] = ((mixedLeft shr 8) and 0xFF).toByte()
            // Write Right (2 bytes)
            outputPcm[outIdx + 2] = (mixedRight and 0xFF).toByte()
            outputPcm[outIdx + 3] = ((mixedRight shr 8) and 0xFF).toByte()
        }

        return requiredBytes
    }
}

