package com.example.services.streaming

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Secure token manager using Android KeyStore + AES-256 GCM encryption.
 * Ensures YouTube OAuth access/refresh tokens are never stored in plain text or hardcoded.
 * Fails safely without unencrypted fallback if secure hardware encryption is unavailable.
 */
class SecureTokenStore(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "SecureTokenStore"
        const val PREF_NAME = "mvp_esports_secure_tokens"
        const val KEY_ACCESS_TOKEN = "yt_access_token"
        const val KEY_REFRESH_TOKEN = "yt_refresh_token"
        const val KEY_TOKEN_EXPIRY = "yt_token_expiry"
        const val KEY_CHANNEL_TITLE = "yt_channel_title"
        const val KEY_CHANNEL_ID = "yt_channel_id"

        private const val KEY_ALIAS = "MvpEsportsYouTubeSecretKey"
        private const val ANDROID_KEY_STORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_LENGTH_BYTES = 12
        private const val GCM_TAG_LENGTH_BITS = 128
    }

    init {
        initKeyStore()
    }

    private fun initKeyStore() {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
            if (!keyStore.containsAlias(KEY_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE)
                val keyGenParameterSpec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()

                keyGenerator.init(keyGenParameterSpec)
                keyGenerator.generateKey()
            }
        } catch (e: Exception) {
            Log.w(TAG, "KeyStore initialization failed: ${e.message}")
        }
    }

    fun isSecureStorageAvailable(): Boolean {
        return getSecretKey() != null
    }

    private fun getSecretKey(): SecretKey? {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEY_STORE).apply { load(null) }
            val entry = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            entry?.secretKey
        } catch (e: Exception) {
            Log.w(TAG, "Failed to retrieve SecretKey from KeyStore: ${e.message}")
            null
        }
    }

    /**
     * Encrypts sensitive string using AES-GCM and stores in SharedPreferences.
     * Never falls back to plaintext storage on failure.
     * @return true if successfully encrypted and saved, false otherwise.
     */
    fun encryptAndSave(key: String, value: String): Boolean {
        if (value.isBlank()) {
            prefs.edit().remove(key).apply()
            return true
        }

        val secretKey = getSecretKey()
        if (secretKey == null) {
            Log.e(TAG, "Cannot save sensitive key '$key': Android KeyStore SecretKey unavailable. Refusing plaintext fallback.")
            return false
        }

        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv ?: return false
            val encryptedBytes = cipher.doFinal(value.toByteArray(Charsets.UTF_8))

            val combined = ByteArray(iv.size + encryptedBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)

            val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
            prefs.edit().putString(key, encoded).apply()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Encryption failed for key '$key': ${e.message}. Refusing plaintext fallback.")
            false
        }
    }

    /**
     * Decrypts AES-GCM encrypted string from SharedPreferences.
     * Returns null if decryption fails or if secure key is unavailable.
     * Never returns plaintext fallback.
     */
    fun getAndDecrypt(key: String): String? {
        val stored = prefs.getString(key, null) ?: return null
        val secretKey = getSecretKey()
        if (secretKey == null) {
            Log.e(TAG, "Cannot decrypt key '$key': Android KeyStore SecretKey unavailable.")
            return null
        }

        return try {
            val combined = Base64.decode(stored, Base64.NO_WRAP)
            if (combined.size <= GCM_IV_LENGTH_BYTES) {
                Log.w(TAG, "Corrupted ciphertext for key '$key'")
                return null
            }

            val iv = ByteArray(GCM_IV_LENGTH_BYTES)
            val encrypted = ByteArray(combined.size - GCM_IV_LENGTH_BYTES)
            System.arraycopy(combined, 0, iv, 0, GCM_IV_LENGTH_BYTES)
            System.arraycopy(combined, GCM_IV_LENGTH_BYTES, encrypted, 0, encrypted.size)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

            val decryptedBytes = cipher.doFinal(encrypted)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            Log.e(TAG, "Decryption failed for key '$key': ${e.message}")
            null
        }
    }

    fun saveTokens(
        accessToken: String,
        refreshToken: String? = null,
        expiresInSeconds: Long = 3600,
        channelTitle: String? = null,
        channelId: String? = null
    ): Boolean {
        val accessSaved = encryptAndSave(KEY_ACCESS_TOKEN, accessToken)
        if (!accessSaved) {
            Log.e(TAG, "Failed to securely encrypt access token. Aborting save to prevent insecure state.")
            return false
        }

        if (!refreshToken.isNullOrBlank()) {
            encryptAndSave(KEY_REFRESH_TOKEN, refreshToken)
        }

        val expiryTime = System.currentTimeMillis() + (expiresInSeconds * 1000L)
        prefs.edit().putLong(KEY_TOKEN_EXPIRY, expiryTime).apply()

        if (!channelTitle.isNullOrBlank()) {
            prefs.edit().putString(KEY_CHANNEL_TITLE, channelTitle).apply()
        }
        if (!channelId.isNullOrBlank()) {
            prefs.edit().putString(KEY_CHANNEL_ID, channelId).apply()
        }
        return true
    }

    fun getAccessToken(): String? = getAndDecrypt(KEY_ACCESS_TOKEN)
    fun getRefreshToken(): String? = getAndDecrypt(KEY_REFRESH_TOKEN)
    fun getChannelTitle(): String? = prefs.getString(KEY_CHANNEL_TITLE, null)
    fun getChannelId(): String? = prefs.getString(KEY_CHANNEL_ID, null)

    fun isTokenExpired(): Boolean {
        val expiry = prefs.getLong(KEY_TOKEN_EXPIRY, 0L)
        if (expiry <= 0L) return true
        return System.currentTimeMillis() >= (expiry - 60000L) // 1 min safety buffer
    }

    fun hasSavedExpiry(): Boolean = prefs.contains(KEY_TOKEN_EXPIRY)

    fun hasValidAccessToken(): Boolean {
        val token = getAccessToken()
        if (token.isNullOrBlank()) return false
        if (isTokenExpired()) return false
        return true
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
