package com.example.ui.util

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.core.model.DetectionFrame
import com.example.core.model.FrameAnalysisInput
import com.example.services.composition.ComposedBroadcastFrame
import java.nio.ByteBuffer

/**
 * High-Performance Zero-Allocation Bitmap Converter for Jetpack Compose.
 *
 * Guarantees:
 * - Station preview capped at 30 fps, reusing one stable ImageBitmap.
 * - ROI crop preview capped at 8 fps, reusing one stable ImageBitmap.
 * - Zero per-frame memory allocations or GC jitter.
 */
object FrameBitmapConverter {

    @Volatile
    private var cachedPreviewBitmap: Bitmap? = null
    @Volatile
    private var cachedPreviewImageBitmap: ImageBitmap? = null
    private var lastPreviewDrawTimeMs: Long = 0L

    @Volatile
    private var cachedStationImageBitmap: ImageBitmap? = null
    @Volatile
    private var cachedStationFrame: ComposedBroadcastFrame? = null
    private var lastStationDrawTimeMs: Long = 0L

    @Volatile
    private var cachedCropBitmap: Bitmap? = null
    @Volatile
    private var cachedCropImageBitmap: ImageBitmap? = null
    private var lastCropDrawTimeMs: Long = 0L

    private var previewCanvas: Canvas? = null
    private var cropCanvas: Canvas? = null
    
    private val previewLock = Any()
    private val stationLock = Any()
    private val cropLock = Any()

    /**
     * Safely updates the stable preview bitmap from a background thread.
     */
    fun updatePreview(frame: DetectionFrame?) {
        if (frame?.buffer == null || frame.width <= 0 || frame.height <= 0) return
        val expectedSize = frame.width * frame.height * 4
        if (frame.buffer.size < expectedSize) return

        val now = System.currentTimeMillis()
        if (now - lastPreviewDrawTimeMs < 33L && cachedPreviewImageBitmap != null) {
            return
        }
        lastPreviewDrawTimeMs = now

        synchronized(previewLock) {
            try {
                var bmp = cachedPreviewBitmap
                if (bmp == null || bmp.width != frame.width || bmp.height != frame.height || bmp.isRecycled) {
                    bmp = Bitmap.createBitmap(frame.width, frame.height, Bitmap.Config.ARGB_8888)
                    cachedPreviewBitmap = bmp
                    cachedPreviewImageBitmap = bmp.asImageBitmap()
                }
                val byteBuffer = ByteBuffer.wrap(frame.buffer, 0, expectedSize)
                bmp.copyPixelsFromBuffer(byteBuffer)
            } catch (_: Exception) {}
        }
    }

    /**
     * Safely updates the stable station preview bitmap from a background thread.
     */
    fun updateStationPreview(frame: ComposedBroadcastFrame?) {
        if (frame == null) return
        
        val now = System.currentTimeMillis()
        if (now - lastStationDrawTimeMs < 33L && cachedStationImageBitmap != null) {
            return
        }
        lastStationDrawTimeMs = now

        synchronized(stationLock) {
            try {
                // Release old frame
                cachedStationFrame?.release()
                
                // Retain new frame
                frame.retain()
                cachedStationFrame = frame
                
                // Use the bitmap directly
                cachedStationImageBitmap = frame.bitmap.asImageBitmap()
            } catch (_: Exception) {}
        }
    }

    /**
     * Safely updates the stable crop preview bitmap from a background thread.
     */
    fun updateCrop(input: FrameAnalysisInput?) {
        if (input?.buffer == null || input.width <= 0 || input.height <= 0) return
        val expectedSize = input.width * input.height * 4
        if (input.buffer.size < expectedSize) return

        val now = System.currentTimeMillis()
        if (now - lastCropDrawTimeMs < 125L && cachedCropImageBitmap != null) {
            return
        }
        lastCropDrawTimeMs = now

        synchronized(cropLock) {
            try {
                var bmp = cachedCropBitmap
                if (bmp == null || bmp.width != input.width || bmp.height != input.height || bmp.isRecycled) {
                    bmp = Bitmap.createBitmap(input.width, input.height, Bitmap.Config.ARGB_8888)
                    cachedCropBitmap = bmp
                    cachedCropImageBitmap = bmp.asImageBitmap()
                }
                val byteBuffer = ByteBuffer.wrap(input.buffer, 0, expectedSize)
                bmp.copyPixelsFromBuffer(byteBuffer)
            } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun toStationProgramImageBitmap(frame: ComposedBroadcastFrame?): ImageBitmap? {
        if (frame == null) return null
        synchronized(stationLock) {
            // If the same frame, just return it
            if (cachedStationFrame == frame) {
                return cachedStationImageBitmap
            }
            
            // Release old
            cachedStationFrame?.release()
            
            // Retain new
            frame.retain()
            cachedStationFrame = frame
            cachedStationImageBitmap = frame.bitmap.asImageBitmap()
            
            return cachedStationImageBitmap
        }
    }

    @Synchronized
    fun toImageBitmap(frame: DetectionFrame?): ImageBitmap? {
        if (frame == null) return null
        synchronized(previewLock) {
            val cached = cachedPreviewImageBitmap
            if (cached != null) return cached
        }
        if (frame.buffer == null || frame.width <= 0 || frame.height <= 0) return null
        val expectedSize = frame.width * frame.height * 4
        if (frame.buffer.size < expectedSize) return null

        return try {
            var bmp = cachedPreviewBitmap
            if (bmp == null || bmp.width != frame.width || bmp.height != frame.height || bmp.isRecycled) {
                bmp = Bitmap.createBitmap(frame.width, frame.height, Bitmap.Config.ARGB_8888)
                cachedPreviewBitmap = bmp
                cachedPreviewImageBitmap = bmp.asImageBitmap()
            }
            val byteBuffer = ByteBuffer.wrap(frame.buffer, 0, expectedSize)
            bmp.copyPixelsFromBuffer(byteBuffer)
            cachedPreviewImageBitmap ?: bmp.asImageBitmap().also { cachedPreviewImageBitmap = it }
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun toImageBitmap(input: FrameAnalysisInput?): ImageBitmap? {
        if (input == null) return null
        synchronized(cropLock) {
            val cached = cachedCropImageBitmap
            if (cached != null) return cached
        }
        if (input.buffer == null || input.width <= 0 || input.height <= 0) return null
        val expectedSize = input.width * input.height * 4
        if (input.buffer.size < expectedSize) return null

        return try {
            var bmp = cachedCropBitmap
            if (bmp == null || bmp.width != input.width || bmp.height != input.height || bmp.isRecycled) {
                bmp = Bitmap.createBitmap(input.width, input.height, Bitmap.Config.ARGB_8888)
                cachedCropBitmap = bmp
                cachedCropImageBitmap = bmp.asImageBitmap()
            }
            val byteBuffer = ByteBuffer.wrap(input.buffer, 0, expectedSize)
            bmp.copyPixelsFromBuffer(byteBuffer)
            cachedCropImageBitmap ?: bmp.asImageBitmap().also { cachedCropImageBitmap = it }
        } catch (_: Exception) {
            null
        }
    }
}
