package com.example.core.model

import java.util.concurrent.atomic.AtomicInteger

/**
 * Thread-safe reference-counted handle for a pooled ByteArray frame buffer.
 * When refCount reaches 0, onRelease is invoked to return the buffer to the pool.
 */
class FrameBufferReference(
    val id: Int,
    val array: ByteArray,
    private val onRelease: (FrameBufferReference) -> Unit
) {
    private val refCount = AtomicInteger(0)

    /**
     * Attempts to acquire the buffer from the pool with an initial reference count.
     * Only succeeds if current refCount is 0.
     */
    fun acquire(initialRefs: Int = 1): Boolean {
        if (initialRefs <= 0) return false
        return refCount.compareAndSet(0, initialRefs)
    }

    /**
     * Retains additional references for downstream consumers.
     * Returns true if successfully retained, false if already released/recycled.
     */
    fun retain(count: Int = 1): Boolean {
        if (count <= 0) return true
        while (true) {
            val current = refCount.get()
            if (current <= 0) return false
            if (refCount.compareAndSet(current, current + count)) {
                return true
            }
        }
    }

    /**
     * Releases references. When refCount drops to 0, onRelease is called.
     */
    fun release(count: Int = 1) {
        if (count <= 0) return
        while (true) {
            val current = refCount.get()
            if (current <= 0) return
            val newCount = maxOf(0, current - count)
            if (refCount.compareAndSet(current, newCount)) {
                if (newCount == 0) {
                    onRelease(this)
                }
                return
            }
        }
    }

    fun isFree(): Boolean = refCount.get() <= 0

    fun getRefCount(): Int = refCount.get()

    fun forceFree() {
        refCount.set(0)
        onRelease(this)
    }
}
