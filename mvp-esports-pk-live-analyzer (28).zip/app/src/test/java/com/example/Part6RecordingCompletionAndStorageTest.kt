package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaCodecInfo
import android.media.MediaFormat
import androidx.test.core.app.ApplicationProvider
import com.example.services.composition.BroadcastVideoCompositor
import com.example.services.composition.ComposedBroadcastFrame
import com.example.services.station.StationDeskManager
import com.example.services.streaming.BroadcastRecordingManager
import com.example.services.streaming.MediaCodecAudioEncoder
import com.example.services.streaming.MediaCodecVideoEncoder
import com.example.services.streaming.RecordingProfile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
@OptIn(ExperimentalCoroutinesApi::class)
class Part6RecordingCompletionAndStorageTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    private fun createTestBitmap(width: Int = 1280, height: Int = 720): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.RED)
        return bmp
    }

    @Test
    fun testMediaCodecAudioEncoderConfigurationAndEOS() {
        val audioEncoder = MediaCodecAudioEncoder()
        val configRes = audioEncoder.configureEncoder(
            sampleRate = 44100,
            channelCount = 2,
            bitrate = 64000
        )
        assertTrue("Audio encoder configuration must succeed", configRes.isSuccess)
        assertTrue(audioEncoder.isRunning)

        val outputFormat = audioEncoder.getOutputFormat()
        assertNotNull("Audio encoder must provide output format", outputFormat)
        assertEquals(MediaFormat.MIMETYPE_AUDIO_AAC, outputFormat?.getString(MediaFormat.KEY_MIME))

        // Encode test PCM buffer
        val dummyPcm = ByteArray(4096) { 0 }
        var packetsReceived = 0
        audioEncoder.encodePcmData(dummyPcm, 0L) { packet, ptsMs, isConfig ->
            packetsReceived++
        }

        // Test End-of-Stream signal and drain
        audioEncoder.signalEndOfStream()
        audioEncoder.drainOutputs { packet, ptsMs, isConfig ->
            packetsReceived++
        }

        audioEncoder.stopEncoder()
        assertFalse(audioEncoder.isRunning)
    }

    @Test
    fun testMediaCodecVideoEncoderEOSDrainingPreservesFinalFrames() {
        val videoEncoder = MediaCodecVideoEncoder()
        videoEncoder.colorFormatOverride = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
        val configRes = videoEncoder.configureEncoder(1280, 720, 4000000, 30, preferSurface = false)
        assertTrue(configRes.isSuccess)

        val testBitmap = createTestBitmap(1280, 720)

        // Encode multiple consecutive frames
        val res1 = videoEncoder.encodeFrame(testBitmap, 0L)
        assertTrue(res1.isSuccess)

        val res2 = videoEncoder.encodeFrame(testBitmap, 33333L)
        assertTrue(res2.isSuccess)

        val res3 = videoEncoder.encodeFrame(testBitmap, 66666L)
        assertTrue(res3.isSuccess)

        // Signal EOS and drain trailing frames
        videoEncoder.signalEndOfStream()
        videoEncoder.drainEndOfStream(maxAttempts = 10)

        videoEncoder.stopEncoder()
        assertFalse(videoEncoder.isRunning)
    }

    @Test
    fun testRecordingLifecycleFullShutdownSequence() = runTest {
        val recordingManager = BroadcastRecordingManager.getInstance()
        assertFalse(recordingManager.isRecording.value)

        // Set audio enabled
        recordingManager.setAudioEnabled(true)
        assertTrue(recordingManager.isAudioEnabled.value)

        val startRes = recordingManager.startRecording(
            context = context,
            width = 1280,
            height = 720,
            fps = 30,
            bitrate = 5000000,
            enableAudio = true
        )
        assertTrue("Recording start must succeed", startRes.isSuccess)
        assertTrue(recordingManager.isRecording.value)
        assertNotNull(recordingManager.fileCreationStatus.value)

        // Check StationDeskManager state synchronization
        val deskState = StationDeskManager.stationState.value
        assertTrue(deskState.isRecording)
        assertNotNull(deskState.recordingFileName)

        // Stop recording with complete shutdown sequence
        val stopRes = recordingManager.stopRecording()
        assertTrue("Recording stop must succeed", stopRes.isSuccess)
        assertFalse("Recording must be inactive after stop", recordingManager.isRecording.value)
        assertNull("No error should be reported on clean stop", recordingManager.recordingError.value)
        assertTrue(
            "File creation status should indicate saved file",
            recordingManager.fileCreationStatus.value?.startsWith("SAVED:") == true
        )

        val updatedDesk = StationDeskManager.stationState.value
        assertFalse(updatedDesk.isRecording)
    }

    @Test
    fun testAudioTrackToggleBehavior() = runTest {
        val recordingManager = BroadcastRecordingManager.getInstance()

        // Test with audio disabled
        recordingManager.setAudioEnabled(false)
        assertFalse(recordingManager.isAudioEnabled.value)

        val startResNoAudio = recordingManager.startRecording(
            context = context,
            width = 854,
            height = 480,
            fps = 30,
            enableAudio = false
        )
        assertTrue(startResNoAudio.isSuccess)
        assertTrue(recordingManager.isRecording.value)

        val stopResNoAudio = recordingManager.stopRecording()
        assertTrue(stopResNoAudio.isSuccess)
        assertFalse(recordingManager.isRecording.value)

        // Reset to true
        recordingManager.setAudioEnabled(true)
        assertTrue(recordingManager.isAudioEnabled.value)
    }

    @Test
    fun testFailureCleanUpAndErrorVisibility() = runTest {
        val recordingManager = BroadcastRecordingManager.getInstance()

        // Double start should be safe and idempotent
        val start1 = recordingManager.startRecording(context, 1280, 720, 30)
        assertTrue(start1.isSuccess)
        val start2 = recordingManager.startRecording(context, 1280, 720, 30)
        assertTrue(start2.isSuccess)

        val stopRes = recordingManager.stopRecording()
        assertTrue(stopRes.isSuccess)
        assertFalse(recordingManager.isRecording.value)
    }
}
