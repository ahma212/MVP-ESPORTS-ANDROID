package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import com.example.core.model.DetectionFrame
import com.example.core.model.PlayerLiveState
import com.example.core.model.TeamLiveState
import com.example.services.composition.BottomTickerOverlayLayer
import com.example.services.composition.BroadcastVideoCompositor
import com.example.services.composition.IBroadcastLayer
import com.example.services.composition.OverallStandingOverlayLayer
import com.example.services.station.StationDeskManager
import com.example.services.station.StationResolution
import com.example.services.streaming.LocalLiveRuntimeManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class Part4CompositorAndFramingTest {

    private lateinit var compositor: BroadcastVideoCompositor

    @Before
    fun setUp() {
        compositor = BroadcastVideoCompositor.getInstance()
        StationDeskManager.setResolution(StationResolution.RES_720P)

        // Seed realistic tournament teams
        val testTeams = (1..4).map { teamNum ->
            TeamLiveState(
                teamNumber = teamNum,
                teamName = "TEAM $teamNum",
                currentMatchKills = teamNum * 2,
                currentMatchPoints = teamNum * 5,
                rank = teamNum,
                currentAlivePlayers = 4,
                players = (1..4).map { pIdx ->
                    PlayerLiveState(
                        playerName = "P_${teamNum}_$pIdx",
                        teamNumber = teamNum,
                        eliminated = false,
                        knocked = false
                    )
                }
            )
        }
        LocalLiveRuntimeManager.initializeFromRoster(testTeams)
    }

    private fun createFrame(width: Int, height: Int, frameId: Long, timestampMs: Long = 1000L + frameId * 33L): DetectionFrame {
        val totalBytes = width * height * 4
        val buffer = ByteArray(totalBytes)
        // Fill with dummy color pattern
        for (i in 0 until totalBytes step 4) {
            buffer[i] = 0x22.toByte()     // R
            buffer[i + 1] = 0x55.toByte() // G
            buffer[i + 2] = 0x88.toByte() // B
            buffer[i + 3] = 0xFF.toByte() // A
        }
        return DetectionFrame(
            frameId = frameId,
            timestampMs = timestampMs,
            width = width,
            height = height,
            format = "RGBA_8888",
            buffer = buffer,
            sourceIdentifier = "android_screen_capture"
        )
    }

    @Test
    fun testFrameBufferPoolEliminatesMutableOwnershipRace() {
        // Compose multiple consecutive frames
        val frame1 = createFrame(1920, 1080, frameId = 1L, timestampMs = 1000L)
        val frame2 = createFrame(1920, 1080, frameId = 2L, timestampMs = 1033L)
        val frame3 = createFrame(1920, 1080, frameId = 3L, timestampMs = 1066L)

        val composed1 = compositor.composeFrame(frame1)
        val composed2 = compositor.composeFrame(frame2)
        val composed3 = compositor.composeFrame(frame3)

        assertNotNull(composed1)
        assertNotNull(composed2)
        assertNotNull(composed3)

        // Consecutive frames must have distinct bitmap instances in the pool to prevent concurrent mutation race
        assertFalse("Bitmap 1 must not equal Bitmap 2", composed1!!.bitmap === composed2!!.bitmap)
        assertFalse("Bitmap 2 must not equal Bitmap 3", composed2.bitmap === composed3!!.bitmap)
        assertFalse("Bitmap 1 must not equal Bitmap 3", composed1.bitmap === composed3.bitmap)

        // Frame IDs and timestamps must match individual submissions
        assertEquals(1L, composed1.frameId)
        assertEquals(1000L, composed1.timestampMs)

        assertEquals(2L, composed2.frameId)
        assertEquals(1033L, composed2.timestampMs)

        assertEquals(3L, composed3.frameId)
        assertEquals(1066L, composed3.timestampMs)
    }

    @Test
    fun testUltrawide20by9CenterCropFraming() {
        // Ultrawide 2400x1080 mobile gaming screen (20:9)
        val ultrawideFrame = createFrame(width = 2400, height = 1080, frameId = 10L)
        val composed = compositor.composeFrame(ultrawideFrame)

        assertNotNull(composed)
        // Standardized to 16:9 720p (1280x720) without stretching
        assertEquals(1280, composed!!.width)
        assertEquals(720, composed.height)
        assertEquals(1280, composed.bitmap.width)
        assertEquals(720, composed.bitmap.height)
        assertFalse(composed.bitmap.isRecycled)
    }

    @Test
    fun test4by3TabletCenterCropFraming() {
        // 4:3 Tablet capture (1440x1080)
        val tabletFrame = createFrame(width = 1440, height = 1080, frameId = 20L)
        val composed = compositor.composeFrame(tabletFrame)

        assertNotNull(composed)
        assertEquals(1280, composed!!.width)
        assertEquals(720, composed.height)
        assertEquals(1280, composed.bitmap.width)
        assertEquals(720, composed.bitmap.height)
    }

    @Test
    fun testPortraitCaptureCenterCropFraming() {
        // Portrait mobile screen (1080x2400)
        val portraitFrame = createFrame(width = 1080, height = 2400, frameId = 30L)
        val composed = compositor.composeFrame(portraitFrame)

        assertNotNull(composed)
        assertEquals(1280, composed!!.width)
        assertEquals(720, composed.height)
        assertEquals(1280, composed.bitmap.width)
        assertEquals(720, composed.bitmap.height)
    }

    @Test
    fun test1080pResolutionScaling() {
        // Switch Station to 1080p
        StationDeskManager.setResolution(StationResolution.RES_1080P)
        val frame = createFrame(width = 1920, height = 1080, frameId = 40L)
        val composed = compositor.composeFrame(frame)

        assertNotNull(composed)
        assertEquals(1920, composed!!.width)
        assertEquals(1080, composed.height)
        assertEquals(1920, composed.bitmap.width)
        assertEquals(1080, composed.bitmap.height)

        // Reset back to 720P
        StationDeskManager.setResolution(StationResolution.RES_720P)
    }

    @Test
    fun testOverlayLayersPreservedAndOperatorControlsExcluded() {
        // Add operator pointer and cropper layer - must be excluded
        val pointerLayer = object : IBroadcastLayer {
            override val layerId: String = "floating_pointer_overlay"
            override val layerName: String = "Pointer"
            override var isEnabled: Boolean = true
            override val zIndex: Int = 999
            override fun draw(canvas: Canvas, frameWidth: Int, frameHeight: Int, timestampMs: Long) {}
        }
        compositor.addLayer(pointerLayer)

        val frame = createFrame(1280, 720, 50L)
        val composed = compositor.composeFrame(frame)

        assertNotNull(composed)
        // Operator pointer must NOT be in activeLayers
        assertFalse(composed!!.activeLayers.contains("floating_pointer_overlay"))
        // Tournament overlays must be present
        assertTrue(composed.activeLayers.contains(OverallStandingOverlayLayer.LAYER_ID))
        assertTrue(composed.activeLayers.contains(BottomTickerOverlayLayer.LAYER_ID))
    }

    @Test
    fun testCompositorReleaseCleansUpResources() {
        val frame = createFrame(1280, 720, 60L)
        compositor.composeFrame(frame)

        compositor.release()
        assertFalse(compositor.isCompositing.value)
    }
}
