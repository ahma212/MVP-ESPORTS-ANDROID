package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.projection.MediaProjection
import com.example.services.audio.AudioMixerManager
import com.example.services.audio.InternalAudioCaptureManager
import com.example.services.audio.MicrophoneCommentaryManager
import com.example.services.audio.PcmMixer
import com.example.services.composition.BroadcastVideoCompositor
import com.example.services.composition.ComposedBroadcastFrame
import com.example.services.streaming.BroadcastStreamingPipeline
import com.example.services.streaming.MediaCodecVideoEncoder
import com.example.services.streaming.RtmpIngestGateway
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.Shadows

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Part7AudioArchitectureAndAvSyncTest {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = RuntimeEnvironment.getApplication()
        MicrophoneCommentaryManager.stopMicrophone()
        InternalAudioCaptureManager.stopCapture()
        AudioMixerManager.setMicVolume(1.0f)
        AudioMixerManager.setGameVolume(1.0f)
        AudioMixerManager.setMusicVolume(1.0f)
    }

    @Test
    fun testInternalAudioCaptureManagerLifecycle() {
        // Verification of start -> capture -> read -> stop lifecycle
        InternalAudioCaptureManager.stopCapture()
        assertFalse("Internal capture should be stopped initially", InternalAudioCaptureManager.internalAudioState.value.isCapturing)

        val buffer = ByteArray(2048)
        val readBytesWhenStopped = InternalAudioCaptureManager.read(buffer, 0, 2048)
        assertEquals("Reading when stopped should return 0 bytes cleanly", 0, readBytesWhenStopped)

        InternalAudioCaptureManager.stopCapture()
        assertFalse("Idempotent stopCapture should maintain stopped state", InternalAudioCaptureManager.internalAudioState.value.isCapturing)
    }

    @Test
    fun testMicrophoneCaptureLifecycleAndPermissionCheck() {
        MicrophoneCommentaryManager.stopMicrophone()
        val stateBefore = MicrophoneCommentaryManager.micState.value
        assertFalse("Microphone initially stopped", stateBefore.isRecording)

        // Read from stopped microphone
        val buffer = ByteArray(1024)
        val bytesRead = MicrophoneCommentaryManager.read(buffer, 0, 1024)
        assertEquals("Read from stopped mic must be 0", 0, bytesRead)

        MicrophoneCommentaryManager.stopMicrophone()
        assertFalse("Microphone stop is safe and idempotent", MicrophoneCommentaryManager.micState.value.isRecording)
    }

    @Test
    fun testZeroAllocationPcmMixerWithExplicitLengths() {
        val micBuffer = ByteArray(2048) { 0x10 }
        val gameBuffer = ByteArray(4096) { 0x20 }
        val musicBuffer = ByteArray(4096) { 0x05 }

        val micReadLen = 2
        val gameReadLen = 4
        val musicReadLen = 4

        val mixedPcm = PcmMixer.mix(
            micPcm = micBuffer,
            micLen = micReadLen,
            micVol = 1.0f,
            micMuted = false,
            gamePcm = gameBuffer,
            gameLen = gameReadLen,
            gameVol = 1.0f,
            gameMuted = false,
            musicPcm = musicBuffer,
            musicLen = musicReadLen,
            musicVol = 1.0f,
            musicMuted = false
        )

        assertNotNull("Mixed PCM output should not be null", mixedPcm)
        assertTrue("Mixed output size should match max frame count * 4", mixedPcm.size > 0)
        assertEquals("Max frames = max(1, 1, 1) = 1 frame -> 4 bytes", 4, mixedPcm.size)
    }

    @Test
    fun testMonotonicTimelineAndAvSyncInStreamingPipeline() = runBlocking {
        val pipeline = BroadcastStreamingPipeline()

        val startRes = pipeline.startPipeline(
            rtmpUrl = "rtmp://localhost/live/test",
            width = 640,
            height = 360,
            bitrate = 1000000,
            fps = 30
        )
        assertNotNull("Start pipeline result should not be null", startRes)

        val bmp = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        val frame1 = ComposedBroadcastFrame(
            frameId = 1L,
            timestampMs = System.currentTimeMillis(),
            width = 640,
            height = 360,
            bitmap = bmp,
            activeLayers = emptyList(),
            compositionTimeMs = 2L
        )

        val res1 = pipeline.processFrame(frame1)
        assertNotNull("Frame 1 result should not be null", res1)

        pipeline.stopPipeline()
        assertFalse("Pipeline stopped cleanly", pipeline.pipelineMetrics.value.isActive)
    }

    @Test
    fun testAudioErrorVisibilityAndPipelineResilience() {
        val pipeline = BroadcastStreamingPipeline()
        val metricsBefore = pipeline.pipelineMetrics.value
        assertFalse("Initial metrics inactive", metricsBefore.isActive)
        assertNull("Initial error null", metricsBefore.lastError)
    }
}
