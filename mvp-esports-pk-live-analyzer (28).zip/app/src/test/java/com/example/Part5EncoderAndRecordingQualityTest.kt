package com.example

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodecInfo
import android.media.MediaFormat
import androidx.test.core.app.ApplicationProvider
import com.example.services.composition.BroadcastVideoCompositor
import com.example.services.composition.ComposedBroadcastFrame
import com.example.services.station.StationDeskManager
import com.example.services.station.StationFps
import com.example.services.station.StationQuality
import com.example.services.station.StationResolution
import com.example.services.streaming.BroadcastRecordingManager
import com.example.services.streaming.MediaCodecVideoEncoder
import com.example.services.streaming.RecordingProfile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
@OptIn(ExperimentalCoroutinesApi::class)
class Part5EncoderAndRecordingQualityTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun testRecordingProfilesConfiguredCorrectly() {
        assertEquals(1920, RecordingProfile.ULTRA.width)
        assertEquals(1080, RecordingProfile.ULTRA.height)
        assertEquals(60, RecordingProfile.ULTRA.fps)
        assertEquals(12000000, RecordingProfile.ULTRA.bitrate)

        assertEquals(1920, RecordingProfile.HIGH.width)
        assertEquals(1080, RecordingProfile.HIGH.height)
        assertEquals(30, RecordingProfile.HIGH.fps)
        assertEquals(8000000, RecordingProfile.HIGH.bitrate)

        assertEquals(1280, RecordingProfile.MEDIUM.width)
        assertEquals(720, RecordingProfile.MEDIUM.height)
        assertEquals(30, RecordingProfile.MEDIUM.fps)
        assertEquals(5000000, RecordingProfile.MEDIUM.bitrate)

        assertEquals(854, RecordingProfile.LOW.width)
        assertEquals(480, RecordingProfile.LOW.height)
        assertEquals(30, RecordingProfile.LOW.fps)
        assertEquals(2000000, RecordingProfile.LOW.bitrate)
    }

    @Test
    fun testMediaCodecVideoEncoder1080p60Configuration() {
        val encoder = MediaCodecVideoEncoder()
        encoder.colorFormatOverride = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar

        val result = encoder.configureEncoder(
            width = 1920,
            height = 1080,
            bitrate = 12000000,
            fps = 60,
            preferSurface = false
        )

        assertTrue(result.isSuccess)
        assertTrue(encoder.isRunning)
        assertEquals(1920, encoder.currentWidth)
        assertEquals(1080, encoder.currentHeight)
        assertEquals(12000000, encoder.currentBitrate)
        assertEquals(60, encoder.currentFps)

        val outputFormat = encoder.getOutputFormat()
        assertNotNull(outputFormat)
        assertEquals(1920, outputFormat?.getInteger(MediaFormat.KEY_WIDTH))
        assertEquals(1080, outputFormat?.getInteger(MediaFormat.KEY_HEIGHT))
        assertEquals(12000000, outputFormat?.getInteger(MediaFormat.KEY_BIT_RATE))
        assertEquals(60, outputFormat?.getInteger(MediaFormat.KEY_FRAME_RATE))

        encoder.stopEncoder()
        assertFalse(encoder.isRunning)
    }

    @Test
    fun testMediaCodecVideoEncoderStrictMonotonicPresentationTimestamps() {
        val encoder = MediaCodecVideoEncoder()
        encoder.colorFormatOverride = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
        encoder.configureEncoder(1280, 720, 4000000, 30)

        val testBitmap = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)

        // Frame 1 with 0us
        val res1 = encoder.encodeFrame(testBitmap, 0L)
        assertTrue(res1.isSuccess)
        val pts1 = encoder.lastPresentationTimeUs
        assertEquals(0L, pts1)

        // Frame 2 with lower or equal timestamp (jitter) - encoder must enforce strictly monotonic PTS
        val res2 = encoder.encodeFrame(testBitmap, 0L)
        assertTrue(res2.isSuccess)
        val pts2 = encoder.lastPresentationTimeUs
        assertTrue("PTS2 ($pts2) must be strictly greater than PTS1 ($pts1)", pts2 > pts1)

        // Frame 3 with higher timestamp
        val res3 = encoder.encodeFrame(testBitmap, 100000L)
        assertTrue(res3.isSuccess)
        val pts3 = encoder.lastPresentationTimeUs
        assertEquals(100000L, pts3)

        encoder.stopEncoder()
    }

    @Test
    fun testBroadcastRecordingManagerProfileSelectionAndSupport() = runTest {
        val manager = BroadcastRecordingManager.getInstance()

        assertTrue(manager.isResolutionSupported(1920, 1080))
        assertTrue(manager.isResolutionSupported(1280, 720))
        assertTrue(manager.isFpsSupported(60))
        assertTrue(manager.isFpsSupported(30))

        manager.setSelectedProfile(RecordingProfile.ULTRA)
        assertEquals(RecordingProfile.ULTRA, manager.selectedProfile.value)
        assertEquals(60, manager.selectedFps.value)

        manager.setSelectedProfile(RecordingProfile.HIGH)
        assertEquals(RecordingProfile.HIGH, manager.selectedProfile.value)
        assertEquals(30, manager.selectedFps.value)
    }

    @Test
    fun testBroadcastRecordingManagerStartAndStopRecording() = runTest {
        val manager = BroadcastRecordingManager.getInstance()
        assertFalse(manager.isRecording.value)

        val startResult = manager.startRecording(
            context = context,
            width = 1920,
            height = 1080,
            fps = 60,
            bitrate = 8000000
        )
        assertTrue(startResult.isSuccess)
        assertTrue(manager.isRecording.value)

        // Check StationDeskManager state update
        val deskState = StationDeskManager.stationState.value
        assertTrue(deskState.isRecording)
        assertNotNull(deskState.recordingFileName)

        val stopResult = manager.stopRecording()
        assertTrue(stopResult.isSuccess)
        assertFalse(manager.isRecording.value)
    }

    @Test
    fun testStationDeskManagerUltraQualityTier() {
        assertEquals(12000000, StationQuality.ULTRA.bitrate)
        StationDeskManager.setQuality(StationQuality.ULTRA)
        assertEquals(StationQuality.ULTRA, StationDeskManager.stationState.value.quality)
    }
}
