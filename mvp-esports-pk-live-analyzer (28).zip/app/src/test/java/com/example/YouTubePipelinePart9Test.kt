package com.example

import android.content.Context
import com.example.services.streaming.IYouTubeLiveService
import com.example.services.streaming.LiveSessionState
import com.example.services.streaming.YouTubeLiveBroadcastInfo
import com.example.services.streaming.YouTubeLiveService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class YouTubePipelinePart9Test {

    private lateinit var context: Context

    @Before
    fun setup() {
        context = RuntimeEnvironment.getApplication()
    }

    @Test
    fun testWaitForIngestReadyTimeoutOnBlankStreamId() = runBlocking {
        val ytService = YouTubeLiveService.getInstance(context)
        val res = ytService.waitForIngestReady("", maxRetries = 2, delayMs = 10)
        assertTrue("Blank streamId should return failure", res.isFailure)
    }

    @Test
    fun testStopBroadcastUnauthenticatedReturnsFailureOrSuccessSafely() = runBlocking {
        val ytService = YouTubeLiveService.getInstance(context)
        ytService.disconnect()

        // Stopping active broadcast without targetId when none active returns success safely
        val resNull = ytService.stopBroadcast(null)
        assertTrue("Stop broadcast with null target and no active broadcast returns success", resNull.isSuccess)

        // Stopping explicit targetId without auth must fail and update state to ERROR
        val res = ytService.stopBroadcast("targetBroadcast123")
        assertTrue("Stop broadcast with explicit ID without auth should fail", res.isFailure)
        assertEquals(LiveSessionState.ERROR, ytService.sessionState.value)
    }
}
