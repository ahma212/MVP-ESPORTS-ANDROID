package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.services.auth.GoogleSignInManager
import com.example.services.streaming.IYouTubeLiveService
import com.example.services.streaming.LiveSessionState
import com.example.services.streaming.SecureTokenStore
import com.example.services.streaming.YouTubeChannelInfo
import com.example.services.streaming.YouTubeLiveService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class YouTubeAuthAndSecurityTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        YouTubeLiveService.resetInstanceForTesting()
        val tokenStore = SecureTokenStore(context)
        tokenStore.clear()
    }

    @Test
    fun testSecureTokenStoreFailsSafelyAndDoesNotStorePlaintext() {
        val tokenStore = SecureTokenStore(context)
        val testToken = "ya29.a0AfH6SMTestSecretToken123456789"

        val saved = tokenStore.saveTokens(
            accessToken = testToken,
            expiresInSeconds = 3600,
            channelTitle = "Test Gaming Channel",
            channelId = "UC1234567890"
        )

        val rawPrefs = context.getSharedPreferences(SecureTokenStore.PREF_NAME, Context.MODE_PRIVATE)
        val rawStoredToken = rawPrefs.getString(SecureTokenStore.KEY_ACCESS_TOKEN, null)

        if (saved) {
            // If secure KeyStore is available, raw stored value must NOT equal the plaintext token
            assertNotNull("Stored token should not be null", rawStoredToken)
            assertNotEquals("Plaintext token must never be stored directly in SharedPreferences", testToken, rawStoredToken)

            // Decryption should restore original value
            val decrypted = tokenStore.getAccessToken()
            assertEquals("Decrypted token must match original", testToken, decrypted)
        } else {
            // If KeyStore was unavailable, it must have failed safely without writing plaintext
            assertNull("No plaintext fallback should be written when encryption is unavailable", rawStoredToken)
        }
    }

    @Test
    fun testTokenExpiryEnforcement() {
        val tokenStore = SecureTokenStore(context)
        val rawPrefs = context.getSharedPreferences(SecureTokenStore.PREF_NAME, Context.MODE_PRIVATE)

        // 1. Empty store should be expired and invalid
        assertTrue("Empty token store must report expired", tokenStore.isTokenExpired())
        assertFalse("Empty token store must not have valid access token", tokenStore.hasValidAccessToken())

        // 2. Set token with future expiry
        tokenStore.saveTokens("mock_token", expiresInSeconds = 7200)
        if (tokenStore.getAccessToken() != null) {
            assertFalse("Fresh token must not be expired", tokenStore.isTokenExpired())
            assertTrue("Fresh token must be valid", tokenStore.hasValidAccessToken())
        }

        // 3. Force expiry timestamp to the past
        rawPrefs.edit().putLong(SecureTokenStore.KEY_TOKEN_EXPIRY, System.currentTimeMillis() - 10000L).commit()
        assertTrue("Past expiry timestamp must report expired", tokenStore.isTokenExpired())
        assertFalse("Past expiry timestamp must not have valid access token", tokenStore.hasValidAccessToken())
    }

    @Test
    fun testCachedChannelInfoDoesNotAuthorizeWithoutValidToken() = runBlocking {
        val rawPrefs = context.getSharedPreferences(SecureTokenStore.PREF_NAME, Context.MODE_PRIVATE)

        // Simulate cached channel info from a previous session, but NO access token
        rawPrefs.edit()
            .putString(SecureTokenStore.KEY_CHANNEL_TITLE, "Old Cached Channel")
            .putString(SecureTokenStore.KEY_CHANNEL_ID, "UC_OLD_ID")
            .remove(SecureTokenStore.KEY_ACCESS_TOKEN)
            .remove(SecureTokenStore.KEY_TOKEN_EXPIRY)
            .commit()

        val service = YouTubeLiveService.getInstance(context)
        val isAuth = service.checkAuthorization()

        assertFalse("checkAuthorization must return false when no access token exists, even if channel info is cached", isAuth)
        assertFalse("isAuthorized StateFlow must be false", service.isAuthorized.value)
        assertNull("channelInfo must be cleared when unauthorized", service.channelInfo.value)
    }

    @Test
    fun testExpiredAccessTokenRevokesAuthorization() = runBlocking {
        val rawPrefs = context.getSharedPreferences(SecureTokenStore.PREF_NAME, Context.MODE_PRIVATE)

        // Set past expiry timestamp and cached channel to simulate expired state
        rawPrefs.edit()
            .putLong(SecureTokenStore.KEY_TOKEN_EXPIRY, System.currentTimeMillis() - 500000L)
            .putString(SecureTokenStore.KEY_CHANNEL_TITLE, "Expired Channel")
            .putString(SecureTokenStore.KEY_CHANNEL_ID, "UC_EXPIRED")
            .commit()

        val service = YouTubeLiveService.getInstance(context)
        val isAuth = service.checkAuthorization()

        assertFalse("Expired token must fail checkAuthorization", isAuth)
        assertFalse("service.isAuthorized must be false", service.isAuthorized.value)
        assertNull("channelInfo must be null for expired token", service.channelInfo.value)
        assertNotNull("errorMessage must be populated for expired token", service.errorMessage.value)
        assertTrue("Error message must indicate expiration", service.errorMessage.value?.contains("expired", ignoreCase = true) == true)
    }

    @Test
    fun testDeveloperErrorDiagnosticsContainActionableDetails() {
        val diag = GoogleSignInManager.formatConfigurationDiagnostics(
            context = context,
            errorCode = 10,
            rawMessage = "DEVELOPER_ERROR 10"
        )

        assertTrue("Diagnostics must mention DEVELOPER_ERROR or Code 10", diag.contains("10"))
        assertTrue("Diagnostics must specify the application package name", diag.contains(context.packageName))
        assertTrue("Diagnostics must explain SHA-1 certificate configuration", diag.contains("SHA-1"))
        assertTrue("Diagnostics must explain OAuth client type requirements", diag.contains("OAuth"))
        assertTrue("Diagnostics must explain YouTube Data API v3 scope requirement", diag.contains("YouTube Data API v3"))
    }

    @Test
    fun testBackupAndDataExtractionRulesExcludeTokens() {
        val backupRulesFile = File("src/main/res/xml/backup_rules.xml")
        val altBackupRulesFile = File("app/src/main/res/xml/backup_rules.xml")
        val fileToRead = if (backupRulesFile.exists()) backupRulesFile else altBackupRulesFile

        assertTrue("backup_rules.xml must exist", fileToRead.exists())
        val backupContent = fileToRead.readText()
        assertTrue(
            "backup_rules.xml must explicitly exclude mvp_esports_secure_tokens",
            backupContent.contains("mvp_esports_secure_tokens")
        )

        val dataExtFile = File("src/main/res/xml/data_extraction_rules.xml")
        val altDataExtFile = File("app/src/main/res/xml/data_extraction_rules.xml")
        val dataFileToRead = if (dataExtFile.exists()) dataExtFile else altDataExtFile

        assertTrue("data_extraction_rules.xml must exist", dataFileToRead.exists())
        val dataExtContent = dataFileToRead.readText()
        assertTrue(
            "data_extraction_rules.xml must explicitly exclude mvp_esports_secure_tokens from cloud and device backups",
            dataExtContent.contains("mvp_esports_secure_tokens")
        )
    }
}
