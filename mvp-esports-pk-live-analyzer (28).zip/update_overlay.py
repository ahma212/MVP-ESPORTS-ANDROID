import re

with open('app/src/main/java/com/example/services/overlay/FloatingPointerOverlay.kt', 'r') as f:
    content = f.read()

# 1. Update showOverlay attachment checks
old_show_overlay = """        // If already attached, make sure it's visible, and update status
        if (isAttached && overlayContainer != null) {
            try {
                overlayContainer?.visibility = View.VISIBLE
                pointerBubbleView?.visibility = if (isExpanded) View.GONE else View.VISIBLE
                expandedCardView?.visibility = if (isExpanded) View.VISIBLE else View.GONE
                pointerStatusText?.text = statusText
                _controlState.value = _controlState.value.copy(isVisible = true)
                Log.d("FloatingPointerOverlay", "showOverlay: Already attached, restored visibility.")
                return
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Failed to restore existing overlay view. Re-creating...", e)
                hideOverlay()
            }
        }

        // Prevent duplicate overlays: dismiss previous instance if exists
        activeInstance?.let {
            if (it != this) {
                Log.d("FloatingPointerOverlay", "Dismissing old active instance of overlay.")
                try {
                    it.hideOverlay()
                } catch (e: Exception) {
                    Log.e("FloatingPointerOverlay", "Failed to hide previous overlay instance", e)
                }
            }
        }
        activeInstance = this"""

new_show_overlay = """        // Clean up self if somehow we are in a bad state (detached but think we are attached)
        if (isAttached && overlayContainer != null && overlayContainer?.isAttachedToWindow == false) {
            Log.w("FloatingPointerOverlay", "Overlay container is detached from window. Hiding first.")
            hideOverlay()
        }

        // If already attached, make sure it's visible, and update status
        if (isAttached && overlayContainer != null && overlayContainer?.isAttachedToWindow == true) {
            try {
                overlayContainer?.visibility = View.VISIBLE
                pointerBubbleView?.visibility = if (isExpanded) View.GONE else View.VISIBLE
                expandedCardView?.visibility = if (isExpanded) View.VISIBLE else View.GONE
                pointerStatusText?.text = statusText
                _controlState.value = _controlState.value.copy(isVisible = true)
                Log.d("FloatingPointerOverlay", "showOverlay: Already attached, restored visibility.")
                return
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Failed to restore existing overlay view. Re-creating...", e)
                hideOverlay()
            }
        }

        // Prevent duplicate overlays: dismiss previous instance if exists
        activeInstance?.let {
            Log.d("FloatingPointerOverlay", "Dismissing old active instance of overlay.")
            try {
                it.hideOverlay()
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Failed to hide previous overlay instance", e)
            }
        }
        activeInstance = this"""

content = content.replace(old_show_overlay, new_show_overlay)


# 2. Remove incorrect removeViewImmediate(root)
old_remove_root = """        // Safely try to remove the root from WindowManager first to prevent duplicate view crashes
        try {
            windowManager.removeViewImmediate(root)
        } catch (e: Exception) { Log.w("FloatingPointerOverlay", "Handled non-fatal exception", e) }"""

new_remove_root = """        // The root view is newly created, so it cannot be in the WindowManager yet.
        // We removed the incorrect removeViewImmediate(root) call to prevent exceptions."""

content = content.replace(old_remove_root, new_remove_root)


# 3. Safe hideOverlay removeViewImmediate
old_hide = """        overlayContainer?.let { container ->
            try {
                windowManager.removeViewImmediate(container)
                Log.d("FloatingPointerOverlay", "Successfully removed overlayContainer view from WindowManager")
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Error removing overlay container from WindowManager during hideOverlay", e)
            }
        }"""

new_hide = """        overlayContainer?.let { container ->
            try {
                if (container.isAttachedToWindow) {
                    windowManager.removeViewImmediate(container)
                    Log.d("FloatingPointerOverlay", "Successfully removed overlayContainer view from WindowManager")
                } else {
                    Log.d("FloatingPointerOverlay", "overlayContainer not attached to window, skipping removeViewImmediate")
                }
            } catch (e: Exception) {
                Log.e("FloatingPointerOverlay", "Error removing overlay container from WindowManager during hideOverlay", e)
            }
        }"""

content = content.replace(old_hide, new_hide)

with open('app/src/main/java/com/example/services/overlay/FloatingPointerOverlay.kt', 'w') as f:
    f.write(content)

print("Update complete")
