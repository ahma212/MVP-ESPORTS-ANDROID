import re

with open('app/src/main/java/com/example/services/overlay/FloatingRoiScreenCropper.kt', 'r') as f:
    content = f.read()

old_remove = """        try {
            windowManager.removeView(overlayRoot)
        } catch (e: Exception) {
            e.printStackTrace()
        }"""

new_remove = """        try {
            if (overlayRoot?.isAttachedToWindow == true) {
                windowManager.removeView(overlayRoot)
            }
        } catch (e: Exception) {
            android.util.Log.e("FloatingRoiCropper", "Error removing ROI overlay from WindowManager", e)
        }"""

content = content.replace(old_remove, new_remove)

with open('app/src/main/java/com/example/services/overlay/FloatingRoiScreenCropper.kt', 'w') as f:
    f.write(content)

print("Cropper update complete")
