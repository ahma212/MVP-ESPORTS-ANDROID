
file_path = 'app/src/main/java/com/example/services/media/HardwareVideoDecoder.kt'
with open(file_path, 'r') as f:
    content = f.read()

# Replace the yuv420ToRgba function to remove Pair allocations
old_yuv420ToRgba = """        for (j in 0 until height) {
            val uvRow = j / 2
            val yRow = j * width
            for (i in 0 until width) {
                val uvCol = i / 2
                val yVal = (yuvBytes.getOrElse(yRow + i) { 0 }.toInt() and 0xFF)

                val (uVal, vVal) = if (isSemiPlanar) {
                    val uvIndex = frameSize + (uvRow * width) + (uvCol * 2)
                    val u = (yuvBytes.getOrElse(uvIndex) { 128.toByte() }.toInt() and 0xFF) - 128
                    val v = (yuvBytes.getOrElse(uvIndex + 1) { 128.toByte() }.toInt() and 0xFF) - 128
                    Pair(u, v)
                } else {
                    val u = (yuvBytes.getOrElse(uStart + (uvRow * (width / 2)) + uvCol) { 128.toByte() }.toInt() and 0xFF) - 128
                    val v = (yuvBytes.getOrElse(vStart + (uvRow * (width / 2)) + uvCol) { 128.toByte() }.toInt() and 0xFF) - 128
                    Pair(u, v)
                }

                // Integer fixed-point color space conversion: YUV -> RGB
                val r = (yVal + ((1436 * vVal) shr 10)).coerceIn(0, 255)
                val g = (yVal - ((352 * uVal + 731 * vVal) shr 10)).coerceIn(0, 255)
                val b = (yVal + ((1815 * uVal) shr 10)).coerceIn(0, 255)
"""

new_yuv420ToRgba = """        for (j in 0 until height) {
            val uvRow = j / 2
            val yRow = j * width
            for (i in 0 until width) {
                val uvCol = i / 2
                val yVal = (yuvBytes[yRow + i].toInt() and 0xFF)

                val uVal: Int
                val vVal: Int
                if (isSemiPlanar) {
                    val uvIndex = frameSize + (uvRow * width) + (uvCol * 2)
                    uVal = (yuvBytes[uvIndex].toInt() and 0xFF) - 128
                    vVal = (yuvBytes[uvIndex + 1].toInt() and 0xFF) - 128
                } else {
                    uVal = (yuvBytes[uStart + (uvRow * (width / 2)) + uvCol].toInt() and 0xFF) - 128
                    vVal = (yuvBytes[vStart + (uvRow * (width / 2)) + uvCol].toInt() and 0xFF) - 128
                }

                // Integer fixed-point color space conversion: YUV -> RGB
                val r = (yVal + ((1436 * vVal) shr 10)).coerceIn(0, 255)
                val g = (yVal - ((352 * uVal + 731 * vVal) shr 10)).coerceIn(0, 255)
                val b = (yVal + ((1815 * uVal) shr 10)).coerceIn(0, 255)
"""

new_content = content.replace(old_yuv420ToRgba, new_yuv420ToRgba)

with open(file_path, 'w') as f:
    f.write(new_content)
