import re

with open('app/src/main/java/com/example/services/composition/BroadcastVideoCompositor.kt', 'r') as f:
    content = f.read()

old_code = """        // Ingest and composite real frames in background
        frameAttachmentJob = scope.launch {
            frameFlow.collect { rawFrame ->
                try {
                    composeFrame(rawFrame)
                } finally {
                    rawFrame.release()
                }
            }
        }"""

new_code = """        // Ingest and composite real frames in background
        frameAttachmentJob = scope.launch(kotlinx.coroutines.Dispatchers.Default) {
            frameFlow.collect { rawFrame ->
                try {
                    composeFrame(rawFrame)
                } finally {
                    rawFrame.release()
                }
            }
        }"""

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/services/composition/BroadcastVideoCompositor.kt', 'w') as f:
    f.write(content)

print("Compositor scope patched")
