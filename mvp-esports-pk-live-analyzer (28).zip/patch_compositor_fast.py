import re

with open('app/src/main/java/com/example/services/composition/BroadcastVideoCompositor.kt', 'r') as f:
    content = f.read()

old_code = """            val byteBuffer = ByteBuffer.wrap(buffer, 0, expectedSize)
            baseBmp.copyPixelsFromBuffer(byteBuffer)"""

new_code = """            val byteBuffer = ByteBuffer.wrap(buffer, 0, expectedSize)
            baseBmp.copyPixelsFromBuffer(byteBuffer)"""

# Instead of modifying ByteBuffer, let's look at BroadcastRecordingManager.kt encodeAndMuxFrame
with open('app/src/main/java/com/example/services/streaming/BroadcastRecordingManager.kt', 'r') as f:
    recording_content = f.read()
    
# Remove synthetic PTST
old_pts = """            val frameIntervalUs = 1_000_000L / configuredTargetFps.coerceAtLeast(1)
            val elapsedUs = (SystemClock.elapsedRealtime() - recordingStartTimeMs) * 1000L

            val presentationTimeUs = if (lastRecordedPtsUs < 0) {
                maxOf(0L, elapsedUs)
            } else {
                maxOf(lastRecordedPtsUs + frameIntervalUs, elapsedUs)
            }
            lastRecordedPtsUs = presentationTimeUs"""

new_pts = """            val frameIntervalUs = 1_000_000L / configuredTargetFps.coerceAtLeast(1)
            var presentationTimeUs = composedFrame.timestampMs * 1000L
            
            // Fallback to elapsed time if timestamp is zero or invalid
            if (presentationTimeUs <= 0L) {
                presentationTimeUs = (SystemClock.elapsedRealtime() - recordingStartTimeMs) * 1000L
            }
            
            // Guarantee monotonic strictly increasing PTS
            if (lastRecordedPtsUs >= 0 && presentationTimeUs <= lastRecordedPtsUs) {
                presentationTimeUs = lastRecordedPtsUs + frameIntervalUs
            }
            
            lastRecordedPtsUs = presentationTimeUs"""

recording_content = recording_content.replace(old_pts, new_pts)

with open('app/src/main/java/com/example/services/streaming/BroadcastRecordingManager.kt', 'w') as f:
    f.write(recording_content)

print("BroadcastRecordingManager patched")
