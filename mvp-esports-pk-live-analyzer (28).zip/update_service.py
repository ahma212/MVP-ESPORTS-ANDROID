import re

with open('app/src/main/java/com/example/platform/android/ScreenCaptureService.kt', 'r') as f:
    content = f.read()

old_show = """                    overlay.showOverlay("LIVE")
                    floatingPointerOverlay = overlay
                    Log.d("ScreenCaptureService", "Created and showed new FloatingPointerOverlay successfully.")"""

new_show = """                    try {
                        overlay.showOverlay("LIVE")
                        floatingPointerOverlay = overlay
                        Log.d("ScreenCaptureService", "Created and showed new FloatingPointerOverlay successfully.")
                    } catch (e: Exception) {
                        Log.e("ScreenCaptureService", "Failed to show FloatingPointerOverlay", e)
                    }"""

content = content.replace(old_show, new_show)

with open('app/src/main/java/com/example/platform/android/ScreenCaptureService.kt', 'w') as f:
    f.write(content)

print("Service update complete")
