import re

with open('app/src/main/java/com/example/services/streaming/BroadcastRecordingManager.kt', 'r') as f:
    content = f.read()

old_code = """            // 6. Background encoding worker consuming from bounded queue
            recordingJob = recordingScope.launch(Dispatchers.Default) {"""

new_code = """            // 6. Background encoding worker consuming from bounded queue
            recordingJob = recordingScope.launch(Dispatchers.IO) {"""

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/services/streaming/BroadcastRecordingManager.kt', 'w') as f:
    f.write(content)

print("Recording manager IO patched")
