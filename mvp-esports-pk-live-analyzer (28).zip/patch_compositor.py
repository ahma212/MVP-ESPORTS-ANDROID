import re

with open('app/src/main/java/com/example/services/composition/BroadcastVideoCompositor.kt', 'r') as f:
    content = f.read()

old_code = """            val cropW = srcRect.width()
            val cropH = srcRect.height()
            val cropStride = cropW * 4
            val cropSize = cropStride * cropH

            // 2. Perform zero-allocation byte-level extraction of the crop region directly from the raw buffer
            var cropBuffer = cachedCropBuffer
            if (cropBuffer == null || cropBuffer.size != cropSize) {
                cropBuffer = ByteArray(cropSize)
                cachedCropBuffer = cropBuffer
            }

            val left = srcRect.left
            val top = srcRect.top
            for (y in 0 until cropH) {
                val inputOffset = ((top + y) * width + left) * 4
                val outputOffset = y * cropStride
                System.arraycopy(buffer, inputOffset, cropBuffer, outputOffset, cropStride)
            }

            // 3. Allocate or reuse base bitmap matching ONLY the crop dimensions (not full original resolution)
            var baseBmp = cachedBaseBitmap
            if (baseBmp == null || baseBmp.width != cropW || baseBmp.height != cropH || baseBmp.isRecycled) {
                baseBmp?.recycle()
                baseBmp = Bitmap.createBitmap(cropW, cropH, Bitmap.Config.ARGB_8888)
                cachedBaseBitmap = baseBmp
            }

            val byteBuffer = ByteBuffer.wrap(cropBuffer, 0, cropSize)
            baseBmp.copyPixelsFromBuffer(byteBuffer)

            // 4. Acquire dedicated target-resolution frame buffer slot from pool
            val slot = frameBufferPool.acquireSlot(outW, outH)
            val outBmp = slot.bitmap
            val canvas = slot.canvas

            // 5. Draw cropped base gameplay layer stretched to target resolution
            basePaint.colorFilter = com.example.services.station.StationDeskManager.getColorFilter()
            basePaint.isFilterBitmap = true
            val dstRect = android.graphics.Rect(0, 0, outW, outH)
            canvas.drawBitmap(baseBmp, null, dstRect, basePaint)"""

new_code = """            // 2. Load entire buffer directly into full-resolution base bitmap to avoid manual row-by-row array copy overhead.
            var baseBmp = cachedBaseBitmap
            if (baseBmp == null || baseBmp.width != width || baseBmp.height != height || baseBmp.isRecycled) {
                baseBmp?.recycle()
                baseBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                cachedBaseBitmap = baseBmp
            }
            val byteBuffer = ByteBuffer.wrap(buffer, 0, expectedSize)
            baseBmp.copyPixelsFromBuffer(byteBuffer)

            // 3. Acquire dedicated target-resolution frame buffer slot from pool
            val slot = frameBufferPool.acquireSlot(outW, outH)
            val outBmp = slot.bitmap
            val canvas = slot.canvas

            // 4. Draw cropped region of the full bitmap directly to target resolution (hardware-accelerated if possible)
            basePaint.colorFilter = com.example.services.station.StationDeskManager.getColorFilter()
            basePaint.isFilterBitmap = true
            val dstRect = android.graphics.Rect(0, 0, outW, outH)
            canvas.drawBitmap(baseBmp, srcRect, dstRect, basePaint)"""

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/services/composition/BroadcastVideoCompositor.kt', 'w') as f:
    f.write(content)

print("Compositor patched")
