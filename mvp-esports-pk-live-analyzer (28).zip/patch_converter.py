import re

file_path = 'app/src/main/java/com/example/ui/util/FrameBitmapConverter.kt'
with open(file_path, 'r') as f:
    content = f.read()

# Add canvas fields
new_content = re.sub(r'private var lastCropDrawTimeMs: Long = 0L\n', r'private var lastCropDrawTimeMs: Long = 0L\n\n    private var previewCanvas: Canvas? = null\n    private var stationCanvas: Canvas? = null\n    private var cropCanvas: Canvas? = null\n', content)

# Patch updatePreview
old_update_preview = """                val byteBuffer = ByteBuffer.wrap(frame.buffer, 0, expectedSize)
                bmp.copyPixelsFromBuffer(byteBuffer)
            } catch (_: Exception) {}
        }
    }"""
new_update_preview = """                val byteBuffer = ByteBuffer.wrap(frame.buffer, 0, expectedSize)
                bmp.copyPixelsFromBuffer(byteBuffer)
            } catch (_: Exception) {}
        }
    }"""
# Wait, updatePreview uses copyPixelsFromBuffer, no canvas needed. That one is already fast.

# Patch updateStationPreview
old_update_station = """                val canvas = Canvas(bmp)
                canvas.drawBitmap(srcBmp, 0f, 0f, null)
            } catch (_: Exception) {}
        }
    }"""
new_update_station = """                if (stationCanvas == null || stationCanvas?.bitmap != bmp) {
                    stationCanvas = Canvas(bmp)
                }
                stationCanvas?.drawBitmap(srcBmp, 0f, 0f, null)
            } catch (_: Exception) {}
        }
    }"""
new_content = new_content.replace(old_update_station, new_update_station)

# Patch updateCrop (already uses copyPixelsFromBuffer)

# Patch toStationProgramImageBitmap
old_to_station = """            val canvas = Canvas(bmp)
            canvas.drawBitmap(srcBmp, 0f, 0f, null)
            cachedStationImageBitmap ?: bmp.asImageBitmap().also { cachedStationImageBitmap = it }
        } catch (_: Exception) {
            null
        }
    }"""
new_to_station = """            if (stationCanvas == null || stationCanvas?.bitmap != bmp) {
                stationCanvas = Canvas(bmp)
            }
            stationCanvas?.drawBitmap(srcBmp, 0f, 0f, null)
            cachedStationImageBitmap ?: bmp.asImageBitmap().also { cachedStationImageBitmap = it }
        } catch (_: Exception) {
            null
        }
    }"""
new_content = new_content.replace(old_to_station, new_to_station)

with open(file_path, 'w') as f:
    f.write(new_content)
