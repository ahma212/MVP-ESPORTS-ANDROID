import re

with open('app/src/main/java/com/example/platform/android/ScreenCaptureService.kt', 'r') as f:
    content = f.read()

old_code = """            val expectedSize = width * height * 4
            val subscribers = _frameFlow.subscriptionCount.value
            // 1 reference for _latestFrame cache + 1 reference for each active subscriber
            val initialRefs = 1 + subscribers
            val bufferRef = bufferPool.acquireBuffer(width, height, expectedSize, initialRefs)

            if (bufferRef == null) {
                // All pre-allocated buffers are currently in use by downstream consumers.
                // Drop this frame cleanly rather than overwriting in-flight buffers or causing lag.
                droppedFrames++
                return
            }

            val pixelData = bufferRef.array

            if (rowPadding == 0) {
                val bytesToRead = minOf(buffer.remaining(), pixelData.size)
                buffer.get(pixelData, 0, bytesToRead)
            } else {
                var offset = 0
                val rowBytes = width * 4
                for (i in 0 until height) {
                    val rowStart = i * rowStride
                    if (rowStart < buffer.capacity()) {
                        buffer.position(rowStart)
                        val bytesToRead = minOf(rowBytes, buffer.remaining())
                        buffer.get(pixelData, offset, bytesToRead)
                    }
                    offset += rowBytes
                }
            }"""

new_code = """            val expectedSize = width * height * 4
            val subscribers = _frameFlow.subscriptionCount.value
            // 1 reference for _latestFrame cache + 1 reference for each active subscriber
            val initialRefs = 1 + subscribers
            val bufferRef = bufferPool.acquireBuffer(width, height, expectedSize, initialRefs)

            if (bufferRef == null) {
                // All pre-allocated buffers are currently in use by downstream consumers.
                // Drop this frame cleanly rather than overwriting in-flight buffers or causing lag.
                droppedFrames++
                return
            }

            val pixelData = bufferRef.array

            if (rowPadding == 0) {
                val bytesToRead = minOf(buffer.remaining(), pixelData.size)
                buffer.get(pixelData, 0, bytesToRead)
            } else {
                // We MUST copy row by row if row padding exists. 
                // Optimize loop slightly
                var offset = 0
                val rowBytes = width * 4
                for (i in 0 until height) {
                    val rowStart = i * rowStride
                    buffer.position(rowStart)
                    buffer.get(pixelData, offset, rowBytes)
                    offset += rowBytes
                }
            }"""

content = content.replace(old_code, new_code)

with open('app/src/main/java/com/example/platform/android/ScreenCaptureService.kt', 'w') as f:
    f.write(content)

print("ScreenCaptureService patched")
