import http from 'http';
import fs from 'fs';
import path from 'path';

const PORT = 3000;
const APK_PATH = path.join(process.cwd(), 'public', 'app-debug.apk');
const ALT_APK_PATH = path.join(process.cwd(), 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
const DIST_DIR = path.join(process.cwd(), 'dist');

// Ensure dist directory exists and copy index.html
try {
    if (!fs.existsSync(DIST_DIR)) {
        fs.mkdirSync(DIST_DIR, { recursive: true });
    }
    if (fs.existsSync(path.join(process.cwd(), 'index.html'))) {
        fs.copyFileSync(path.join(process.cwd(), 'index.html'), path.join(DIST_DIR, 'index.html'));
    }
} catch (e) {
    console.error('Error preparing dist directory:', e);
}

if (process.argv.includes('--check')) {
    console.log('Server check successful.');
    process.exit(0);
}

const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    const parsedUrl = new URL(req.url || '/', `http://localhost:${PORT}`);
    const pathname = parsedUrl.pathname;

    if (pathname === '/health' || pathname === '/api/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'ok', time: new Date().toISOString() }));
        return;
    }

    const targetApk = fs.existsSync(APK_PATH) ? APK_PATH : (fs.existsSync(ALT_APK_PATH) ? ALT_APK_PATH : null);

    if (pathname === '/app-debug.apk' || pathname === '/download') {
        if (!targetApk) {
            res.writeHead(404, { 'Content-Type': 'text/plain' });
            res.end('APK not found. Please build with ./gradlew assembleDebug');
            return;
        }

        const stat = fs.statSync(targetApk);
        res.writeHead(200, {
            'Content-Type': 'application/vnd.android.package-archive',
            'Content-Length': stat.size,
            'Content-Disposition': 'attachment; filename="app-debug.apk"',
            'Cache-Control': 'no-cache'
        });

        const readStream = fs.createReadStream(targetApk);
        readStream.pipe(res);
        return;
    }

    // Serve index.html
    const indexPath = fs.existsSync(path.join(process.cwd(), 'index.html'))
        ? path.join(process.cwd(), 'index.html')
        : (fs.existsSync(path.join(DIST_DIR, 'index.html')) ? path.join(DIST_DIR, 'index.html') : null);

    if (indexPath) {
        const html = fs.readFileSync(indexPath, 'utf-8');
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(html);
        return;
    }

    const apkSize = targetApk ? (fs.statSync(targetApk).size / (1024 * 1024)).toFixed(1) + ' MB' : '22 MB';

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MVP ESPORTS PK Live Analyzer</title>
</head>
<body style="background:#0E0E10;color:#F2F2F5;font-family:sans-serif;padding:32px;text-align:center;">
    <h1>MVP ESPORTS PK</h1>
    <p>Live Screen Capture & Detection Engine Foundation</p>
    <p><a href="/app-debug.apk" style="color:#FF6600;font-weight:bold;">DOWNLOAD APP-DEBUG.APK (${apkSize})</a></p>
</body>
</html>`);
});

server.on('error', (err: any) => {
    console.error('Server error:', err);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
});
