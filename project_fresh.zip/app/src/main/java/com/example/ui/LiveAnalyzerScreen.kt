package com.example.ui

import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AdminReviewCard
import com.example.ui.components.ArchitecturePipelineViewer
import com.example.ui.components.ConfidenceRuleViewer
import com.example.ui.components.LiveCaptureMonitor
import com.example.ui.components.RealDetectionInspectorCard
import com.example.ui.components.RoiEditorCard
import com.example.ui.components.StatusBadge
import com.example.ui.util.FrameBitmapConverter
import com.example.ui.theme.HighDensityBackground
import com.example.ui.theme.HighDensityBorder
import com.example.ui.theme.HighDensityDanger
import com.example.ui.theme.HighDensityOrange
import com.example.ui.theme.HighDensitySurface
import com.example.ui.theme.HighDensitySurfaceVariant
import com.example.ui.theme.HighDensityTextMuted
import com.example.ui.theme.HighDensityTextPrimary

@Composable
fun LiveAnalyzerScreen(
    viewModel: LiveAnalyzerViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val rois by viewModel.rois.collectAsState()
    val selectedRoi by viewModel.selectedRoi.collectAsState()
    val latestPreviewFrame by viewModel.latestPreviewFrame.collectAsState()
    val latestSampledFrame by viewModel.latestSampledFrame.collectAsState()
    val croppedFrame by viewModel.croppedFrame.collectAsState()
    val adminReviewQueue by viewModel.adminReviewQueue.collectAsState()
    val realDetectionInspectionState by viewModel.realDetectionInspectionState.collectAsState()

    val previewBitmap = remember(latestPreviewFrame) {
        FrameBitmapConverter.toImageBitmap(latestPreviewFrame)
    }

    val croppedBitmap = remember(croppedFrame) {
        FrameBitmapConverter.toImageBitmap(croppedFrame)
    }

    val context = LocalContext.current
    val mediaProjectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
    }

    val captureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            viewModel.startScreenCaptureWithPermission(result.resultCode, result.data!!)
        } else {
            viewModel.onCapturePermissionDenied()
        }
    }

    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = HighDensityBackground
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(HighDensitySurface)
                    .border(1.dp, HighDensityBorder, RoundedCornerShape(8.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "MVP ESPORTS PK",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = HighDensityOrange,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "LIVE ANALYZER // FRAME ANALYSIS FOUNDATION",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = HighDensityTextPrimary,
                    letterSpacing = 0.5.sp
                )
            }

            // Real Live Capture Monitor Viewport
            LiveCaptureMonitor(
                isCapturing = uiState.isCapturingActive,
                sourceName = uiState.videoSourceText,
                framesCaptured = uiState.framesCaptured,
                fps = uiState.captureFps,
                resolution = uiState.resolutionText
            )

            // Screen Capture Status Card
            StatusBadge(
                label = "Screen Capture",
                value = uiState.screenCaptureStatusText
            )

            // Capture Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        if (mediaProjectionManager != null) {
                            captureLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
                        } else {
                            viewModel.startScreenCapture()
                        }
                    },
                    enabled = !uiState.isCapturingActive,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = HighDensityOrange,
                        contentColor = Color.Black,
                        disabledContainerColor = Color(0xFF1E1610),
                        disabledContentColor = Color(0xFF523B2A)
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = if (!uiState.isCapturingActive) Color.Black else Color(0xFF523B2A)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = "START SCREEN CAPTURE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }

                OutlinedButton(
                    onClick = { viewModel.stopScreenCapture() },
                    enabled = uiState.isCapturingActive,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = HighDensitySurfaceVariant,
                        contentColor = HighDensityDanger,
                        disabledContainerColor = Color(0xFF121214),
                        disabledContentColor = HighDensityTextMuted
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(
                            if (uiState.isCapturingActive) HighDensityDanger.copy(alpha = 0.5f) else HighDensityBorder
                        )
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.size(6.dp))
                    Text(
                        text = "STOP CAPTURE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Phase 4B: Admin-Controlled ROI / Crop Editor & Frame Sampler
            RoiEditorCard(
                rois = rois,
                selectedRoi = selectedRoi,
                frameWidth = latestPreviewFrame?.width ?: latestSampledFrame?.width ?: 1080,
                frameHeight = latestPreviewFrame?.height ?: latestSampledFrame?.height ?: 1920,
                frameBitmap = previewBitmap,
                croppedBitmap = croppedBitmap,
                framesReceived = uiState.framesReceived,
                framesSampled = uiState.framesSampled,
                captureFps = uiState.captureFps,
                previewFps = uiState.previewFps,
                analysisFps = uiState.analysisFps,
                targetSampleFps = uiState.targetSampleFps,
                onTargetSampleFpsChanged = { viewModel.setTargetSampleFps(it) },
                onSelectRoi = { viewModel.selectRoi(it) },
                onUpdateRoi = { viewModel.updateRoi(it) },
                onToggleRoiEnabled = { viewModel.toggleRoiEnabled(it) },
                onDeleteRoi = { viewModel.deleteRoi(it) },
                onResetDefaults = { viewModel.resetRoiDefaults() },
                onAddNewRoi = { viewModel.addNewRoi(it) }
            )

            // Phase 4C.3 Real Detection Inspector Card
            RealDetectionInspectorCard(
                inspectionState = realDetectionInspectionState,
                fullFrameBitmap = previewBitmap,
                croppedRoiBitmap = croppedBitmap
            )

            // Confidence Rule Architecture Viewer (Clean Rules, No Mock Detections)
            ConfidenceRuleViewer()

            // Phase 4C: Admin Review Queue Foundation
            AdminReviewCard(
                pendingEvents = adminReviewQueue,
                onConfirmEvent = { viewModel.confirmAdminEvent(it) },
                onRejectEvent = { id, reason -> viewModel.rejectAdminEvent(id, reason) }
            )

            // Infrastructure Status Badges
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(HighDensitySurface)
                    .border(1.dp, HighDensityBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatusBadge(
                    label = "Input Status",
                    value = uiState.inputStatusText
                )

                StatusBadge(
                    label = "AI Detection",
                    value = uiState.aiDetectionStatusText
                )

                StatusBadge(
                    label = "Supabase",
                    value = uiState.supabaseStatusText
                )

                StatusBadge(
                    label = "YouTube",
                    value = uiState.youtubeStatusText
                )
            }

            // High Density Architecture Pipeline Viewer
            ArchitecturePipelineViewer()
        }
    }
}
