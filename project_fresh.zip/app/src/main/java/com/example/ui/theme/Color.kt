package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Theme Color Palette
val HighDensityBackground = Color(0xFF0A0A0B)
val HighDensitySurface = Color(0xFF121214)
val HighDensitySurfaceVariant = Color(0xFF1A1A1C)
val HighDensityBorder = Color(0xFF242426)
val HighDensityBorderAccent = Color(0xFF38383C)

// Accent Colors
val HighDensityOrange = Color(0xFFEA580C)
val HighDensityOrangeLight = Color(0xFFFB923C)
val HighDensityOrangeDim = Color(0x26EA580C)

// Status & Semantic Colors
val HighDensityTextPrimary = Color(0xFFE0E0E0)
val HighDensityTextSecondary = Color(0xFF9CA3AF)
val HighDensityTextMuted = Color(0xFF6B7280)
val HighDensitySuccess = Color(0xFF10B981)
val HighDensitySuccessDim = Color(0x2610B981)
val HighDensityWarning = Color(0xFFF59E0B)
val HighDensityWarningDim = Color(0x26F59E0B)
val HighDensityDanger = Color(0xFFEF4444)
val HighDensityDangerDim = Color(0x26EF4444)
val HighDensityInfo = Color(0xFF3B82F6)
val HighDensityInfoDim = Color(0x263B82F6)

