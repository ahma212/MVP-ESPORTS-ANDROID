package com.example.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.model.DetectedEvent
import com.example.core.model.DetectionFrame
import com.example.core.model.EsportsDetectedEvent
import com.example.core.model.FrameAnalysisInput
import com.example.core.model.RoiRegion
import com.example.platform.PlatformDetector
import com.example.platform.PlatformType
import com.example.platform.VideoInputFactory
import com.example.platform.android.AndroidScreenCaptureService
import com.example.services.analysis.FrameSampler
import com.example.services.analysis.RoiCropPipeline
import com.example.services.detection.IDetectionResult
import com.example.services.detection.IDetectionService
import com.example.services.detection.PUBGDetectionService
import com.example.ui.components.RealDetectionInspectionState
import com.example.services.event.EventProcessor
import com.example.services.event.IEventProcessingService
import com.example.services.roi.IRoiConfigurationService
import com.example.services.roi.InMemoryRoiConfigurationService
import com.example.services.supabase.ISupabaseService
import com.example.services.supabase.SupabaseService
import com.example.services.video.IVideoInputService
import com.example.services.video.VideoCaptureState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * UI State for the Live Analyzer main screen with Phase 4B Frame Analysis & ROI Telemetry.
 */
data class LiveAnalyzerUiState(
    val platformType: PlatformType = PlatformDetector.getCurrentPlatform(),
    val inputStatusText: String = "Not connected",
    val videoSourceText: String = "Not connected",
    val screenCaptureStatusText: String = "OFF",
    val isCapturingActive: Boolean = false,
    val aiDetectionStatusText: String = "OFF",
    val supabaseStatusText: String = "Not connected",
    val youtubeStatusText: String = "Not connected",
    val framesCaptured: Long = 0L,
    val captureFps: Int = 0,
    val previewFps: Double = 0.0,
    val resolutionText: String = "None",
    val activeTab: Int = 0,
    val framesReceived: Long = 0L,
    val framesSampled: Long = 0L,
    val analysisFps: Double = 0.0,
    val targetSampleFps: Double = 5.0
)

class LiveAnalyzerViewModel(application: Application) : AndroidViewModel(application) {

    val videoInputService: IVideoInputService = VideoInputFactory.createVideoInputService(application)
    val detectionService: IDetectionService = PUBGDetectionService(autoRegisterDefaultDetector = true)
    val supabaseService: ISupabaseService = SupabaseService()
    val eventService: IEventProcessingService = EventProcessor(supabaseService)

    // Phase 4B Services
    val frameSampler: FrameSampler = FrameSampler(initialTargetFps = 5.0, coroutineScope = viewModelScope)
    val roiService: IRoiConfigurationService = InMemoryRoiConfigurationService()

    // Phase 4C Services & Queues
    val adminReviewQueue: StateFlow<List<EsportsDetectedEvent>> = eventService.adminReviewQueue

    val captureState: StateFlow<VideoCaptureState> = videoInputService.captureState

    val rois: StateFlow<List<RoiRegion>> = roiService.rois
    val selectedRoi: StateFlow<RoiRegion?> = roiService.selectedRoi

    // Dedicated smooth preview frame (Direct from hardware capture stream)
    private val _latestPreviewFrame = MutableStateFlow<DetectionFrame?>(null)
    val latestPreviewFrame: StateFlow<DetectionFrame?> = _latestPreviewFrame.asStateFlow()

    // Downsampled analysis frame (Configurable 1-30 FPS)
    val latestSampledFrame: StateFlow<FrameAnalysisInput?> = frameSampler.latestSampledFrame

    private val _croppedFrame = MutableStateFlow<FrameAnalysisInput?>(null)
    val croppedFrame: StateFlow<FrameAnalysisInput?> = _croppedFrame.asStateFlow()

    private val _realDetectionInspectionState = MutableStateFlow(RealDetectionInspectionState())
    val realDetectionInspectionState: StateFlow<RealDetectionInspectionState> = _realDetectionInspectionState.asStateFlow()

    private val _uiState = MutableStateFlow(LiveAnalyzerUiState())
    val uiState: StateFlow<LiveAnalyzerUiState> = _uiState.asStateFlow()

    private var previewWindowStartMs = System.currentTimeMillis()
    private var previewFramesInWindow = 0

    init {
        // Collect video capture state updates to sync UI indicators
        viewModelScope.launch {
            videoInputService.captureState.collect { state ->
                when (state) {
                    is VideoCaptureState.Idle -> {
                        _uiState.value = _uiState.value.copy(
                            inputStatusText = "Not connected",
                            videoSourceText = "Not connected",
                            screenCaptureStatusText = "OFF",
                            isCapturingActive = false,
                            framesCaptured = 0L,
                            captureFps = 0,
                            previewFps = 0.0,
                            resolutionText = "None"
                        )
                        _latestPreviewFrame.value = null
                        frameSampler.reset()
                        _croppedFrame.value = null
                        previewFramesInWindow = 0
                        previewWindowStartMs = System.currentTimeMillis()
                    }
                    is VideoCaptureState.Initializing -> {
                        _uiState.value = _uiState.value.copy(
                            inputStatusText = "Initializing...",
                            videoSourceText = videoInputService.activeSource.displayName,
                            screenCaptureStatusText = "STARTING",
                            isCapturingActive = false
                        )
                    }
                    is VideoCaptureState.Capturing -> {
                        _uiState.value = _uiState.value.copy(
                            inputStatusText = "Connected",
                            videoSourceText = state.sourceType.displayName,
                            screenCaptureStatusText = "ACTIVE",
                            isCapturingActive = true,
                            framesCaptured = state.framesCaptured,
                            captureFps = state.fps,
                            resolutionText = "${state.width}x${state.height}"
                        )
                    }
                    is VideoCaptureState.Paused -> {
                        _uiState.value = _uiState.value.copy(
                            inputStatusText = "Paused",
                            screenCaptureStatusText = "PAUSED",
                            isCapturingActive = false
                        )
                    }
                    is VideoCaptureState.Error -> {
                        _uiState.value = _uiState.value.copy(
                            inputStatusText = "Error: ${state.message}",
                            screenCaptureStatusText = "ERROR",
                            isCapturingActive = false
                        )
                    }
                }
            }
        }

        // Dedicated Parallel Ingestion:
        // 1. Direct preview update at full capture rate
        // 2. Downsampled analysis stream via FrameSampler
        viewModelScope.launch {
            videoInputService.frameFlow.collect { frame ->
                // Direct Preview Stream (Smooth, real capture frame rate)
                _latestPreviewFrame.value = frame

                // Live Cropped Inspection Preview (Smooth ~23 FPS preview crop update)
                val currentRoi = roiService.selectedRoi.value ?: RoiRegion.DEFAULT_KILL_FEED
                val input = FrameAnalysisInput.fromDetectionFrame(frame, videoInputService.activeSource)
                _croppedFrame.value = RoiCropPipeline.crop(input, currentRoi.copy(enabled = true))

                val now = System.currentTimeMillis()
                previewFramesInWindow++
                if (now - previewWindowStartMs >= 1000L) {
                    val elapsed = (now - previewWindowStartMs).toDouble()
                    val calculatedPreviewFps = (previewFramesInWindow * 1000.0) / elapsed
                    _uiState.value = _uiState.value.copy(previewFps = calculatedPreviewFps)
                    previewFramesInWindow = 0
                    previewWindowStartMs = now
                }

                // Independent Analysis Stream (Configurable 5 FPS default)
                frameSampler.onIncomingFrame(frame, videoInputService.activeSource)
            }
        }

        // Process sampled frames through AI analysis pipeline without altering preview crop
        viewModelScope.launch {
            frameSampler.sampledFrameFlow.collect { sampledInput ->
                val currentRoi = roiService.selectedRoi.value ?: RoiRegion.DEFAULT_KILL_FEED
                val croppedForAnalysis = RoiCropPipeline.crop(sampledInput, currentRoi)
                // Pass to detection placeholder (safe pass-through without fake results)
                detectionService.analyzeFrameInput(croppedForAnalysis)
            }
        }

        // Track FrameSampler telemetry
        viewModelScope.launch {
            frameSampler.framesReceived.collect { received ->
                _uiState.value = _uiState.value.copy(framesReceived = received)
            }
        }

        viewModelScope.launch {
            frameSampler.framesSampled.collect { sampled ->
                _uiState.value = _uiState.value.copy(framesSampled = sampled)
            }
        }

        viewModelScope.launch {
            frameSampler.currentAnalysisFps.collect { analysisFps ->
                _uiState.value = _uiState.value.copy(analysisFps = analysisFps)
            }
        }

        viewModelScope.launch {
            frameSampler.targetSampleFps.collect { targetFps ->
                _uiState.value = _uiState.value.copy(targetSampleFps = targetFps)
            }
        }

        // Collect Detection Results for Real Detection Inspector
        viewModelScope.launch {
            detectionService.detectionResultsFlow.collect { result ->
                val currentRoi = roiService.selectedRoi.value ?: RoiRegion.DEFAULT_KILL_FEED
                val state = _realDetectionInspectionState.value
                val now = System.currentTimeMillis()
                val dropped = (_uiState.value.framesReceived - _uiState.value.framesSampled).coerceAtLeast(0L)

                when (result) {
                    is IDetectionResult.Success -> {
                        val ev = result.event
                        val isAutoProcess = ev.confidence >= 0.50f
                        _realDetectionInspectionState.value = state.copy(
                            activeRoi = currentRoi,
                            ocrLeftText = ev.metadata["raw_left"] ?: "-",
                            ocrRightText = ev.metadata["raw_right"] ?: "-",
                            detectedIcons = ev.metadata["cause"] ?: ev.eventType.name,
                            ignoredFlags = ev.metadata["flags_ignored"] ?: "None",
                            detectedEventType = ev.eventType.name,
                            killerName = ev.killerPlayerId ?: "-",
                            victimName = ev.victimPlayerId ?: "-",
                            confidence = ev.confidence,
                            decisionStatus = if (isAutoProcess) "AUTO_PROCESS" else "ADMIN_REVIEW",
                            decisionReason = "Rule #${ev.metadata["rule_number"] ?: "1"}: ${ev.metadata["explanation"] ?: "Detection verified"}",
                            uniqueEventId = ev.eventId,
                            frameTimestampMs = ev.frameTimestamp,
                            capturedFps = _uiState.value.captureFps,
                            sampledFps = _uiState.value.targetSampleFps.toInt(),
                            analyzedFps = _uiState.value.analysisFps,
                            droppedFrames = dropped,
                            detectorLatencyMs = (now - ev.frameTimestamp).coerceAtLeast(0L)
                        )
                    }
                    is IDetectionResult.NoDetection -> {
                        _realDetectionInspectionState.value = state.copy(
                            activeRoi = currentRoi,
                            ocrLeftText = "-",
                            ocrRightText = "-",
                            detectedIcons = "-",
                            ignoredFlags = "-",
                            detectedEventType = "-",
                            killerName = "-",
                            victimName = "-",
                            confidence = 0.0f,
                            decisionStatus = "NO_DECISION_WAIT",
                            decisionReason = "Waiting for clear visual kill-feed evidence",
                            uniqueEventId = "-",
                            frameTimestampMs = result.frameTimestamp,
                            capturedFps = _uiState.value.captureFps,
                            sampledFps = _uiState.value.targetSampleFps.toInt(),
                            analyzedFps = _uiState.value.analysisFps,
                            droppedFrames = dropped
                        )
                    }
                    is IDetectionResult.Failure -> {
                        _realDetectionInspectionState.value = state.copy(
                            activeRoi = currentRoi,
                            decisionStatus = "NO_DECISION_WAIT",
                            decisionReason = "Analysis error: ${result.reason}",
                            capturedFps = _uiState.value.captureFps,
                            sampledFps = _uiState.value.targetSampleFps.toInt(),
                            analyzedFps = _uiState.value.analysisFps,
                            droppedFrames = dropped
                        )
                    }
                }
            }
        }

        // Collect Frame Analysis Result Telemetry
        viewModelScope.launch {
            detectionService.analysisResultFlow.collect { res ->
                val state = _realDetectionInspectionState.value
                _realDetectionInspectionState.value = state.copy(
                    avgAnalysisTimeMs = res.processingDurationMs
                )
            }
        }
    }

    fun setTargetSampleFps(fps: Double) {
        frameSampler.setTargetSampleFps(fps)
    }

    fun selectRoi(id: String) {
        roiService.selectRoi(id)
        recomputeCrop()
    }

    fun updateRoi(roi: RoiRegion) {
        viewModelScope.launch {
            roiService.updateRoi(roi)
            recomputeCrop(roi)
        }
    }

    fun toggleRoiEnabled(id: String) {
        viewModelScope.launch {
            roiService.toggleRoiEnabled(id)
            recomputeCrop()
        }
    }

    fun deleteRoi(id: String) {
        viewModelScope.launch {
            roiService.deleteRoi(id)
            recomputeCrop()
        }
    }

    fun resetRoiDefaults() {
        viewModelScope.launch {
            roiService.resetToDefaults()
            recomputeCrop()
        }
    }

    fun addNewRoi(name: String) {
        val newRoi = RoiRegion(
            id = "roi_${System.currentTimeMillis()}",
            name = name.ifBlank { "ROI_${System.currentTimeMillis() % 1000}" },
            x = 0.2f,
            y = 0.2f,
            width = 0.3f,
            height = 0.2f,
            enabled = true
        )
        viewModelScope.launch {
            roiService.saveRoi(newRoi)
            roiService.selectRoi(newRoi.id)
            recomputeCrop(newRoi)
        }
    }

    private fun recomputeCrop(overrideRoi: RoiRegion? = null) {
        val currentRoi = overrideRoi ?: roiService.selectedRoi.value ?: RoiRegion.DEFAULT_KILL_FEED
        val preview = _latestPreviewFrame.value
        if (preview != null) {
            val input = FrameAnalysisInput.fromDetectionFrame(preview, videoInputService.activeSource)
            _croppedFrame.value = RoiCropPipeline.crop(input, currentRoi.copy(enabled = true))
        } else {
            val sampled = frameSampler.latestSampledFrame.value ?: return
            _croppedFrame.value = RoiCropPipeline.crop(sampled, currentRoi.copy(enabled = true))
        }
    }

    fun startScreenCaptureWithPermission(resultCode: Int, data: Intent) {
        if (videoInputService is AndroidScreenCaptureService) {
            videoInputService.attachMediaProjectionIntent(resultCode, data)
        }
        viewModelScope.launch {
            videoInputService.startCapture()
        }
    }

    fun onCapturePermissionDenied() {
        _uiState.value = _uiState.value.copy(
            inputStatusText = "Screen capture permission denied",
            screenCaptureStatusText = "DENIED"
        )
    }

    fun startScreenCapture() {
        viewModelScope.launch {
            videoInputService.startCapture()
        }
    }

    fun stopScreenCapture() {
        viewModelScope.launch {
            videoInputService.stopCapture()
        }
    }

    fun confirmAdminEvent(eventId: String, confirmedBy: String = "Admin") {
        viewModelScope.launch {
            eventService.confirmEvent(eventId, confirmedBy)
        }
    }

    fun rejectAdminEvent(eventId: String, reason: String = "Admin manual rejection", rejectedBy: String = "Admin") {
        viewModelScope.launch {
            eventService.rejectEvent(eventId, reason, rejectedBy)
        }
    }

    fun setTab(index: Int) {
        _uiState.value = _uiState.value.copy(activeTab = index)
    }

    override fun onCleared() {
        super.onCleared()
        videoInputService.release()
        detectionService.shutdown()
    }
}
