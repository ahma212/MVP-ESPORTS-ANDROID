package com.example.ui.util

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.core.model.DetectionFrame
import com.example.core.model.FrameAnalysisInput
import java.nio.ByteBuffer

/**
 * Utility for converting raw frame buffers into Android ImageBitmap instances
 * for live preview and ROI visualization in Jetpack Compose.
 *
 * Employs reusable Bitmap allocations to avoid high-frequency GC pressure
 * during 23+ FPS screen capture previews.
 */
object FrameBitmapConverter {

    @Volatile
    private var cachedPreviewBitmap: Bitmap? = null

    @Volatile
    private var cachedCropBitmap: Bitmap? = null

    @Synchronized
    fun toImageBitmap(frame: DetectionFrame?): ImageBitmap? {
        if (frame?.buffer == null || frame.width <= 0 || frame.height <= 0) return null
        val expectedSize = frame.width * frame.height * 4
        if (frame.buffer.size < expectedSize) return null

        return try {
            var bmp = cachedPreviewBitmap
            if (bmp == null || bmp.width != frame.width || bmp.height != frame.height || bmp.isRecycled) {
                bmp = Bitmap.createBitmap(frame.width, frame.height, Bitmap.Config.ARGB_8888)
                cachedPreviewBitmap = bmp
            }
            val byteBuffer = ByteBuffer.wrap(frame.buffer, 0, expectedSize)
            bmp.copyPixelsFromBuffer(byteBuffer)
            bmp.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun toImageBitmap(input: FrameAnalysisInput?): ImageBitmap? {
        if (input?.buffer == null || input.width <= 0 || input.height <= 0) return null
        val expectedSize = input.width * input.height * 4
        if (input.buffer.size < expectedSize) return null

        return try {
            var bmp = cachedCropBitmap
            if (bmp == null || bmp.width != input.width || bmp.height != input.height || bmp.isRecycled) {
                bmp = Bitmap.createBitmap(input.width, input.height, Bitmap.Config.ARGB_8888)
                cachedCropBitmap = bmp
            }
            val byteBuffer = ByteBuffer.wrap(input.buffer, 0, expectedSize)
            bmp.copyPixelsFromBuffer(byteBuffer)
            bmp.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }
}

