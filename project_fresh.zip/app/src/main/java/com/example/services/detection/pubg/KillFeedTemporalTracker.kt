package com.example.services.detection.pubg

import java.util.concurrent.ConcurrentHashMap

/**
 * Tracks PUBG Mobile kill feed bars across consecutive video frames to provide:
 * 1. Temporal / Animation stability (avoids premature decisions on blurry/animating frames).
 * 2. Duplicate protection (ensures a kill-feed bar lasting 3-5 seconds across multiple frames emits exactly ONE event).
 * 3. Knock -> Finish state tracking (correlates downed players and subsequent eliminations).
 */
class KillFeedTemporalTracker(
    private val duplicateWindowMs: Long = 6000L,
    private val knockRetentionMs: Long = 60000L
) {

    data class PendingKnock(
        val killerName: String?,
        val victimName: String,
        val weaponUsed: String?,
        val timestampMs: Long
    )

    data class FinalizedEventRecord(
        val eventKey: String,
        val firstSeenTimestampMs: Long,
        val finalizedTimestampMs: Long
    )

    // Tracks finalized events to prevent duplicate emissions
    private val finalizedEvents = ConcurrentHashMap<String, FinalizedEventRecord>()

    // Tracks pending knocks: victimName (normalized) -> PendingKnock
    private val pendingKnocks = ConcurrentHashMap<String, PendingKnock>()

    // Tracks active bars in transit across frames to ensure stable readability
    private val barClarityHistory = ConcurrentHashMap<String, MutableList<Float>>()

    /**
     * Builds a deterministic key for an event.
     */
    fun buildEventKey(
        rawLeft: String,
        rawRight: String,
        cause: KillFeedCause,
        hasKnock: Boolean
    ): String {
        val normLeft = PUBGTextNormalizer.normalizePlayerName(rawLeft)
        val normRight = PUBGTextNormalizer.normalizePlayerName(rawRight)
        return "${normLeft}::${cause.name}::${normRight}::${if (hasKnock) "KNOCK" else "KILL"}"
    }

    /**
     * Evaluates whether a frame observation is clear enough or should WAIT.
     *
     * Temporal / Animation Rule:
     * - If killer name is unclear -> WAIT
     * - If victim name is unclear -> WAIT
     * - If required icon is unclear -> WAIT
     * - If feed is still transitioning/animating -> WAIT
     * - Returns true if ready to finalize; false if should wait.
     */
    fun isVisualEvidenceReady(
        rawLeft: String,
        rawRight: String,
        cause: KillFeedCause,
        isTransitioning: Boolean,
        clarityScore: Float
    ): Boolean {
        // Animation / transition in progress or unclear team/player token
        if (isTransitioning || PUBGTextNormalizer.hasUnclearTeamPlayerToken(rawLeft) || PUBGTextNormalizer.hasUnclearTeamPlayerToken(rawRight)) return false

        // Blurry or unreadable text
        if (clarityScore < 0.35f) return false

        val cleanLeft = PUBGTextNormalizer.stripFlagsAndDecorations(rawLeft)
        val cleanRight = PUBGTextNormalizer.stripFlagsAndDecorations(rawRight)

        // Right text (victim) is always required for all kills and knocks
        if (cleanRight.isBlank() || cleanRight.length < 2) return false

        // Left text is required unless it's a generic knock without weapon/attacker
        val leftIsSystem = PUBGTextNormalizer.isSystemText(cleanLeft) || cause.isEnvironment
        if (!leftIsSystem && cause != KillFeedCause.KNOCK && cleanLeft.isBlank()) {
            return false
        }

        // Check if cause icon is completely unknown
        if (cause == KillFeedCause.UNKNOWN && clarityScore < 0.70f) {
            return false
        }

        val eventKey = buildEventKey(rawLeft, rawRight, cause, hasKnock = false)
        val history = barClarityHistory.computeIfAbsent(eventKey) { mutableListOf() }
        history.add(clarityScore)

        // If clarity is sufficient in single frame (e.g. >= 0.40), or read across 2+ consecutive frames
        return clarityScore >= 0.40f || history.size >= 2
    }

    /**
     * Checks if this event has already been finalized recently (Duplicate Protection).
     */
    fun isDuplicateEvent(
        rawLeft: String,
        rawRight: String,
        cause: KillFeedCause,
        hasKnock: Boolean,
        currentTimestampMs: Long
    ): Boolean {
        cleanExpiredRecords(currentTimestampMs)
        val key = buildEventKey(rawLeft, rawRight, cause, hasKnock)
        val record = finalizedEvents[key] ?: return false
        return (currentTimestampMs - record.finalizedTimestampMs) < duplicateWindowMs
    }

    /**
     * Marks an event as finalized to block subsequent duplicate frame emissions.
     */
    fun markEventFinalized(
        rawLeft: String,
        rawRight: String,
        cause: KillFeedCause,
        hasKnock: Boolean,
        timestampMs: Long
    ) {
        val key = buildEventKey(rawLeft, rawRight, cause, hasKnock)
        finalizedEvents[key] = FinalizedEventRecord(
            eventKey = key,
            firstSeenTimestampMs = timestampMs,
            finalizedTimestampMs = timestampMs
        )

        val normVictim = PUBGTextNormalizer.normalizePlayerName(rawRight)
        if (hasKnock) {
            // Record pending knock
            val cleanLeft = PUBGTextNormalizer.extractCleanDisplayName(rawLeft)
            pendingKnocks[normVictim] = PendingKnock(
                killerName = cleanLeft,
                victimName = PUBGTextNormalizer.extractCleanDisplayName(rawRight),
                weaponUsed = cause.name,
                timestampMs = timestampMs
            )
        } else {
            // If victim was killed, consume pending knock
            pendingKnocks.remove(normVictim)
        }
    }

    /**
     * Retrieves any pending knock for a victim player.
     */
    fun getPendingKnock(victimRaw: String): PendingKnock? {
        val norm = PUBGTextNormalizer.normalizePlayerName(victimRaw)
        return pendingKnocks[norm]
    }

    /**
     * Clears old tracking state.
     */
    fun reset() {
        finalizedEvents.clear()
        pendingKnocks.clear()
        barClarityHistory.clear()
    }

    private fun cleanExpiredRecords(nowMs: Long) {
        finalizedEvents.entries.removeIf { nowMs - it.value.finalizedTimestampMs > duplicateWindowMs }
        pendingKnocks.entries.removeIf { nowMs - it.value.timestampMs > knockRetentionMs }
        if (barClarityHistory.size > 200) {
            barClarityHistory.clear()
        }
    }
}
