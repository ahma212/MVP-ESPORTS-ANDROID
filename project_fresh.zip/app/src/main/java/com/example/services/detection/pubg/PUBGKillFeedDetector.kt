package com.example.services.detection.pubg

import com.example.core.model.DetectedEvent
import com.example.core.model.DetectedEventType
import com.example.core.model.DetectionEvidence
import com.example.core.rules.ConfidenceGate
import com.example.services.detection.IDetectionResult
import com.example.services.detection.IPUBGVisualDetector
import java.util.UUID

/**
 * Phase 4C.2 — Real PUBG Mobile Kill-Feed Detector.
 *
 * Implements authoritative PUBG Mobile kill-feed recognition according to PUBG_Kill_Feed_Detector_Rules.pdf.
 *
 * Capabilities & Adherence:
 * 1. Complete Flag Removal: Country flags, clan badges, and decorative badges are completely ignored.
 * 2. Strict 20-Rule Decision Matrix: Implements the exact scoring and kill count logic from the specification.
 * 3. Temporal / Animation Rule: Blurry, transitioning, glowing, or incomplete bars wait for clear frames.
 * 4. Duplicate Event Protection: Consecutive frames of the same kill-feed bar generate exactly one event.
 * 5. Knock -> Finish State Correlation: Tracks downed status and handles subsequent eliminations cleanly.
 * 6. 50% Confidence Gate: Confidence >= 0.50f -> AUTO_PROCESS, Confidence < 0.50f -> ADMIN_REVIEW.
 * 7. Admin-Configured ROI: Uses dynamically passed ROI regions (no hardcoded coordinates).
 */
class PUBGKillFeedDetector(
    val temporalTracker: KillFeedTemporalTracker = KillFeedTemporalTracker()
) : IPUBGVisualDetector {

    init {
        if (PUBGKillFeedVisualParser.getRegisteredVisionEngine() == null) {
            PUBGKillFeedVisualParser.registerVisionEngine(MLKitPUBGVisionEngine())
        }
    }

    override val detectorId: String = "PUBG_REAL_KILL_FEED_DETECTOR_PHASE_4C2"
    override val description: String = "Authoritative PUBG Mobile 20-Rule Kill-Feed Recognition Engine"
    override val priority: Int = 100

    override suspend fun analyze(evidence: DetectionEvidence): IDetectionResult {
        // 1. Visual Extraction
        val extraction = PUBGKillFeedVisualParser.parseEvidence(evidence)
            ?: return IDetectionResult.NoDetection(evidence.frameTimestamp, evidence.roiId)

        // 2. Temporal / Animation Rule (Wait for readable evidence)
        val isReady = temporalTracker.isVisualEvidenceReady(
            rawLeft = extraction.rawLeft,
            rawRight = extraction.rawRight,
            cause = extraction.cause,
            isTransitioning = extraction.isTransitioning,
            clarityScore = extraction.clarityScore
        )
        if (!isReady) {
            // Wait until the required visual evidence is readable
            return IDetectionResult.NoDetection(evidence.frameTimestamp, evidence.roiId)
        }

        // 3. Duplicate Protection (Do not create multiple events for the same kill bar across frames)
        val isDuplicate = temporalTracker.isDuplicateEvent(
            rawLeft = extraction.rawLeft,
            rawRight = extraction.rawRight,
            cause = extraction.cause,
            hasKnock = extraction.hasKnock,
            currentTimestampMs = evidence.frameTimestamp
        )
        if (isDuplicate) {
            return IDetectionResult.NoDetection(evidence.frameTimestamp, evidence.roiId)
        }

        // 4. Authoritative Decision Tree Evaluation
        val decision = PUBGKillFeedDecisionEngine.evaluate(
            rawLeft = extraction.rawLeft,
            rawRight = extraction.rawRight,
            cause = extraction.cause,
            hasKnock = extraction.hasKnock,
            hasFinishHelmet = extraction.hasFinishHelmet,
            hasTeamKillIcon = extraction.hasTeamKillIcon,
            hasReviveIcon = extraction.hasReviveIcon,
            confidence = extraction.clarityScore
        )

        // 5. Knock-to-Finish State Transition & Zone Bleed Handling
        if (!decision.hasKnock && decision.decisionType == PUBGDecisionType.ENV_DEATH) {
            // If victim was previously knocked, environment death (zone/bleed) awards 0 points to knocker
            val pendingKnock = temporalTracker.getPendingKnock(decision.rawRight)
            if (pendingKnock != null) {
                // Zone death rule strictly applies: 0 points awarded to any player
            }
        }

        // 6. Mark Event Finalized in Temporal Tracker
        temporalTracker.markEventFinalized(
            rawLeft = extraction.rawLeft,
            rawRight = extraction.rawRight,
            cause = extraction.cause,
            hasKnock = extraction.hasKnock,
            timestampMs = evidence.frameTimestamp
        )

        // 7. Construct Standard DetectedEvent
        val detectedEventType = when (decision.decisionType) {
            PUBGDecisionType.KNOCK -> DetectedEventType.KNOCK
            PUBGDecisionType.REVIVE -> DetectedEventType.REVIVE
            PUBGDecisionType.ENV_DEATH -> DetectedEventType.ELIMINATION
            PUBGDecisionType.SELF_KILL,
            PUBGDecisionType.TEAM_KILL,
            PUBGDecisionType.ENEMY_KILL -> DetectedEventType.KILL
            PUBGDecisionType.NO_DECISION_WAIT -> DetectedEventType.OTHER
        }

        val eventId = "pubg_evt_${evidence.frameTimestamp}_${UUID.randomUUID().toString().take(8)}"

        val detectedEvent = DetectedEvent(
            eventId = eventId,
            eventType = detectedEventType,
            timestamp = System.currentTimeMillis(),
            frameTimestamp = evidence.frameTimestamp,
            confidence = decision.confidence,
            killerPlayerId = decision.pointAwardedTo ?: decision.killerName,
            victimPlayerId = decision.victimName,
            killerTeamId = decision.killerTeam,
            victimTeamId = decision.victimTeam,
            evidence = evidence,
            roiId = evidence.roiId,
            source = "SCREEN_CAPTURE",
            metadata = mapOf(
                "cause" to decision.cause.name,
                "rule_number" to decision.ruleNumber.toString(),
                "dead" to decision.dead.toString(),
                "kill_count" to decision.killCount.toString(),
                "point_awarded_to" to (decision.pointAwardedTo ?: "NONE"),
                "has_knock" to decision.hasKnock.toString(),
                "has_finish" to decision.hasFinishHelmet.toString(),
                "raw_left" to decision.rawLeft,
                "raw_right" to decision.rawRight,
                "explanation" to decision.explanation,
                "flags_ignored" to extraction.flagsExtracted.joinToString(",")
            )
        )

        val routingDecision = ConfidenceGate.evaluate(decision.confidence)
        return IDetectionResult.Success(detectedEvent, routingDecision)
    }

    /**
     * Resets internal tracking caches.
     */
    fun reset() {
        temporalTracker.reset()
    }
}
