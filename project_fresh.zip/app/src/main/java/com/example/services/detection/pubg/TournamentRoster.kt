package com.example.services.detection.pubg

import com.example.core.model.Player

/**
 * Registry holding official tournament slot-booking roster data.
 *
 * Maps (teamNumber, playerNumber) e.g., Team 3 Player 2 -> Player(id, inGameName, teamId, ...)
 */
object TournamentRoster {

    private val rosterMap = mutableMapOf<Pair<Int, Int>, Player>()

    fun registerPlayer(
        teamNumber: Int,
        playerNumber: Int,
        inGameName: String,
        realName: String? = null,
        teamName: String? = null,
        teamTag: String? = null
    ) {
        val player = Player(
            id = "t${teamNumber}_p${playerNumber}",
            inGameName = inGameName,
            realName = realName,
            teamId = "team_${teamNumber}",
            teamTag = teamTag ?: "T${teamNumber}",
            slotNumber = teamNumber,
            kills = 0,
            isAlive = true
        )
        rosterMap[Pair(teamNumber, playerNumber)] = player
    }

    fun resolvePlayer(teamNumber: Int, playerNumber: Int): Player? {
        return rosterMap[Pair(teamNumber, playerNumber)]
    }

    fun resolvePlayer(identity: PUBGTextNormalizer.TeamPlayerIdentity?): Player? {
        if (identity == null) return null
        return resolvePlayer(identity.teamNumber, identity.playerNumber)
    }

    fun clearRoster() {
        rosterMap.clear()
    }

    fun isRosterLoaded(): Boolean = rosterMap.isNotEmpty()
}
