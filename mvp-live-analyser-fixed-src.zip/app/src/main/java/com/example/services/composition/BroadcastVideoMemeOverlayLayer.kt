package com.example.services.composition

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.YuvImage
import android.media.Image
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import com.example.services.streaming.StandingTableControlsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream

/**
 * Meme / gallery video overlay.
 * zIndex 18 = behind standing (100), ticker (200), milestone (300).
 * Decodes with MediaExtractor + MediaCodec on a background thread.
 * Drops frames instead of stalling. Loops. No SurfaceTexture.
 */
class BroadcastVideoMemeOverlayLayer : IBroadcastLayer {

    companion object {
        private const val TAG = "BroadcastVideoMeme"
        private const val TARGET_WIDTH = 480
        private const val TARGET_HEIGHT = 270
    }

    override val layerId: String = "broadcast_video_meme_overlay_layer"
    override val layerName: String = "Broadcast Video / Meme Overlay Layer"
    override var isEnabled: Boolean = false
    override val zIndex: Int = 18

    var videoUri: String? = null

    private val decoderScope = CoroutineScope(Dispatchers.Default)
    private var playbackJob: Job? = null

    private var currentLoadedUri: String? = null

    @Volatile
    private var activeFrameBitmap: Bitmap? = null

    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#00E5FF")
    }
    private val rectF = RectF()

    @Synchronized
    private fun startPlayback(uriString: String) {
        if (uriString == currentLoadedUri && playbackJob?.isActive == true) return
        stopPlayback()
        currentLoadedUri = uriString
        playbackJob = decoderScope.launch {
            decodeAndStreamLoop(uriString, StandingTableControlsManager.context)
        }
    }

    private suspend fun decodeAndStreamLoop(uriString: String, context: Context?) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            if (context != null && (uriString.startsWith("content://") || uriString.startsWith("file://"))) {
                extractor.setDataSource(context, Uri.parse(uriString), null)
            } else {
                extractor.setDataSource(uriString)
            }

            var videoTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoTrack = i
                    format = f
                    break
                }
            }
            if (videoTrack < 0 || format == null) {
                Log.w(TAG, "No video track in $uriString")
                return
            }

            extractor.selectTrack(videoTrack)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputEos = false
            var reusable = activeFrameBitmap
            if (reusable == null || reusable.isRecycled) {
                reusable = Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
                activeFrameBitmap = reusable
            }

            while (isActive) {
                if (!inputEos) {
                    val inIx = codec.dequeueInputBuffer(8_000)
                    if (inIx >= 0) {
                        val input = codec.getInputBuffer(inIx)
                        val sampleSize = if (input != null) extractor.readSampleData(input, 0) else -1
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            codec.queueInputBuffer(inIx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIx = codec.dequeueOutputBuffer(info, 8_000)
                when {
                    outIx >= 0 -> {
                        if (info.size > 0) {
                            try {
                                val image = codec.getOutputImage(outIx)
                                if (image != null) {
                                    val bmp = yuvImageToBitmap(image, reusable)
                                    image.close()
                                    if (bmp != null) {
                                        activeFrameBitmap = bmp
                                        reusable = bmp
                                    }
                                }
                            } catch (e: Exception) {
                                Log.w(TAG, "frame convert: ${e.message}")
                            }
                        }
                        codec.releaseOutputBuffer(outIx, false)

                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                            codec.flush()
                            inputEos = false
                        }
                    }
                    outIx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        delay(4)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Playback loop stopped: ${e.message}")
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    private fun yuvImageToBitmap(image: Image, reuse: Bitmap?): Bitmap? {
        return try {
            if (image.format != ImageFormat.YUV_420_888) {
                return reuse
            }
            val yPlane = image.planes[0]
            val yBuf = yPlane.buffer
            val ySize = yBuf.remaining()
            val nv21 = ByteArray(image.width * image.height * 3 / 2)
            yBuf.get(nv21, 0, ySize)

            val u = image.planes[1]
            val v = image.planes[2]
            val uBuf = u.buffer
            val vBuf = v.buffer
            val chroma = ByteArray(uBuf.remaining() + vBuf.remaining())
            // NV21 = Y + VU interleaved; approximate by packing V then U rows
            var offset = image.width * image.height
            val vBytes = ByteArray(vBuf.remaining())
            val uBytes = ByteArray(uBuf.remaining())
            vBuf.get(vBytes)
            uBuf.get(uBytes)
            val pixelStride = v.pixelStride
            val rowStride = v.rowStride
            var dest = offset
            val chromaHeight = image.height / 2
            val chromaWidth = image.width / 2
            for (row in 0 until chromaHeight) {
                var col = 0
                while (col < chromaWidth && dest + 1 < nv21.size) {
                    val vi = row * rowStride + col * pixelStride
                    val ui = row * u.rowStride + col * u.pixelStride
                    if (vi < vBytes.size) nv21[dest] = vBytes[vi]
                    if (ui < uBytes.size && dest + 1 < nv21.size) nv21[dest + 1] = uBytes[ui]
                    dest += 2
                    col++
                }
            }

            val yuv = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
            val out = ByteArrayOutputStream()
            yuv.compressToJpeg(Rect(0, 0, image.width, image.height), 70, out)
            val jpeg = out.toByteArray()
            val decoded = android.graphics.BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return reuse
            val target = if (reuse != null && !reuse.isRecycled && reuse.width == TARGET_WIDTH && reuse.height == TARGET_HEIGHT) {
                reuse
            } else {
                Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
            }
            val c = Canvas(target)
            c.drawBitmap(decoded, null, Rect(0, 0, TARGET_WIDTH, TARGET_HEIGHT), bgPaint)
            if (decoded != target) decoded.recycle()
            target
        } catch (e: Exception) {
            Log.w(TAG, "yuvImageToBitmap: ${e.message}")
            reuse
        }
    }

    @Synchronized
    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        currentLoadedUri = null
    }

    override fun draw(canvas: Canvas, frameWidth: Int, frameHeight: Int, timestampMs: Long) {
        val uri = videoUri
        if (!isEnabled || uri.isNullOrBlank() || frameWidth <= 0 || frameHeight <= 0) {
            if (playbackJob?.isActive == true) {
                stopPlayback()
            }
            return
        }

        if (uri != currentLoadedUri) {
            startPlayback(uri)
        }

        val frame = activeFrameBitmap
        if (frame != null && !frame.isRecycled) {
            val overlayWidth = frameWidth * 0.28f
            val overlayHeight = frameHeight * 0.28f
            val left = frameWidth - overlayWidth - (frameWidth * 0.04f)
            val top = frameHeight - overlayHeight - (frameHeight * 0.10f)
            rectF.set(left, top, left + overlayWidth, top + overlayHeight)
            canvas.drawBitmap(frame, null, rectF, bgPaint)
            canvas.drawRoundRect(rectF, 12f, 12f, borderPaint)
        }
    }
}
