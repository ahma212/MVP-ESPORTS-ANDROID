package com.example.services.composition

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.example.core.model.DetectionFrame
import com.example.services.streaming.StandingTableControlsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

/**
 * Real-Time Broadcast Video Compositor Foundation (Part A).
 *
 * Implements [IBroadcastCompositor] and [com.example.services.streaming.ICompositionProcessor].
 *
 * Execution Pipeline:
 * Real Captured PUBG Frame (ScreenCaptureService)
 *         ↓
 * Broadcast Compositor Base Layer
 *         ↓
 * Overall Standing Overlay Layer (EsportsStandingTable integration)
 *         ↓
 * MVP ESPORTS Bottom Ticker Layer (EsportsBottomTicker integration)
 *         ↓
 * Final Composed Broadcast Frame (MediaCodec / Broadcast Program Output)
 *
 * Guarantees:
 * 1. Base layer is strictly the real captured PUBG mobile screen frame (never fake/placeholder).
 * 2. PUBG gameplay remains fully visible beneath semi-transparent esports overlays.
 * 3. Operator controls (Floating pointer, ROI boxes, buttons) are strictly excluded from broadcast output.
 * 4. Memory-optimized zero-allocation buffer reuse across high-frequency 30/60 FPS frames.
 */
class BroadcastVideoCompositor private constructor() : IBroadcastCompositor {

    companion object {
        @Volatile
        private var instance: BroadcastVideoCompositor? = null

        fun getInstance(): BroadcastVideoCompositor {
            return instance ?: synchronized(this) {
                instance ?: BroadcastVideoCompositor().also { instance = it }
            }
        }
    }

    private val layers = ConcurrentHashMap<String, IBroadcastLayer>()

    override val standingOverlay = OverallStandingOverlayLayer()
    fun setTeamsProvider(provider: () -> List<com.example.core.model.TeamLiveState>) {
        standingOverlay.teamsProvider = provider
        customGraphicsOverlay.teamsProvider = provider
        vipMilestoneOverlay.teamsProvider = provider
    }
    override val tickerOverlay = BottomTickerOverlayLayer()
    val sceneGraphicsOverlay = SceneGraphicsOverlayLayer()
    val vipMilestoneOverlay = VipMilestoneOverlayLayer()
    val customGraphicsOverlay = CustomGraphicsOverlayLayer()
    val videoMemeOverlay = BroadcastVideoMemeOverlayLayer()

    private val _composedFrames = MutableSharedFlow<ComposedBroadcastFrame>(
        replay = 1,
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val composedFrames: SharedFlow<ComposedBroadcastFrame> = _composedFrames.asSharedFlow()

    private val _latestComposedFrame = MutableStateFlow<ComposedBroadcastFrame?>(null)
    override val latestComposedFrame: StateFlow<ComposedBroadcastFrame?> = _latestComposedFrame.asStateFlow()

    private val _isCompositing = MutableStateFlow(false)
    override val isCompositing: StateFlow<Boolean> = _isCompositing.asStateFlow()

    private var frameAttachmentJob: Job? = null
    private var controlsObserverJob: Job? = null
    private var sceneObserverJob: Job? = null
    private var milestoneObserverJob: Job? = null

    // Reusable bitmaps to eliminate garbage collection pressure
    @Volatile
    private var cachedProgramBitmap: Bitmap? = null
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    
    // Smoothness tracking
    private var frameTimes = mutableListOf<Long>()
    private var lastFpsUpdate = 0L
    private var frameCount = 0
    @Volatile
    private var currentFps = 0
    @Volatile
    private var isHeavy = false

    init {
        // Register default Part A, Part E, Part F, and Part G broadcast layers
        addLayer(standingOverlay)
        addLayer(tickerOverlay)
        addLayer(sceneGraphicsOverlay)
        addLayer(vipMilestoneOverlay)
        addLayer(customGraphicsOverlay)
        addLayer(videoMemeOverlay)
    }

    override fun addLayer(layer: IBroadcastLayer) {
        // Floating pointer, cropper, and operator control overlays must NOT appear in broadcast composition
        if (layer.layerId.contains("pointer", ignoreCase = true) ||
            layer.layerId.contains("cropper", ignoreCase = true) ||
            layer.layerId.contains("control", ignoreCase = true) ||
            layer.layerId.contains("overlay_badge", ignoreCase = true)
        ) {
            android.util.Log.w("BroadcastVideoCompositor", "Excluded operator layer '${layer.layerId}' from broadcast composition")
            return
        }
        layers[layer.layerId] = layer
    }

    override fun removeLayer(layerId: String) {
        layers.remove(layerId)
    }

    override fun getLayer(layerId: String): IBroadcastLayer? {
        return layers[layerId]
    }

    override fun getAllLayers(): List<IBroadcastLayer> {
        return layers.values.sortedBy { it.zIndex }
    }

    override fun setStandingOverlayEnabled(enabled: Boolean) {
        standingOverlay.isEnabled = enabled
    }

    override fun setTickerOverlayEnabled(enabled: Boolean) {
        tickerOverlay.isEnabled = enabled
    }

    /**
     * Attaches directly to a live frame stream from ScreenCaptureService or IVideoInputService.
     */
    override fun attachFrameSource(frameFlow: SharedFlow<DetectionFrame>, scope: CoroutineScope) {
        frameAttachmentJob?.cancel()
        controlsObserverJob?.cancel()
        sceneObserverJob?.cancel()
        milestoneObserverJob?.cancel()

        _isCompositing.value = true

        // Synchronize with operator toggle controls from StandingTableControlsManager
        controlsObserverJob = scope.launch {
            StandingTableControlsManager.controlsState.collect { controls ->
                standingOverlay.isEnabled = controls.scoreboardEnabled
                standingOverlay.top3Mode = controls.top3ModeEnabled
                
                // Standing Scale/Size mapping
                standingOverlay.scale = when (controls.standingSize) {
                    "Small" -> 0.75f
                    "Large" -> 1.25f
                    else -> 1.0f // "Medium"
                }

                // Standing Position mapping
                when (controls.standingPosition) {
                    "Top Left" -> {
                        standingOverlay.xOffsetPercent = 0.05f
                        standingOverlay.yOffsetPercent = 0.05f
                    }
                    "Bottom Left" -> {
                        standingOverlay.xOffsetPercent = 0.05f
                        standingOverlay.yOffsetPercent = 0.55f
                    }
                    "Bottom Right" -> {
                        standingOverlay.xOffsetPercent = 0.68f
                        standingOverlay.yOffsetPercent = 0.55f
                    }
                    else -> { // "Top Right"
                        standingOverlay.xOffsetPercent = 0.68f
                        standingOverlay.yOffsetPercent = 0.05f
                    }
                }

                tickerOverlay.isEnabled = controls.bottomTickerEnabled
                tickerOverlay.speedMultiplier = controls.tickerSpeedMultiplier

                // Ticker Size (height + textScale) mapping
                when (controls.tickerSize) {
                    "Small" -> {
                        tickerOverlay.heightPx = 30f
                        tickerOverlay.textScale = 0.8f
                    }
                    "Large" -> {
                        tickerOverlay.heightPx = 60f
                        tickerOverlay.textScale = 1.3f
                    }
                    else -> { // "Medium"
                        tickerOverlay.heightPx = 42f
                        tickerOverlay.textScale = 1.0f
                    }
                }

                tickerOverlay.yOffsetPercent = controls.tickerYOffset
                tickerOverlay.customText = controls.tickerCustomText
                tickerOverlay.loopVideoUri = controls.tickerLoopVideoUri
                tickerOverlay.loopVideoEnabled = controls.tickerLoopVideoEnabled

                videoMemeOverlay.videoUri = controls.tickerLoopVideoUri
                videoMemeOverlay.isEnabled = controls.tickerLoopVideoEnabled

                customGraphicsOverlay.isEnabled = controls.customGraphicsEnabled
                customGraphicsOverlay.customBannerText = controls.customBannerText
                customGraphicsOverlay.customBannerPosition = controls.customBannerPosition
                customGraphicsOverlay.customBannerScale = controls.customBannerScale
                vipMilestoneOverlay.isEnabled = controls.killCardEnabled || controls.milestoneCardEnabled
            }
        }

        // Synchronize with EsportsSceneEngine state (enabling scene graphics overlay for countdowns, breaks, endings)
        sceneObserverJob = scope.launch {
            com.example.services.scene.EsportsSceneEngine.sceneState.collect { sceneState ->
                // Keep the program clean by default. Scene graphics are opt-in through
                // their dedicated controls; never inject placeholder/status artwork just
                // because the scene is not LIVE_MATCH.
                sceneGraphicsOverlay.isEnabled = false
            }
        }

        // Observe teams state for VIP milestones
        milestoneObserverJob = scope.launch {
            var previousTeams = emptyList<com.example.core.model.TeamLiveState>()
            com.example.services.streaming.LocalLiveRuntimeManager.teamsState.collect { currentTeams ->
                if (previousTeams.isNotEmpty()) {
                    vipMilestoneOverlay.detectMilestones(previousTeams, currentTeams)
                }
                previousTeams = currentTeams
            }
        }

        // Ingest and composite real frames in background
        frameAttachmentJob = scope.launch {
            frameFlow.collect { rawFrame ->
                composeFrame(rawFrame)
            }
        }
    }

    /**
     * Core composition engine.
     * Takes the real captured PUBG mobile frame, paints it as the background,
     * overlays active esports graphics, and outputs the final broadcast frame.
     */
    @Synchronized
    override fun composeFrame(rawFrame: DetectionFrame): ComposedBroadcastFrame? {
        val buffer = rawFrame.buffer ?: return null
        val width = rawFrame.width
        val height = rawFrame.height
        if (width <= 0 || height <= 0) return null

        val expectedSize = width * height * 4
        if (buffer.size < expectedSize) return null

        val startTimestamp = System.currentTimeMillis()

        try {
            // Use ONE reusable ARGB bitmap per source size. The previous pipeline kept
            // both a base bitmap and a second output bitmap at full screen resolution,
            // doubling the resident pixel memory and the full-frame draw work.
            var programBmp = cachedProgramBitmap
            if (programBmp == null || programBmp.width != width || programBmp.height != height || programBmp.isRecycled) {
                programBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                cachedProgramBitmap = programBmp
            }

            val byteBuffer = ByteBuffer.wrap(buffer, 0, expectedSize)
            programBmp.copyPixelsFromBuffer(byteBuffer)

            // Draw directly on the program bitmap. Pointer/ROI/operator UI is never
            // part of this Canvas; only registered broadcast layers are rendered.
            val canvas = Canvas(programBmp)
            basePaint.colorFilter = com.example.services.station.StationDeskManager.getColorFilter()

            val enabledLayers = layers.values
                .asSequence()
                .filter { layer ->
                    layer.isEnabled &&
                        !layer.layerId.contains("pointer", ignoreCase = true) &&
                        !layer.layerId.contains("cropper", ignoreCase = true) &&
                        !layer.layerId.contains("control", ignoreCase = true)
                }
                .sortedBy { it.zIndex }
                .toList()

            val activeLayerIds = ArrayList<String>(enabledLayers.size)
            for (layer in enabledLayers) {
                layer.draw(canvas, width, height, rawFrame.timestampMs)
                activeLayerIds.add(layer.layerId)
            }

            val elapsed = System.currentTimeMillis() - startTimestamp
            frameCount++
            frameTimes.add(elapsed)
            if (frameTimes.size > 60) frameTimes.removeAt(0)

            val now = System.currentTimeMillis()
            if (now - lastFpsUpdate > 1000) {
                currentFps = frameCount
                frameCount = 0
                lastFpsUpdate = now

                val avgTime = frameTimes.average()
                isHeavy = avgTime > 20.0
                com.example.services.station.StationDeskManager.updatePerformanceMetrics(currentFps, isHeavy)

                val state = com.example.services.station.StationDeskManager.stationState.value
                if (state.smoothnessMode == com.example.services.station.SmoothnessMode.QUALITY && isHeavy) {
                    com.example.services.station.StationDeskManager.triggerAutoDowngrade()
                }
            }

            val composed = ComposedBroadcastFrame(
                frameId = rawFrame.frameId,
                timestampMs = rawFrame.timestampMs,
                width = width,
                height = height,
                bitmap = programBmp,
                activeLayers = activeLayerIds,
                compositionTimeMs = elapsed
            )

            _latestComposedFrame.value = composed
            _composedFrames.tryEmit(composed)
            return composed
        } catch (e: Exception) {
            android.util.Log.e("BroadcastVideoCompositor", "composeFrame failed: ${e.message}", e)
            return null
        }
    }

    /**
     * Backward-compatible bridge to existing [com.example.services.streaming.ICompositionProcessor].
     * Program output is strictly gameplay + standing + ticker + milestones + memes only.
     * Overlay screenshots or badges are strictly NOT drawn into the compose bitmap.
     */
    override fun compositeOverlay(frame: DetectionFrame, overlayBadge: Bitmap?): Bitmap {
        val composed = composeFrame(frame)
        return composed?.bitmap
            ?: cachedProgramBitmap
            ?: Bitmap.createBitmap(frame.width.coerceAtLeast(1), frame.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    }

    override fun release() {
        frameAttachmentJob?.cancel()
        frameAttachmentJob = null
        controlsObserverJob?.cancel()
        controlsObserverJob = null
        sceneObserverJob?.cancel()
        sceneObserverJob = null
        milestoneObserverJob?.cancel()
        milestoneObserverJob = null
        _isCompositing.value = false

        cachedProgramBitmap?.recycle()
        cachedProgramBitmap = null

        _latestComposedFrame.value = null
    }
}
