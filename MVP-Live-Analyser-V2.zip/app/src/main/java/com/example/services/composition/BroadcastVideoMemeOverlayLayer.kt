package com.example.services.composition

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.Image
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import com.example.services.streaming.StandingTableControlsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Meme / gallery video overlay.
 * zIndex 18 = behind standing (100), ticker (200), milestone (300).
 * Decodes with MediaExtractor + MediaCodec on a background thread.
 * Drops frames instead of stalling. Loops. No SurfaceTexture.
 */
class BroadcastVideoMemeOverlayLayer : IBroadcastLayer {

    companion object {
        private const val TAG = "BroadcastVideoMeme"
        private const val TARGET_WIDTH = 480
        private const val TARGET_HEIGHT = 270
    }

    override val layerId: String = "broadcast_video_meme_overlay_layer"
    override val layerName: String = "Broadcast Video / Meme Overlay Layer"
    override var isEnabled: Boolean = false
    override val zIndex: Int = 18

    var videoUri: String? = null

    private val decoderScope = CoroutineScope(Dispatchers.Default)
    private var playbackJob: Job? = null

    private var currentLoadedUri: String? = null

    @Volatile
    private var activeFrameBitmap: Bitmap? = null
    private var decodeTargetBitmap: Bitmap? = null
    private var memeArgbBuffer: IntArray? = null

    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.parseColor("#00E5FF")
    }
    private val rectF = RectF()

    @Synchronized
    private fun startPlayback(uriString: String) {
        if (uriString == currentLoadedUri && playbackJob?.isActive == true) return
        stopPlayback()
        currentLoadedUri = uriString
        playbackJob = decoderScope.launch {
            decodeAndStreamLoop(uriString, StandingTableControlsManager.context)
        }
    }

    private suspend fun decodeAndStreamLoop(uriString: String, context: Context?) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            if (context != null && (uriString.startsWith("content://") || uriString.startsWith("file://"))) {
                extractor.setDataSource(context, Uri.parse(uriString), null)
            } else {
                extractor.setDataSource(uriString)
            }

            var videoTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoTrack = i
                    format = f
                    break
                }
            }
            if (videoTrack < 0 || format == null) {
                Log.w(TAG, "No video track in $uriString")
                return
            }

            extractor.selectTrack(videoTrack)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputEos = false
            var reusable = decodeTargetBitmap
            if (reusable == null || reusable.isRecycled) {
                reusable = Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
                decodeTargetBitmap = reusable
            }
            if (activeFrameBitmap == null) {
                activeFrameBitmap = Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
            }

            while (isActive) {
                if (!inputEos) {
                    val inIx = codec.dequeueInputBuffer(8_000)
                    if (inIx >= 0) {
                        val input = codec.getInputBuffer(inIx)
                        val sampleSize = if (input != null) extractor.readSampleData(input, 0) else -1
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            codec.queueInputBuffer(inIx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIx = codec.dequeueOutputBuffer(info, 8_000)
                when {
                    outIx >= 0 -> {
                        if (info.size > 0) {
                            try {
                                val image = codec.getOutputImage(outIx)
                                if (image != null) {
                                    val bmp = yuvImageToBitmap(image, reusable)
                                    image.close()
                                    if (bmp != null) {
                                        val previousActive = activeFrameBitmap
                                        activeFrameBitmap = bmp
                                        reusable = previousActive?.takeIf {
                                            !it.isRecycled && it.width == TARGET_WIDTH && it.height == TARGET_HEIGHT && it !== bmp
                                        } ?: Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
                                        decodeTargetBitmap = reusable
                                    }
                                }
                            } catch (e: Exception) {
                                Log.w(TAG, "frame convert: ${e.message}")
                            }
                        }
                        codec.releaseOutputBuffer(outIx, false)

                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                            codec.flush()
                            inputEos = false
                        }
                    }
                    outIx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        delay(4)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Playback loop stopped: ${e.message}")
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    private fun yuvImageToBitmap(image: Image, reuse: Bitmap?): Bitmap? {
        return try {
            if (image.format != ImageFormat.YUV_420_888) return reuse

            val target = if (reuse != null && !reuse.isRecycled && reuse.width == TARGET_WIDTH && reuse.height == TARGET_HEIGHT) {
                reuse
            } else {
                Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
            }

            // Read planes using their row/pixel strides and convert directly to ARGB.
            // The old implementation built NV21 -> JPEG -> Bitmap for every frame,
            // which caused large CPU spikes and visible meme-overlay stutter.
            val yPlane = image.planes[0]
            val uPlane = image.planes[1]
            val vPlane = image.planes[2]
            val yBuf = yPlane.buffer
            val uBuf = uPlane.buffer
            val vBuf = vPlane.buffer
            val yRowStride = yPlane.rowStride
            val uRowStride = uPlane.rowStride
            val vRowStride = vPlane.rowStride
            val yPixelStride = yPlane.pixelStride
            val uPixelStride = uPlane.pixelStride
            val vPixelStride = vPlane.pixelStride

            val out = memeArgbBuffer?.takeIf { it.size == TARGET_WIDTH * TARGET_HEIGHT }
                ?: IntArray(TARGET_WIDTH * TARGET_HEIGHT).also { memeArgbBuffer = it }
            val scaleX = image.width.toFloat() / TARGET_WIDTH.toFloat()
            val scaleY = image.height.toFloat() / TARGET_HEIGHT.toFloat()

            fun byteAt(buf: java.nio.ByteBuffer, index: Int): Int {
                return if (index >= 0 && index < buf.limit()) buf.get(index).toInt() and 0xFF else 0
            }

            var dst = 0
            for (oy in 0 until TARGET_HEIGHT) {
                val sy = (oy * scaleY).toInt().coerceIn(0, image.height - 1)
                val uvY = sy / 2
                for (ox in 0 until TARGET_WIDTH) {
                    val sx = (ox * scaleX).toInt().coerceIn(0, image.width - 1)
                    val uvX = sx / 2

                    val yIndex = sy * yRowStride + sx * yPixelStride
                    val uIndex = uvY * uRowStride + uvX * uPixelStride
                    val vIndex = uvY * vRowStride + uvX * vPixelStride
                    val y = byteAt(yBuf, yIndex)
                    val u = byteAt(uBuf, uIndex)
                    val v = byteAt(vBuf, vIndex)

                    val c = (y - 16).coerceAtLeast(0)
                    val d = u - 128
                    val e = v - 128
                    val r = ((298 * c + 409 * e + 128) shr 8).coerceIn(0, 255)
                    val g = ((298 * c - 100 * d - 208 * e + 128) shr 8).coerceIn(0, 255)
                    val b = ((298 * c + 516 * d + 128) shr 8).coerceIn(0, 255)
                    out[dst++] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            target.setPixels(out, 0, TARGET_WIDTH, 0, 0, TARGET_WIDTH, TARGET_HEIGHT)
            target
        } catch (e: Exception) {
            Log.w(TAG, "yuvImageToBitmap: ${e.message}")
            reuse
        }
    }

    @Synchronized
    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        currentLoadedUri = null
    }

    override fun draw(canvas: Canvas, frameWidth: Int, frameHeight: Int, timestampMs: Long) {
        val uri = videoUri
        if (!isEnabled || uri.isNullOrBlank() || frameWidth <= 0 || frameHeight <= 0) {
            if (playbackJob?.isActive == true) {
                stopPlayback()
            }
            return
        }

        if (uri != currentLoadedUri) {
            startPlayback(uri)
        }

        val frame = activeFrameBitmap
        if (frame != null && !frame.isRecycled) {
            val overlayWidth = frameWidth * 0.28f
            val overlayHeight = frameHeight * 0.28f
            val left = frameWidth - overlayWidth - (frameWidth * 0.04f)
            val top = frameHeight - overlayHeight - (frameHeight * 0.10f)
            rectF.set(left, top, left + overlayWidth, top + overlayHeight)
            canvas.drawBitmap(frame, null, rectF, bgPaint)
            canvas.drawRoundRect(rectF, 12f, 12f, borderPaint)
        }
    }
}
