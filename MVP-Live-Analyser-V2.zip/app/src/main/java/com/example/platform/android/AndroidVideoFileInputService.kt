package com.example.platform.android

import android.content.Context
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import com.example.core.model.DetectionFrame
import com.example.services.video.IVideoInputService
import com.example.services.video.VideoCaptureState
import com.example.services.video.VideoSourceType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

/**
 * Hardware-decoded local video input.
 *
 * V1 used MediaMetadataRetriever.getFrameAtTime() in a loop. That API is a poor fit
 * for realtime playback because every requested timestamp can trigger a random seek /
 * software bitmap decode. V2 uses MediaExtractor + MediaCodec with a Surface backed by
 * ImageReader, then emits RGBA frames to the existing detection/compositor pipeline.
 */
class AndroidVideoFileInputService(
    private val context: Context,
    private val videoUri: Uri
) : IVideoInputService {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var decodeJob: Job? = null
    private var decoderThread: HandlerThread? = null
    private var decoderHandler: Handler? = null
    private var imageReader: ImageReader? = null
    private var decoder: MediaCodec? = null
    private var extractor: MediaExtractor? = null

    private val _captureState = MutableStateFlow<VideoCaptureState>(VideoCaptureState.Idle)
    override val captureState: StateFlow<VideoCaptureState> = _captureState.asStateFlow()

    private val _frameFlow = MutableSharedFlow<DetectionFrame>(
        extraBufferCapacity = 8,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )
    override val frameFlow: SharedFlow<DetectionFrame> = _frameFlow.asSharedFlow()

    override val activeSource: VideoSourceType = VideoSourceType.VIDEO_FILE_FEED

    private val stateLock = Any()
    @Volatile private var isPaused = false
    @Volatile private var stopRequested = false
    @Volatile private var pendingSeekMs: Long? = null

    private var durationMs = 0L
    private var videoWidth = 1920
    private var videoHeight = 1080
    private var targetFps = 30
    private var frameIndex = 0L
    private var lastEmittedMs = 0L

    init {
        readMetadata()
    }

    private fun readMetadata() {
        val r = android.media.MediaMetadataRetriever()
        try {
            r.setDataSource(context, videoUri)
            durationMs = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            videoWidth = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()?.coerceAtLeast(2) ?: 1920
            videoHeight = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()?.coerceAtLeast(2) ?: 1080
            val fps = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()?.toInt()
            // 24–30 FPS is enough for the program pipeline and keeps CPU/GPU load bounded.
            targetFps = (fps ?: 30).coerceIn(24, 30)
        } catch (_: Exception) {
            durationMs = 0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    override suspend fun startCapture(): Result<Unit> {
        if (decodeJob?.isActive == true) return Result.success(Unit)

        stopRequested = false
        isPaused = false
        pendingSeekMs = null
        frameIndex = 0L
        lastEmittedMs = 0L

        decodeJob = scope.launch {
            runDecoderLoop()
        }
        return Result.success(Unit)
    }

    private suspend fun runDecoderLoop() {
        try {
            setupDecoder()
            _captureState.value = VideoCaptureState.Capturing(
                sourceType = VideoSourceType.VIDEO_FILE_FEED,
                width = videoWidth,
                height = videoHeight,
                fps = targetFps,
                framesCaptured = 0L
            )

            var inputEos = false
            var outputEos = false
            while (isActive && !stopRequested) {
                if (isPaused) {
                    delay(20)
                    continue
                }

                val seekMs = pendingSeekMs
                if (seekMs != null) {
                    pendingSeekMs = null
                    val ex = extractor
                    val dec = decoder
                    if (ex != null && dec != null) {
                        ex.seekTo(seekMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST)
                        try { dec.flush() } catch (_: Exception) {}
                        inputEos = false
                        outputEos = false
                        lastEmittedMs = seekMs
                    }
                }

                val dec = decoder ?: break
                val ex = extractor ?: break

                if (!inputEos) {
                    val inputIndex = dec.dequeueInputBuffer(8_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = dec.getInputBuffer(inputIndex)
                        val sampleSize = if (inputBuffer != null) ex.readSampleData(inputBuffer, 0) else -1
                        if (sampleSize < 0) {
                            dec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEos = true
                        } else {
                            dec.queueInputBuffer(inputIndex, 0, sampleSize, ex.sampleTime, ex.sampleFlags)
                            ex.advance()
                        }
                    }
                }

                val bufferInfo = MediaCodec.BufferInfo()
                val outputIndex = dec.dequeueOutputBuffer(bufferInfo, 8_000)
                if (outputIndex >= 0) {
                    // Output is rendered to ImageReader's Surface; the listener emits frames.
                    dec.releaseOutputBuffer(outputIndex, true)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputEos = true
                    }
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // Surface output: format changes are handled by the decoder/Surface.
                } else if (outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    delay(1)
                }

                if (inputEos && outputEos) {
                    // Loop local playback only after the decoder has actually emitted EOS,
                    // so the last buffered frames are not cut off.
                    ex.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                    try { dec.flush() } catch (_: Exception) {}
                    inputEos = false
                    outputEos = false
                    lastEmittedMs = 0L
                }
            }
        } catch (e: Exception) {
            _captureState.value = VideoCaptureState.Error("Video decoding error: ${e.message}", e)
        } finally {
            releaseDecoderResources()
            _captureState.value = VideoCaptureState.Idle
        }
    }


    private fun setupDecoder() {
        val ex = MediaExtractor()
        if (videoUri.toString().startsWith("content://") || videoUri.toString().startsWith("file://")) {
            ex.setDataSource(context, videoUri, null)
        } else {
            ex.setDataSource(videoUri.toString())
        }

        var track = -1
        var format: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/")) {
                track = i
                format = f
                break
            }
        }
        check(track >= 0 && format != null) { "No video track found" }

        ex.selectTrack(track)
        val f = format!!
        videoWidth = f.getInteger(MediaFormat.KEY_WIDTH).coerceAtLeast(2)
        videoHeight = f.getInteger(MediaFormat.KEY_HEIGHT).coerceAtLeast(2)

        val mime = f.getString(MediaFormat.KEY_MIME) ?: error("Missing video MIME")
        val dec = MediaCodec.createDecoderByType(mime)

        val thread = HandlerThread("LocalVideoDecoder").apply { start() }
        val handler = Handler(thread.looper)
        val reader = ImageReader.newInstance(
            videoWidth,
            videoHeight,
            PixelFormat.RGBA_8888,
            3
        )

        reader.setOnImageAvailableListener({ ir -> onDecodedImage(ir) }, handler)
        dec.configure(f, reader.surface, null, 0)
        dec.start()

        extractor = ex
        decoder = dec
        decoderThread = thread
        decoderHandler = handler
        imageReader = reader
    }

    private fun onDecodedImage(reader: ImageReader) {
        val image = try { reader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        if (stopRequested || isPaused) {
            image.close()
            return
        }

        try {
            val ptsMs = if (image.timestamp > 0L) image.timestamp / 1_000_000L else lastEmittedMs + 1000L / targetFps
            val now = SystemClock.elapsedRealtime()
            val safePtsMs = if (ptsMs <= lastEmittedMs) lastEmittedMs + 1L else ptsMs

            val width = image.width
            val height = image.height
            val plane = image.planes[0]
            val src = plane.buffer.duplicate()
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowBytes = width * 4
            val rgba = ByteArray(width * height * 4)

            if (pixelStride == 4 && rowStride == rowBytes) {
                src.position(0)
                src.get(rgba, 0, minOf(src.remaining(), rgba.size))
            } else {
                var outOffset = 0
                for (y in 0 until height) {
                    val rowStart = y * rowStride
                    if (rowStart >= src.capacity()) break
                    src.position(rowStart)
                    val copyBytes = minOf(rowBytes, src.remaining(), rgba.size - outOffset)
                    src.get(rgba, outOffset, copyBytes)
                    outOffset += rowBytes
                }
            }

            frameIndex++
            lastEmittedMs = safePtsMs
            val frame = DetectionFrame(
                frameId = frameIndex,
                timestampMs = safePtsMs,
                width = width,
                height = height,
                buffer = rgba,
                format = "RGBA_8888",
                sourceIdentifier = "video_file"
            )
            if (!_frameFlow.tryEmit(frame)) {
                // Flow is DROP_OLDEST; reaching here means the downstream collector is
                // temporarily saturated. The frame is simply discarded rather than
                // blocking decoder output.
            }

            _captureState.value = VideoCaptureState.Capturing(
                sourceType = VideoSourceType.VIDEO_FILE_FEED,
                width = width,
                height = height,
                fps = targetFps,
                framesCaptured = frameIndex,
                startTimeMs = now
            )
        } finally {
            image.close()
        }
    }

    fun pausePlayback() {
        isPaused = true
    }

    fun resumePlayback() {
        isPaused = false
    }

    fun seekTo(positionMs: Long) {
        pendingSeekMs = positionMs.coerceIn(0L, durationMs)
    }

    override suspend fun stopCapture(): Result<Unit> {
        stopRequested = true
        decodeJob?.cancel()
        decodeJob = null
        releaseDecoderResources()
        _captureState.value = VideoCaptureState.Idle
        return Result.success(Unit)
    }

    override fun release() {
        stopRequested = true
        decodeJob?.cancel()
        decodeJob = null
        releaseDecoderResources()
        _captureState.value = VideoCaptureState.Idle
    }

    @Synchronized
    private fun releaseDecoderResources() {
        try { decoder?.stop() } catch (_: Exception) {}
        try { decoder?.release() } catch (_: Exception) {}
        decoder = null

        try { extractor?.release() } catch (_: Exception) {}
        extractor = null

        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null

        try { decoderThread?.quitSafely() } catch (_: Exception) {}
        decoderThread = null
        decoderHandler = null
    }
}
