# MVP Live Analyser V2 — engineering audit

## Changes in this V2

- Preserved the original package, Supabase integration, detection/ROI stack, scoreboard, YouTube/RTMP stack and existing tests.
- Broadcast compositor now reuses a single full-resolution program bitmap instead of maintaining two full-resolution ARGB buffers.
- Scene placeholder graphics are no longer enabled automatically for non-LIVE scenes; the program stays clean unless scene graphics are explicitly enabled.
- Screen capture delivery is paced at a maximum of 30 FPS to stop unnecessary full-screen RGBA copies from hammering the device when the display is 60 FPS or higher.
- H.264 Bitmap→YUV conversion reuses the scaled bitmap, ARGB array and YUV buffer instead of allocating them on every frame.
- Meme overlay no longer performs YUV→NV21→JPEG→Bitmap on every frame; it converts YUV planes directly into the reusable ARGB bitmap.
- Floating pointer control-room sections are lazy-created, so enabling the pointer no longer constructs ten heavy panels immediately.
- Station program preview no longer exposes composition-latency telemetry.
- Google Sign-In can request a real Web client ID through BuildConfig when configured, without inventing a fake ID.

## Official guidance used

Android documentation recommends Surface-based MediaCodec input for high-performance encoder paths, MediaProjection foreground services require the mediaProjection foreground-service type/permission on current Android versions, and TYPE_APPLICATION_OVERLAY is the supported application overlay window type with SYSTEM_ALERT_WINDOW.

Media3 ExoPlayer is the Android-recommended player stack for local/streamed media playback. For this V2, the local source pipeline was moved to Android MediaCodec Surface decoding instead of doing timestamp-by-timestamp MediaMetadataRetriever decoding; this keeps the existing DetectionFrame interface intact while removing the main random-seek bottleneck. A future UI-only player can still use Media3 1.11.0 for rich seek/controls.

## Validation

Static source validation was performed after the edits. A full Gradle/device build could not be completed in this environment because the supplied Gradle wrapper requires downloading Gradle 9.3.1 from services.gradle.org and network access for the build host is unavailable. Therefore this ZIP is a source-level V2 update, not a claim of a device-validated APK.

## YouTube OAuth requirement

For the `com.example.esports` package, create/configure an Android OAuth client with the SHA-1 of the certificate actually used to sign the APK, and configure a valid Web application client ID for backend/ID-token use. The source now accepts that Web client ID through `GOOGLE_WEB_CLIENT_ID`; it does not invent a placeholder.

## Research references

- Android MediaProjection foreground-service requirements: https://developer.android.com/develop/background-work/services/fgs/service-types
- Android application overlay requirements: https://developer.android.com/reference/android/view/WindowManager.LayoutParams
- Android Media3 ExoPlayer: https://developer.android.com/media/media3/exoplayer
- AndroidX Media3 stable release listing (1.11.0): https://developer.android.com/jetpack/androidx/versions/stable-channel
- Google YouTube Android quickstart / SHA-1 OAuth setup: https://developers.google.com/youtube/v3/quickstart/android
- Google Sign-In Web client ID / requestIdToken reference: https://developers.google.com/android/reference/kotlin/com/google/android/gms/auth/api/signin/GoogleSignInOptions.Builder
